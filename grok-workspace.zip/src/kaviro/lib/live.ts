export type LiveEvent = { event: string; payload: unknown };

type Handler = (event: string, payload: unknown) => void;

const handlers = new Set<Handler>();

export function subscribeLive(handler: Handler) {
  handlers.add(handler);
  return () => {
    handlers.delete(handler);
  };
}

export function emitLive(event: string, payload: unknown) {
  for (const handler of handlers) handler(event, payload);
}
