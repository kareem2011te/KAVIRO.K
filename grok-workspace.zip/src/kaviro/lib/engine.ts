import { emitLive } from "./live";
import { getAuthToken } from "./session";

type Role = "member" | "supervisor" | "admin";

type Perms = {
  canApproveMembers: boolean;
  canManageAssessments: boolean;
  canViewSessions: boolean;
  canRevokeSessions: boolean;
  canManageTasksAndGroups: boolean;
  canViewAnalytics: boolean;
  canManageIntegrations: boolean;
};

const DEFAULT_PERMS: Perms = {
  canApproveMembers: true,
  canManageAssessments: true,
  canViewSessions: true,
  canRevokeSessions: true,
  canManageTasksAndGroups: true,
  canViewAnalytics: true,
  canManageIntegrations: false,
};

const DB_KEY = "kaviro.workspace.v1";

class ApiError extends Error {
  status: number;
  payload: Record<string, unknown>;
  constructor(status: number, message: string, extra: Record<string, unknown> = {}) {
    super(message);
    this.status = status;
    this.payload = { error: message, ...extra };
  }
}

function fail(status: number, message: string, extra?: Record<string, unknown>): never {
  throw new ApiError(status, message, extra);
}

function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

function nowIso() {
  return new Date().toISOString();
}

function code6() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function hashPassword(password: string) {
  let h = 2166136261;
  const s = `kaviro::${password}`;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return `fnv1a:${(h >>> 0).toString(16)}`;
}

function hashToken(token: string) {
  return hashPassword(`tok:${token}`);
}

function sanitize(user: any) {
  const copy = { ...user };
  delete copy.passwordHash;
  delete copy.emailVerificationCode;
  delete copy.resetPasswordCode;
  delete copy.twoFactorSecret;
  return copy;
}

function parseUa() {
  const lower = (typeof navigator !== "undefined" ? navigator.userAgent : "").toLowerCase();
  let deviceType: "Desktop" | "Tablet" | "Mobile" = "Desktop";
  if (/ipad|tablet/.test(lower)) deviceType = "Tablet";
  else if (/mobile|iphone|android/.test(lower)) deviceType = "Mobile";
  let browser = "Web Browser";
  if (lower.includes("edg/")) browser = "Microsoft Edge";
  else if (lower.includes("chrome/")) browser = "Google Chrome";
  else if (lower.includes("firefox/")) browser = "Mozilla Firefox";
  else if (lower.includes("safari/")) browser = "Apple Safari";
  let os = "Unknown OS";
  if (lower.includes("windows")) os = "Windows";
  else if (lower.includes("mac os")) os = "macOS";
  else if (lower.includes("android")) os = "Android";
  else if (lower.includes("iphone") || lower.includes("ipad")) os = "iOS";
  else if (lower.includes("linux")) os = "Linux";
  return { deviceType, browser, os };
}

const online = new Set<string>();

function presence() {
  emitLive("presence:update", { onlineUserIds: [...online] });
}

function touch() {
  saveDb();
  emitLive("workspace:changed", { at: nowIso() });
}

let cache: any | null = null;

function seed() {
  const now = nowIso();
  const hourAgo = new Date(Date.now() - 3600 * 1000).toISOString();
  const dayAgo = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  const tomorrow = new Date(Date.now() + 24 * 3600 * 1000).toISOString();
  const twoDays = new Date(Date.now() + 48 * 3600 * 1000).toISOString();
  const passwordHash = hashPassword("Kaviro@2026");
  const base = {
    passwordHash,
    emailVerified: true,
    twoFactorEnabled: false,
    humanVerified: true,
    createdAt: dayAgo,
    lastActiveAt: now,
  };
  return {
    users: [
      {
        ...base,
        id: "usr-admin-01",
        fullName: "Tariq Al-Mansoor",
        email: "admin@kaviro.ai",
        phone: "+971 50 482 9104",
        whatsapp: "+971 50 482 9104",
        desiredRole: "Platform Administrator",
        department: "Executive Operations",
        skills: ["Security Architecture", "System Governance", "AI Strategy", "RBAC"],
        interests: ["Enterprise Security", "Team Scaling"],
        bio: "Head of Platform Operations & Security Governance at KAVIRO.",
        role: "admin",
        status: "approved",
        onboarding: doneOnboarding(),
        preferredLanguage: "en",
      },
      {
        ...base,
        id: "usr-sup-01",
        fullName: "Sarah Chen",
        email: "supervisor@kaviro.ai",
        phone: "+1 415 890 3312",
        whatsapp: "+1 415 890 3312",
        desiredRole: "Engineering Team Lead",
        department: "Core Product Engineering",
        skills: ["TypeScript", "Distributed Systems", "Technical Interviews", "Agile Delivery"],
        interests: ["Mentorship", "Code Quality"],
        bio: "Engineering Supervisor overseeing onboarding, technical assessments, and project delivery.",
        role: "supervisor",
        supervisorPermissions: { ...DEFAULT_PERMS },
        status: "approved",
        onboarding: doneOnboarding(),
        preferredLanguage: "en",
        lastActiveAt: hourAgo,
      },
      {
        ...base,
        id: "usr-mem-01",
        fullName: "Omar El-Sayed",
        email: "member@kaviro.ai",
        phone: "+20 100 742 8819",
        whatsapp: "+20 100 742 8819",
        desiredRole: "Senior Full-Stack Engineer",
        department: "Core Product Engineering",
        skills: ["React", "TypeScript", "PostgreSQL", "Node.js"],
        interests: ["AI Workflows", "Realtime Collaboration"],
        bio: "Full-stack engineer focused on resilient web platforms and bilingual interfaces.",
        role: "member",
        status: "approved",
        onboarding: {
          profileCompleted: true,
          cvCompleted: true,
          humanVerified: true,
          assessmentCompleted: false,
          applicationSubmitted: true,
        },
        preferredLanguage: "en",
      },
      {
        ...base,
        id: "usr-mem-02",
        fullName: "Lina Haddad",
        email: "lina.haddad@kaviro.ai",
        phone: "+962 79 514 2201",
        desiredRole: "Product Designer",
        department: "Design Systems",
        skills: ["Figma", "Design Tokens", "Accessibility", "Arabic RTL UI"],
        interests: ["Design Engineering"],
        bio: "Product designer specializing in bilingual RTL enterprise interfaces.",
        role: "member",
        status: "pending",
        onboarding: doneOnboarding(),
        preferredLanguage: "ar",
        createdAt: hourAgo,
        lastActiveAt: hourAgo,
      },
    ],
    sessions: [
      {
        id: "ses-seed-01",
        userId: "usr-mem-02",
        tokenHash: hashToken("seed-inactive"),
        deviceType: "Mobile",
        browser: "Apple Safari",
        os: "iOS",
        ipAddress: "192.168.10.42",
        loginAt: hourAgo,
        lastActivityAt: hourAgo,
        status: "active",
        isUnusual: true,
        alertReason: "First sign-in from a new iOS mobile device",
      },
    ],
    cvs: [
      {
        id: "cv-mem-01",
        userId: "usr-mem-01",
        fullName: "Omar El-Sayed",
        headline: "Senior Full-Stack Engineer · TypeScript & Cloud Architecture",
        email: "member@kaviro.ai",
        phone: "+20 100 742 8819",
        location: "Cairo, Egypt",
        summary:
          "Full-stack software engineer with 6+ years building real-time SaaS, data pipelines, and accessible bilingual web products.",
        education: [
          {
            id: "edu-1",
            institution: "Cairo University",
            degree: "B.Sc.",
            field: "Computer Engineering",
            startYear: "2015",
            endYear: "2019",
          },
        ],
        experience: [
          {
            id: "exp-1",
            company: "NileCloud Systems",
            title: "Senior Software Engineer",
            period: "2022 – Present",
            description: "Led the workspace dashboard migration to TypeScript and live sync, cutting latency by 42%.",
          },
        ],
        projects: [
          {
            id: "prj-1",
            name: "Realtime Collab Engine",
            role: "Lead Architect",
            summary: "Multi-room messaging and presence with offline recovery.",
            impact: "4,500 concurrent channels at 99.95% delivery.",
          },
        ],
        achievements: ["Cut CI from 14 minutes to 4 minutes."],
        technicalSkills: ["TypeScript", "React", "Node.js", "PostgreSQL", "WebSockets"],
        softSkills: ["Mentorship", "System Ownership"],
        updatedAt: hourAgo,
      },
    ],
    assessments: [
      {
        id: "asm-eng-01",
        title: "Full-Stack Architecture & Security Readiness",
        titleAr: "اختبار جاهزية البنية البرمجية والأمن السيبراني",
        description: "Practical judgment across authentication, real-time state, API security, and trade-offs.",
        category: "Engineering",
        timeLimitMinutes: 20,
        maxAttempts: 3,
        passingScore: 70,
        assignedUserIds: ["usr-mem-01", "usr-mem-02"],
        randomizeQuestions: true,
        createdBy: "usr-sup-01",
        createdAt: dayAgo,
        questions: [
          {
            id: "q-1",
            type: "mcq",
            prompt: "Where should RBAC permissions be enforced in a production SaaS platform?",
            promptAr: "أين يجب فرض صلاحيات الوصول المعتمدة على الأدوار في منصة احترافية؟",
            options: [
              "Only in React UI route guards",
              "On the server API layer for every protected endpoint",
              "Inside browser localStorage flags",
              "Only during user login",
            ],
            correctAnswer: "On the server API layer for every protected endpoint",
            points: 25,
          },
          {
            id: "q-2",
            type: "true_false",
            prompt: "True or False: Password hashes should always use a unique per-user cryptographic salt.",
            promptAr: "صح أم خطأ: يجب استخدام ملح تشفير فريد لكل مستخدم عند تجزئة كلمات المرور.",
            options: ["True", "False"],
            correctAnswer: "True",
            points: 20,
          },
          {
            id: "q-3",
            type: "scenario",
            prompt:
              "A supervisor notices a team account signed in from an unrecognized OS and location. Outline the immediate containment and audit steps.",
            promptAr: "لاحظ المشرف تسجيل دخول من جهاز غير معتاد. ما خطوات الاحتواء والمراجعة الفورية؟",
            points: 30,
          },
          {
            id: "q-4",
            type: "written",
            prompt: "How do you prevent duplicate messages when a realtime client reconnects after a brief network drop?",
            promptAr: "كيف تمنع تكرار الرسائل عند إعادة الاتصال بعد انقطاع الشبكة؟",
            points: 25,
          },
        ],
      },
      {
        id: "asm-design-01",
        title: "Bilingual Design Systems & Accessibility",
        titleAr: "أنظمة التصميم ثنائية اللغة وإتاحة الوصول",
        description: "RTL mirroring, contrast ratios, and token consistency.",
        category: "Design",
        timeLimitMinutes: 15,
        maxAttempts: 2,
        passingScore: 75,
        assignedUserIds: ["usr-mem-02"],
        randomizeQuestions: false,
        createdBy: "usr-sup-01",
        createdAt: dayAgo,
        questions: [
          {
            id: "q-d1",
            type: "mcq",
            prompt: "What is the minimum WCAG AA contrast ratio for standard body text?",
            options: ["2.5:1", "3.0:1", "4.5:1", "7.0:1"],
            correctAnswer: "4.5:1",
            points: 50,
          },
          {
            id: "q-d2",
            type: "written",
            prompt: "Explain two layout adjustments required when switching a dashboard from LTR English to RTL Arabic.",
            points: 50,
          },
        ],
      },
    ],
    attempts: [
      {
        id: "att-lina-01",
        assessmentId: "asm-design-01",
        userId: "usr-mem-02",
        startedAt: hourAgo,
        submittedAt: hourAgo,
        answers: [
          { questionId: "q-d1", answer: "4.5:1", isCorrect: true, pointsAwarded: 50 },
          {
            questionId: "q-d2",
            answer: "Mirror the sidebar and directional icons, and keep numeric metrics tabular.",
            pointsAwarded: 0,
          },
        ],
        autoScore: 50,
        manualScore: 0,
        totalScore: 50,
        maxScore: 100,
        status: "pending_review",
      },
    ],
    conversations: [
      {
        id: "conv-grp-core",
        type: "group",
        name: "Core Engineering & Onboarding",
        description: "Architecture, sprint updates, and onboarding.",
        announcement: "Complete human verification before the weekly sync.",
        memberIds: ["usr-admin-01", "usr-sup-01", "usr-mem-01", "usr-mem-02"],
        adminIds: ["usr-admin-01", "usr-sup-01"],
        pinnedMessageIds: ["msg-01"],
        createdAt: dayAgo,
        updatedAt: hourAgo,
      },
      {
        id: "conv-dm-sup-mem",
        type: "direct",
        name: "Sarah Chen & Omar El-Sayed",
        memberIds: ["usr-sup-01", "usr-mem-01"],
        adminIds: ["usr-sup-01", "usr-mem-01"],
        pinnedMessageIds: [],
        createdAt: dayAgo,
        updatedAt: hourAgo,
      },
    ],
    messages: [
      {
        id: "msg-01",
        conversationId: "conv-grp-core",
        senderId: "usr-sup-01",
        content: "Welcome to the core channel. Review your onboarding checklist and the upcoming skill assessment.",
        reactions: { "👍": ["usr-admin-01", "usr-mem-01"] },
        readBy: ["usr-sup-01", "usr-admin-01", "usr-mem-01"],
        createdAt: dayAgo,
      },
      {
        id: "msg-02",
        conversationId: "conv-grp-core",
        senderId: "usr-mem-01",
        content: "Thanks Sarah — CV draft is uploaded and ready for review.",
        replyToId: "msg-01",
        reactions: {},
        readBy: ["usr-mem-01", "usr-sup-01"],
        createdAt: hourAgo,
      },
      {
        id: "msg-03",
        conversationId: "conv-dm-sup-mem",
        senderId: "usr-sup-01",
        content: "Omar, finish the architecture assessment so we can lock your project assignment.",
        reactions: {},
        readBy: ["usr-sup-01", "usr-mem-01"],
        createdAt: hourAgo,
      },
    ],
    projects: [
      {
        id: "proj-01",
        name: "KAVIRO Platform v2 Rollout",
        description: "Onboarding, CV intelligence, and session security.",
        leadId: "usr-sup-01",
        memberIds: ["usr-admin-01", "usr-sup-01", "usr-mem-01", "usr-mem-02"],
        status: "active",
        createdAt: dayAgo,
      },
      {
        id: "proj-02",
        name: "Security & Compliance Audit",
        description: "Session monitoring, RBAC, and assessment integrity.",
        leadId: "usr-admin-01",
        memberIds: ["usr-admin-01", "usr-sup-01"],
        status: "active",
        createdAt: dayAgo,
      },
    ],
    tasks: [
      task("tsk-01", "proj-01", "Finalize bilingual RTL navigation", "usr-mem-02", "usr-sup-01", "in_review", "high", 85, tomorrow, dayAgo, hourAgo, [
        { id: "cmt-1", authorId: "usr-sup-01", text: "Looks crisp on desktop. Check the mobile drawer next.", createdAt: hourAgo },
      ]),
      task("tsk-02", "proj-01", "Complete the architecture assessment", "usr-mem-01", "usr-sup-01", "in_progress", "urgent", 50, tomorrow, dayAgo, hourAgo),
      task("tsk-03", "proj-02", "Review pending applications and unusual sessions", "usr-sup-01", "usr-admin-01", "backlog", "medium", 20, twoDays, dayAgo, dayAgo),
      task("tsk-04", "proj-02", "Confirm session revocation actually signs devices out", "usr-admin-01", "usr-admin-01", "done", "high", 100, now, dayAgo, hourAgo),
    ],
    meetings: [
      {
        id: "mtg-01",
        title: "Weekly Engineering & Onboarding Sync",
        description: "Assessments, milestones, and security alerts.",
        organizerId: "usr-sup-01",
        participantIds: ["usr-admin-01", "usr-sup-01", "usr-mem-01"],
        startTime: tomorrow,
        endTime: new Date(new Date(tomorrow).getTime() + 45 * 60000).toISOString(),
        provider: "internal",
        createdAt: dayAgo,
      },
    ],
    integrations: [
      {
        provider: "google",
        connected: false,
        scopes: [],
        note: "Google is not connected. Paste a real OAuth access token, or schedule with an internal room / join link.",
      },
      {
        provider: "zoom",
        connected: false,
        scopes: [],
        note: "Zoom is not connected. Provide Account ID, Client ID, and Client Secret, or paste a join link.",
      },
    ],
    notifications: [
      note("notif-01", "usr-sup-01", "application", "New application ready", "Lina Haddad submitted her onboarding application.", hourAgo, "dashboard"),
      note("notif-02", "usr-mem-01", "assessment", "Assessment waiting", "Full-Stack Architecture assessment is assigned to you.", hourAgo, "assessments"),
      note("notif-03", "usr-admin-01", "security", "Unusual mobile session", "Lina Haddad has an active iOS session flagged as unusual.", dayAgo, "security"),
    ],
    auditLogs: [
      audit("aud-01", "usr-admin-01", "SECURITY_POLICY_INIT", "system", "kaviro", "Initialized RBAC and session audit logging.", dayAgo),
      audit("aud-02", "usr-sup-01", "ASSESSMENT_CREATED", "assessment", "asm-eng-01", "Published the architecture readiness assessment.", dayAgo),
    ],
    captchas: [] as Array<{ id: string; answer: string }>,
  };
}

function doneOnboarding() {
  return {
    profileCompleted: true,
    cvCompleted: true,
    humanVerified: true,
    assessmentCompleted: true,
    applicationSubmitted: true,
  };
}

function task(
  id: string,
  projectId: string,
  title: string,
  assigneeId: string,
  reporterId: string,
  status: string,
  priority: string,
  progress: number,
  deadline: string,
  createdAt: string,
  updatedAt: string,
  comments: any[] = [],
) {
  return {
    id,
    projectId,
    title,
    description: title,
    assigneeId,
    reporterId,
    status,
    priority,
    progress,
    deadline: deadline.slice(0, 10),
    comments,
    createdAt,
    updatedAt,
  };
}

function note(id: string, userId: string, category: string, title: string, body: string, createdAt: string, targetTab: string) {
  return { id, userId, category, title, body, read: false, createdAt, targetTab };
}

function audit(id: string, actorId: string, action: string, targetType: string, targetId: string, details: string, createdAt: string) {
  return { id, actorId, action, targetType, targetId, details, ipAddress: "workspace", createdAt };
}

function getDb() {
  if (cache) return cache;
  if (typeof localStorage !== "undefined") {
    try {
      const raw = localStorage.getItem(DB_KEY);
      if (raw) {
        cache = JSON.parse(raw);
        if (cache?.users?.length) return cache;
      }
    } catch {
      /* reseed */
    }
  }
  cache = seed();
  saveDb();
  return cache;
}

function saveDb() {
  if (typeof localStorage === "undefined" || !cache) return;
  try {
    localStorage.setItem(DB_KEY, JSON.stringify(cache));
  } catch {
    /* quota — keep the in-memory workspace */
  }
}

function notify(userId: string, category: string, title: string, body: string, targetTab?: string) {
  const db = getDb();
  const item = {
    id: uid("ntf"),
    userId,
    category,
    title,
    body,
    read: false,
    createdAt: nowIso(),
    targetTab,
  };
  db.notifications.unshift(item);
  emitLive("notification:new", item);
  return item;
}

function addAudit(actorId: string, action: string, targetType: string, targetId: string, details: string) {
  const db = getDb();
  db.auditLogs.unshift(audit(uid("aud"), actorId, action, targetType, targetId, details, nowIso()));
  if (db.auditLogs.length > 200) db.auditLogs.length = 200;
}

function privileged(user: any) {
  return user.role === "admin" || user.role === "supervisor";
}

function hasPerm(user: any, perm: keyof Perms) {
  if (user.role === "admin") return true;
  if (user.role === "supervisor") return Boolean((user.supervisorPermissions || DEFAULT_PERMS)[perm]);
  return false;
}

function requirePerm(user: any, perm: keyof Perms) {
  if (!hasPerm(user, perm)) fail(403, `Missing permission: ${perm}`);
}

function auth() {
  const token = getAuthToken();
  if (!token) fail(401, "Authentication required");
  const db = getDb();
  const tokenHash = hashToken(token);
  const session = db.sessions.find((s: any) => s.tokenHash === tokenHash && s.status === "active");
  if (!session) fail(401, "Session expired or revoked");
  const user = db.users.find((u: any) => u.id === session.userId);
  if (!user) fail(401, "Account not found");
  if (user.status === "suspended" || user.status === "rejected") {
    fail(403, "Account access is suspended or rejected");
  }
  session.lastActivityAt = nowIso();
  user.lastActiveAt = session.lastActivityAt;
  if (!online.has(user.id)) {
    online.add(user.id);
    presence();
  }
  return { db, user, session };
}

function createSession(user: any) {
  const db = getDb();
  const rawToken = uid("tok") + uid("sec");
  const ua = parseUa();
  const past = db.sessions.filter((s: any) => s.userId === user.id);
  const known = past.some((s: any) => s.browser === ua.browser && s.os === ua.os && !s.isUnusual);
  const isUnusual = past.length > 0 && !known;
  const session = {
    id: uid("ses"),
    userId: user.id,
    tokenHash: hashToken(rawToken),
    deviceType: ua.deviceType,
    browser: ua.browser,
    os: ua.os,
    ipAddress: "workspace",
    loginAt: nowIso(),
    lastActivityAt: nowIso(),
    status: "active",
    isUnusual,
    alertReason: isUnusual ? `New ${ua.os} / ${ua.browser} sign-in` : undefined,
  };
  db.sessions.unshift(session);
  online.add(user.id);
  if (isUnusual) {
    for (const sup of db.users.filter((u: any) => privileged(u))) {
      notify(sup.id, "security", "Unusual login", `${user.fullName} signed in from ${ua.browser} on ${ua.os}.`, "security");
    }
  }
  presence();
  return rawToken;
}

function revokeSession(session: any, actorName: string) {
  session.status = "revoked";
  session.logoutAt = nowIso();
  const token = getAuthToken();
  const affectsCurrent = Boolean(token && session.tokenHash === hashToken(token));
  if (affectsCurrent) online.delete(session.userId);
  emitLive("session:revoked", { userId: session.userId, sessionId: session.id, affectsCurrent, actorName });
  presence();
}

function publicUser(user: any, viewer: any) {
  const safe = sanitize(user);
  if (privileged(viewer) || user.id === viewer.id) return { ...safe, isOnline: online.has(user.id) };
  return {
    id: safe.id,
    fullName: safe.fullName,
    email: safe.email,
    desiredRole: safe.desiredRole,
    department: safe.department,
    skills: safe.skills,
    role: safe.role,
    status: safe.status,
    avatarUrl: safe.avatarUrl,
    isOnline: online.has(user.id),
  };
}

function analyticsFor(user: any) {
  const db = getDb();
  const names = new Map(db.users.map((u: any) => [u.id, u.fullName]));
  const graded = db.attempts.filter((a: any) => a.status === "graded" && a.maxScore > 0);
  const avg =
    graded.length > 0
      ? Math.round(graded.reduce((acc: number, a: any) => acc + (a.totalScore / a.maxScore) * 100, 0) / graded.length)
      : 0;
  const logs = (privileged(user) ? db.auditLogs : db.auditLogs.filter((l: any) => l.actorId === user.id))
    .slice(0, 40)
    .map((log: any) => ({ ...log, actorName: names.get(log.actorId) || "System" }));
  return {
    memberStats: {
      total: db.users.length,
      approved: db.users.filter((u: any) => u.status === "approved").length,
      pending: db.users.filter((u: any) => u.status === "pending").length,
      humanVerified: db.users.filter((u: any) => u.humanVerified).length,
    },
    taskStats: {
      total: db.tasks.length,
      backlog: db.tasks.filter((t: any) => t.status === "backlog").length,
      inProgress: db.tasks.filter((t: any) => t.status === "in_progress").length,
      inReview: db.tasks.filter((t: any) => t.status === "in_review").length,
      done: db.tasks.filter((t: any) => t.status === "done").length,
    },
    assessmentStats: {
      totalAssessments: db.assessments.length,
      totalAttempts: db.attempts.length,
      pendingReviews: db.attempts.filter((a: any) => a.status === "pending_review").length,
      avgScorePct: avg,
    },
    securityStats: {
      activeSessions: db.sessions.filter((s: any) => s.status === "active").length,
      unusualAlerts: db.sessions.filter((s: any) => s.status === "active" && s.isUnusual).length,
    },
    projectProgress: db.projects.map((p: any) => {
      const pTasks = db.tasks.filter((t: any) => t.projectId === p.id);
      const progress = pTasks.length ? Math.round(pTasks.reduce((s: number, t: any) => s + t.progress, 0) / pTasks.length) : 0;
      return { id: p.id, name: p.name, taskCount: pTasks.length, progress };
    }),
    auditLogs: logs,
  };
}

function assistantReply(user: any, message: string) {
  const db = getDb();
  const text = message.toLowerCase();
  const ar = /[\u0600-\u06FF]/.test(message) || user.preferredLanguage === "ar";
  const tasks = db.tasks.filter((t: any) => privileged(user) || t.assigneeId === user.id || t.reporterId === user.id);
  const open = tasks.filter((t: any) => t.status !== "done");
  const meetings = db.meetings.filter((m: any) => privileged(user) || m.participantIds.includes(user.id));
  const pending = db.users.filter((u: any) => u.status === "pending");
  const unusual = db.sessions.filter((s: any) => s.status === "active" && s.isUnusual);
  const cv = db.cvs.find((c: any) => c.userId === user.id);

  if (/assess|اختبار|تقييم/.test(text)) {
    const mine = db.attempts.filter((a: any) => a.userId === user.id);
    return ar
      ? `عندك ${mine.length} محاولة. ابدأ من شاشة الاختبارات بعد التحقق البشري. الأسئلة الموضوعية تُصحح فوراً، والمقالية تنتظر المشرف.`
      : `You have ${mine.length} attempt(s). Open Assessments, pass the human check, then start. Multiple choice is graded instantly; written answers wait for a supervisor.`;
  }
  if (/task|مهم/.test(text)) {
    const titles = open.slice(0, 4).map((t: any) => `${t.title} (${t.status}, due ${t.deadline})`).join(ar ? "، " : "; ");
    return ar
      ? `المهام المفتوحة: ${open.length}. ${titles || "لا توجد مهام مفتوحة."}`
      : `Open tasks: ${open.length}. ${titles || "Nothing open right now."}`;
  }
  if (/meet|اجتماع/.test(text)) {
    const next = meetings[0];
    return ar
      ? next
        ? `أقرب اجتماع: ${next.title} في ${new Date(next.startTime).toLocaleString()}.`
        : "لا توجد اجتماعات على جدولك."
      : next
        ? `Next meeting: ${next.title} at ${new Date(next.startTime).toLocaleString()}.`
        : "No meetings on your calendar.";
  }
  if (/cv|سيرة|resume/.test(text)) {
    return ar
      ? cv
        ? `سيرتك محفوظة بعنوان «${cv.headline}». افتح منشئ السيرة ثم شغّل التحليل لسد الثغرات قبل الاعتماد.`
        : "لا توجد سيرة بعد. افتح منشئ السيرة، املأ العنوان والملخص، ثم احفظ."
      : cv
        ? `Your CV is saved as “${cv.headline}”. Run AI analysis in the CV builder before you apply the draft.`
        : "No CV yet. Open the CV builder, add a headline and summary, then save.";
  }
  if (/secur|جلسة|أمان|login/.test(text)) {
    return ar
      ? `الجلسات النشطة غير المعتادة: ${unusual.length}. الإنهاء الفوري متاح من شاشة الجلسات والأمان لحسابك أو للفريق إذا كنت مشرفاً.`
      : `Unusual active sessions: ${unusual.length}. Force logout is on Sessions & Security — your own devices, or the whole team if you are a supervisor.`;
  }
  if (privileged(user) && /pending|موافق|طلب|approv/.test(text)) {
    return ar
      ? `طلبات بانتظار الموافقة: ${pending.length}${pending[0] ? ` — ${pending.map((u: any) => u.fullName).join("، ")}` : ""}.`
      : `Pending approvals: ${pending.length}${pending[0] ? ` — ${pending.map((u: any) => u.fullName).join(", ")}` : ""}.`;
  }
  return ar
    ? `أنا مساعد KAVIRO. أقدر أساعدك في السيرة، الاختبارات (${db.assessments.length})، المهام المفتوحة (${open.length})، والاجتماعات (${meetings.length}). اسأل عن أي شاشة بالاسم.`
    : `I am KAVIRO AI for this workspace. I can help with your CV, ${db.assessments.length} assessments, ${open.length} open tasks, and ${meetings.length} meetings. Ask about a screen by name.`;
}

function analyzeCv(cv: any, language: string) {
  const ar = language === "ar";
  const missing: string[] = [];
  if (!cv?.headline) missing.push(ar ? "العنوان المهني" : "Professional headline");
  if (!cv?.summary || String(cv.summary).length < 40) missing.push(ar ? "ملخص أقوى (٤٠+ حرف)" : "A fuller summary (40+ characters)");
  if (!cv?.experience?.length) missing.push(ar ? "خبرة عملية واحدة على الأقل" : "At least one role");
  if (!cv?.technicalSkills?.length) missing.push(ar ? "مهارات تقنية" : "Technical skills");
  const skills = (cv?.technicalSkills || []).filter(Boolean);
  return {
    overallReadiness: missing.length === 0 ? (ar ? "جاهزة للمراجعة" : "Ready for review") : ar ? "تحتاج استكمال" : "Needs a pass",
    missingInformation: missing.length ? missing : [ar ? "لا نواقص جوهرية" : "No critical gaps"],
    followUpQuestions: [
      ar ? "ما النتيجة الرقمية الأهم في آخر مشروع؟" : "What is the most concrete metric from your latest project?",
      ar ? "ما الأدوات التي استخدمتها يومياً؟" : "Which tools did you use every day?",
    ],
    grammarAndWordingFixes: [
      ar ? "ابدأ كل نقطة خبرة بفعل قوي ورقم." : "Start each experience bullet with a strong verb and a number.",
      ar ? "اجعل العنوان دوراً لا جملة." : "Keep the headline to a role, not a sentence.",
    ],
    projectSuggestions: (cv?.projects || []).slice(0, 2).map((p: any) => ({
      projectName: p.name,
      improvedSummary: p.summary || (ar ? "صف المشكلة والحل في سطرين." : "Describe the problem and the fix in two lines."),
      improvedImpact: p.impact || (ar ? "أضف نسبة أو حجماً (مستخدمون، زمن، أخطاء)." : "Add a scale: users, time saved, or errors removed."),
    })),
    improvedDraft: {
      headline: cv?.headline || (ar ? "مهندس برمجيات" : "Software engineer"),
      summary:
        cv?.summary && String(cv.summary).length > 40
          ? cv.summary
          : ar
            ? "مهندس يبني منتجات ويب ثنائية اللغة مع تركيز على الاعتمادية وتجربة الفريق."
            : "Engineer building bilingual web products with a focus on reliability and team workflows.",
      technicalSkills: skills.length ? skills : ["TypeScript", "React"],
      softSkills: cv?.softSkills?.length ? cv.softSkills : ar ? ["تواصل", "ملكية"] : ["Communication", "Ownership"],
    },
  };
}

function decodeBase64(b64: string) {
  const bin = atob(b64.replace(/\s/g, ""));
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

function printable(bytes: Uint8Array) {
  let run = "";
  let out = "";
  for (const b of bytes) {
    if (b >= 32 && b < 127) run += String.fromCharCode(b);
    else {
      if (run.length > 5) out += `${run} `;
      run = "";
    }
  }
  if (run.length > 5) out += run;
  return out.replace(/\s+/g, " ").trim().slice(0, 6000);
}

function crc32(data: Uint8Array) {
  let c = ~0;
  for (const b of data) {
    c ^= b;
    for (let i = 0; i < 8; i++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1;
  }
  return ~c >>> 0;
}

function u16(n: number) {
  return [n & 255, (n >> 8) & 255];
}
function u32(n: number) {
  return [n & 255, (n >> 8) & 255, (n >> 16) & 255, (n >> 24) & 255];
}

function buildZip(files: Array<{ name: string; text: string }>) {
  const parts: number[] = [];
  const central: number[] = [];
  let offset = 0;
  for (const file of files) {
    const nameBytes = new TextEncoder().encode(file.name);
    const data = new TextEncoder().encode(file.text);
    const crc = crc32(data);
    const local = [
      ...u32(0x04034b50),
      ...u16(20),
      ...u16(0),
      ...u16(0),
      ...u16(0),
      ...u16(0),
      ...u32(crc),
      ...u32(data.length),
      ...u32(data.length),
      ...u16(nameBytes.length),
      ...u16(0),
      ...nameBytes,
      ...data,
    ];
    parts.push(...local);
    central.push(
      ...u32(0x02014b50),
      ...u16(20),
      ...u16(20),
      ...u16(0),
      ...u16(0),
      ...u16(0),
      ...u16(0),
      ...u32(crc),
      ...u32(data.length),
      ...u32(data.length),
      ...u16(nameBytes.length),
      ...u16(0),
      ...u16(0),
      ...u16(0),
      ...u16(0),
      ...u32(0),
      ...u32(offset),
      ...nameBytes,
    );
    offset += local.length;
  }
  const end = [
    ...u32(0x06054b50),
    ...u16(0),
    ...u16(0),
    ...u16(files.length),
    ...u16(files.length),
    ...u32(central.length),
    ...u32(offset),
    ...u16(0),
  ];
  return new Uint8Array([...parts, ...central, ...end]);
}

export async function buildWorkspaceZip(): Promise<Blob> {
  const db = getDb();
  const snapshot = {
    members: db.users.map((u: any) => ({ name: u.fullName, email: u.email, role: u.role, status: u.status })),
    projects: db.projects.map((p: any) => p.name),
    tasks: db.tasks.map((t: any) => ({ title: t.title, status: t.status })),
    meetings: db.meetings.map((m: any) => ({ title: m.title, start: m.startTime })),
  };
  const readme = [
    "KAVIRO workspace package",
    "",
    "This archive is a portable snapshot of the live KAVIRO team workspace.",
    "Demo sign-in password: Kaviro@2026",
    "Accounts: admin@kaviro.ai · supervisor@kaviro.ai · member@kaviro.ai",
    "",
    "Screens: Dashboard, Design System, CV Builder, Assessments, Messages,",
    "Tasks, Meetings, Sessions & Security, Reports, Profile.",
  ].join("\n");
  const bytes = buildZip([
    { name: "README.txt", text: readme },
    { name: "workspace-snapshot.json", text: JSON.stringify(snapshot, null, 2) },
  ]);
  return new Blob([bytes], { type: "application/zip" });
}

function csvReport() {
  const db = getDb();
  const rows = [
    ["Type", "ID", "Title", "Status", "Owner", "Timestamp"].join(","),
    ...db.users.map((u: any) => ["Member", u.id, `"${u.fullName}"`, u.status, u.role, u.createdAt].join(",")),
    ...db.tasks.map((t: any) => ["Task", t.id, `"${t.title}"`, t.status, `${t.progress}%`, t.updatedAt].join(",")),
    ...db.attempts.map((a: any) =>
      ["AssessmentAttempt", a.id, a.assessmentId, a.status, `${a.totalScore}/${a.maxScore}`, a.startedAt].join(","),
    ),
  ];
  return rows.join("\n");
}

function icsFor(id: string) {
  const { db } = auth();
  const m = db.meetings.find((item: any) => item.id === id);
  if (!m) fail(404, "Meeting not found");
  const fmt = (iso: string) => iso.replace(/[-:]/g, "").replace(/\.\d+Z$/, "Z");
  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//KAVIRO//Team Workspace//EN",
    "BEGIN:VEVENT",
    `UID:${m.id}@kaviro.ai`,
    `DTSTAMP:${fmt(m.createdAt)}`,
    `DTSTART:${fmt(m.startTime)}`,
    `DTEND:${fmt(m.endTime)}`,
    `SUMMARY:${m.title}`,
    `DESCRIPTION:${(m.description || "").replace(/\n/g, " ")}`,
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");
}

function match(pathname: string, pattern: string) {
  const a = pathname.split("/").filter(Boolean);
  const b = pattern.split("/").filter(Boolean);
  if (a.length !== b.length) return null;
  const params: Record<string, string> = {};
  for (let i = 0; i < b.length; i++) {
    if (b[i].startsWith(":")) params[b[i].slice(1)] = decodeURIComponent(a[i]);
    else if (a[i] !== b[i]) return null;
  }
  return params;
}

export async function dispatch(method: string, path: string, body: any = {}): Promise<any> {
  const url = new URL(path, "http://kaviro.local");
  const pathname = url.pathname.replace(/\/$/, "") || "/";
  const q = url.searchParams;
  const m = method.toUpperCase();

  try {
    if (m === "GET" && pathname === "/api/analytics/export.csv") {
      auth();
      return { __text: csvReport(), __mime: "text/csv" };
    }
    const ics = match(pathname, "/api/meetings/:id/ics");
    if (m === "GET" && ics) return { __text: icsFor(ics.id), __mime: "text/calendar" };

    if (m === "POST" && pathname === "/api/auth/register") {
      const db = getDb();
      const { fullName, email, password, phone, whatsapp, avatarUrl, desiredRole, department, skills, interests, preferredLanguage } = body || {};
      if (!fullName || !email || !password || !phone || !desiredRole) {
        fail(400, "Full name, email, password, phone, and desired role are required.");
      }
      if (String(password).length < 8) fail(400, "Password must be at least 8 characters long.");
      const normalized = String(email).trim().toLowerCase();
      if (db.users.some((u: any) => u.email.toLowerCase() === normalized)) {
        fail(409, "An account with this email already exists.");
      }
      const verificationCode = code6();
      const user = {
        id: uid("usr"),
        fullName: String(fullName).trim(),
        email: normalized,
        passwordHash: hashPassword(String(password)),
        phone: String(phone).trim(),
        whatsapp: whatsapp ? String(whatsapp).trim() : undefined,
        avatarUrl: avatarUrl || undefined,
        desiredRole: String(desiredRole).trim(),
        department: department ? String(department).trim() : "General Operations",
        skills: Array.isArray(skills) ? skills.map(String) : [],
        interests: Array.isArray(interests) ? interests.map(String) : [],
        role: "member" as Role,
        status: "pending",
        emailVerified: false,
        emailVerificationCode: verificationCode,
        twoFactorEnabled: false,
        humanVerified: false,
        onboarding: {
          profileCompleted: true,
          cvCompleted: false,
          humanVerified: false,
          assessmentCompleted: false,
          applicationSubmitted: false,
        },
        preferredLanguage: preferredLanguage === "ar" ? "ar" : "en",
        createdAt: nowIso(),
        lastActiveAt: nowIso(),
      };
      db.users.push(user);
      addAudit(user.id, "USER_REGISTERED", "user", user.id, `New member registered: ${user.email}`);
      for (const sup of db.users.filter((u: any) => privileged(u) && u.id !== user.id)) {
        notify(sup.id, "application", "New member registration", `${user.fullName} (${user.desiredRole}) is completing onboarding.`, "dashboard");
      }
      touch();
      return { requiresEmailVerification: true, email: user.email, verificationCodePreview: verificationCode };
    }

    if (m === "POST" && pathname === "/api/auth/verify-email") {
      const db = getDb();
      const user = db.users.find((u: any) => u.email.toLowerCase() === String(body?.email || "").trim().toLowerCase());
      if (!user) fail(404, "Account not found.");
      if (!user.emailVerified && user.emailVerificationCode !== String(body?.code || "").trim()) {
        fail(400, "Invalid verification code.");
      }
      user.emailVerified = true;
      user.emailVerificationCode = undefined;
      const token = createSession(user);
      addAudit(user.id, "EMAIL_VERIFIED", "user", user.id, "Email verified");
      touch();
      return { token, user: sanitize(user) };
    }

    if (m === "POST" && pathname === "/api/auth/login") {
      const { email, password } = body || {};
      if (!email || !password) fail(400, "Email and password are required.");
      const db = getDb();
      const user = db.users.find((u: any) => u.email.toLowerCase() === String(email).trim().toLowerCase());
      if (!user || user.passwordHash !== hashPassword(String(password))) fail(401, "Invalid email or password.");
      if (user.status === "suspended" || user.status === "rejected") fail(403, "This account is suspended or rejected.");
      if (!user.emailVerified) {
        user.emailVerificationCode = user.emailVerificationCode || code6();
        touch();
        fail(403, "Email verification required.", {
          requiresEmailVerification: true,
          email: user.email,
          verificationCodePreview: user.emailVerificationCode,
        });
      }
      if (user.twoFactorEnabled) {
        user.twoFactorSecret = code6();
        touch();
        return { requiresTwoFactor: true, email: user.email, twoFactorCodePreview: user.twoFactorSecret };
      }
      const token = createSession(user);
      addAudit(user.id, "USER_LOGIN", "user", user.id, "Signed in");
      touch();
      return { token, user: sanitize(user) };
    }

    if (m === "POST" && pathname === "/api/auth/verify-2fa") {
      const db = getDb();
      const user = db.users.find((u: any) => u.email.toLowerCase() === String(body?.email || "").trim().toLowerCase());
      if (!user || !user.twoFactorEnabled) fail(400, "2FA challenge not active.");
      if (user.twoFactorSecret !== String(body?.code || "").trim()) fail(401, "Invalid 2FA verification code.");
      user.twoFactorSecret = undefined;
      const token = createSession(user);
      addAudit(user.id, "USER_LOGIN_2FA", "user", user.id, "Completed 2FA sign-in");
      touch();
      return { token, user: sanitize(user) };
    }

    if (m === "POST" && pathname === "/api/auth/forgot-password") {
      const db = getDb();
      const user = db.users.find((u: any) => u.email.toLowerCase() === String(body?.email || "").trim().toLowerCase());
      if (!user) return { message: "If an account matches that email, a recovery code has been issued." };
      user.resetPasswordCode = code6();
      touch();
      return { message: "Password recovery code issued.", resetCodePreview: user.resetPasswordCode };
    }

    if (m === "POST" && pathname === "/api/auth/reset-password") {
      const { email, code, newPassword } = body || {};
      if (!email || !code || !newPassword || String(newPassword).length < 8) {
        fail(400, "Valid email, code, and 8+ character password are required.");
      }
      const db = getDb();
      const user = db.users.find((u: any) => u.email.toLowerCase() === String(email).trim().toLowerCase());
      if (!user || user.resetPasswordCode !== String(code).trim()) fail(400, "Invalid recovery code.");
      user.passwordHash = hashPassword(String(newPassword));
      user.resetPasswordCode = undefined;
      addAudit(user.id, "PASSWORD_RESET", "user", user.id, "Password reset completed");
      touch();
      return { ok: true };
    }

    if (m === "POST" && pathname === "/api/auth/logout") {
      const { db, user, session } = auth();
      session.status = "logged_out";
      session.logoutAt = nowIso();
      online.delete(user.id);
      addAudit(user.id, "USER_LOGOUT", "session", session.id, "Signed out");
      presence();
      touch();
      return { ok: true };
    }

    if (m === "GET" && pathname === "/api/auth/me") {
      const { user, session } = auth();
      return { user: sanitize(user), sessionId: session.id };
    }

    if (m === "PATCH" && pathname === "/api/auth/profile") {
      const { db, user } = auth();
      if (body.email) {
        const normalized = String(body.email).trim().toLowerCase();
        if (db.users.some((u: any) => u.id !== user.id && u.email.toLowerCase() === normalized)) {
          fail(409, "That email address is already in use by another account.");
        }
        user.email = normalized;
      }
      if (body.fullName) user.fullName = String(body.fullName).trim();
      if (body.phone) user.phone = String(body.phone).trim();
      if (body.whatsapp !== undefined) user.whatsapp = body.whatsapp ? String(body.whatsapp).trim() : undefined;
      if (body.avatarUrl !== undefined) user.avatarUrl = body.avatarUrl || undefined;
      if (body.desiredRole) user.desiredRole = String(body.desiredRole).trim();
      if (body.department) user.department = String(body.department).trim();
      if (Array.isArray(body.skills)) user.skills = body.skills.map(String);
      if (Array.isArray(body.interests)) user.interests = body.interests.map(String);
      if (body.bio !== undefined) user.bio = String(body.bio);
      if (body.preferredLanguage === "ar" || body.preferredLanguage === "en") user.preferredLanguage = body.preferredLanguage;
      user.onboarding = user.onboarding || {};
      user.onboarding.profileCompleted = Boolean(user.fullName && user.phone && user.desiredRole);
      addAudit(user.id, "PROFILE_UPDATED", "user", user.id, "Updated profile");
      touch();
      return { user: sanitize(user) };
    }

    if (m === "POST" && pathname === "/api/auth/change-password") {
      const { user } = auth();
      if (!body?.currentPassword || !body?.newPassword || String(body.newPassword).length < 8) {
        fail(400, "Current password and an 8+ character new password are required.");
      }
      if (user.passwordHash !== hashPassword(String(body.currentPassword))) fail(401, "Current password is incorrect.");
      user.passwordHash = hashPassword(String(body.newPassword));
      addAudit(user.id, "PASSWORD_CHANGED", "user", user.id, "Updated password");
      touch();
      return { ok: true };
    }

    if (m === "POST" && pathname === "/api/auth/2fa/toggle") {
      const { user } = auth();
      user.twoFactorEnabled = Boolean(body?.enabled);
      addAudit(user.id, user.twoFactorEnabled ? "2FA_ENABLED" : "2FA_DISABLED", "user", user.id, "2FA toggled");
      touch();
      return { user: sanitize(user) };
    }

    if (m === "POST" && pathname === "/api/auth/onboarding/submit") {
      const { db, user } = auth();
      user.onboarding = user.onboarding || {};
      user.onboarding.applicationSubmitted = true;
      addAudit(user.id, "APPLICATION_SUBMITTED", "user", user.id, "Submitted application");
      for (const sup of db.users.filter((u: any) => privileged(u))) {
        notify(sup.id, "application", "Application submitted", `${user.fullName} submitted their onboarding application.`, "dashboard");
      }
      touch();
      return { user: sanitize(user) };
    }

    if (m === "GET" && pathname === "/api/users") {
      const { db, user } = auth();
      return { users: db.users.map((u: any) => publicUser(u, user)) };
    }

    const statusRoute = match(pathname, "/api/admin/users/:id/status");
    if (m === "PATCH" && statusRoute) {
      const { db, user } = auth();
      requirePerm(user, "canApproveMembers");
      if (!["approved", "pending", "rejected", "suspended"].includes(body?.status)) fail(400, "Invalid status");
      const target = db.users.find((u: any) => u.id === statusRoute.id);
      if (!target) fail(404, "User not found");
      if (target.role === "admin" && user.role !== "admin") fail(403, "Only administrators can modify administrator accounts.");
      target.status = body.status;
      if (body.status === "suspended" || body.status === "rejected") {
        for (const s of db.sessions) {
          if (s.userId === target.id && s.status === "active") revokeSession(s, user.fullName);
        }
      }
      addAudit(user.id, "USER_STATUS_CHANGED", "user", target.id, `Status → ${body.status}`);
      notify(target.id, "application", `Account ${body.status}`, `${user.fullName} set your status to ${body.status}.`, "dashboard");
      touch();
      return { user: sanitize(target) };
    }

    const roleRoute = match(pathname, "/api/admin/users/:id/role");
    if (m === "PATCH" && roleRoute) {
      const { db, user } = auth();
      if (user.role !== "admin") fail(403, "Insufficient permissions for this action");
      if (!["member", "supervisor", "admin"].includes(body?.role)) fail(400, "Invalid role");
      const target = db.users.find((u: any) => u.id === roleRoute.id);
      if (!target) fail(404, "User not found");
      if (target.id === user.id && body.role !== "admin") fail(400, "You cannot demote your own administrator account.");
      target.role = body.role;
      if (body.role === "supervisor" && !target.supervisorPermissions) target.supervisorPermissions = { ...DEFAULT_PERMS };
      addAudit(user.id, "USER_ROLE_CHANGED", "user", target.id, `Role → ${body.role}`);
      notify(target.id, "security", `Role updated: ${body.role}`, `${user.fullName} updated your role.`, "security");
      touch();
      return { user: sanitize(target) };
    }

    const permRoute = match(pathname, "/api/admin/users/:id/permissions");
    if (m === "PATCH" && permRoute) {
      const { db, user } = auth();
      if (user.role !== "admin") fail(403, "Insufficient permissions for this action");
      const target = db.users.find((u: any) => u.id === permRoute.id);
      if (!target) fail(404, "User not found");
      const incoming = body?.permissions || {};
      target.supervisorPermissions = {
        canApproveMembers: Boolean(incoming.canApproveMembers),
        canManageAssessments: Boolean(incoming.canManageAssessments),
        canViewSessions: Boolean(incoming.canViewSessions),
        canRevokeSessions: Boolean(incoming.canRevokeSessions),
        canManageTasksAndGroups: Boolean(incoming.canManageTasksAndGroups),
        canViewAnalytics: Boolean(incoming.canViewAnalytics),
        canManageIntegrations: Boolean(incoming.canManageIntegrations),
      };
      addAudit(user.id, "SUPERVISOR_PERMISSIONS_UPDATED", "user", target.id, `Updated permissions for ${target.fullName}`);
      touch();
      return { user: sanitize(target) };
    }

    const delUser = match(pathname, "/api/admin/users/:id");
    if (m === "DELETE" && delUser && !pathname.includes("/status") && !pathname.includes("/role")) {
      const { db, user } = auth();
      if (user.role !== "admin") fail(403, "Insufficient permissions for this action");
      if (delUser.id === user.id) fail(400, "You cannot delete your own currently signed-in administrator account.");
      const idx = db.users.findIndex((u: any) => u.id === delUser.id);
      if (idx < 0) fail(404, "User not found");
      const removed = db.users[idx];
      for (const s of db.sessions) {
        if (s.userId === removed.id && s.status === "active") revokeSession(s, user.fullName);
      }
      db.users.splice(idx, 1);
      addAudit(user.id, "USER_DELETED", "user", removed.id, `Removed ${removed.email}`);
      touch();
      return { ok: true };
    }

    if (m === "GET" && pathname === "/api/sessions") {
      const { db, user, session } = auth();
      const canViewAll = hasPerm(user, "canViewSessions");
      const sessions = db.sessions
        .filter((s: any) => canViewAll || s.userId === user.id)
        .map((s: any) => {
          const owner = db.users.find((u: any) => u.id === s.userId);
          return {
            id: s.id,
            userId: s.userId,
            userName: owner?.fullName || "Unknown user",
            userEmail: owner?.email || "",
            userRole: owner?.role || "member",
            deviceType: s.deviceType,
            browser: s.browser,
            os: s.os,
            ipAddress: s.ipAddress,
            loginAt: s.loginAt,
            logoutAt: s.logoutAt,
            lastActivityAt: s.lastActivityAt,
            status: s.status,
            isUnusual: s.isUnusual,
            alertReason: s.alertReason,
            isCurrent: s.id === session.id,
          };
        });
      return { sessions };
    }

    const delSession = match(pathname, "/api/sessions/:id");
    if (m === "DELETE" && delSession) {
      const { db, user } = auth();
      const target = db.sessions.find((s: any) => s.id === delSession.id);
      if (!target) fail(404, "Session not found");
      if (!hasPerm(user, "canRevokeSessions") && target.userId !== user.id) fail(403, "Not authorized to revoke this session");
      const owner = db.users.find((u: any) => u.id === target.userId);
      if (owner?.role === "admin" && user.role !== "admin" && target.userId !== user.id) {
        fail(403, "Only an Administrator can revoke an Administrator session.");
      }
      revokeSession(target, user.fullName);
      addAudit(user.id, "SESSION_REVOKED", "session", target.id, `Revoked ${target.browser} on ${target.os}`);
      notify(target.userId, "security", "Session terminated", `${user.fullName} revoked a ${target.browser} session.`, "security");
      touch();
      return { ok: true };
    }

    const revokeUser = match(pathname, "/api/sessions/revoke-user/:userId");
    if (m === "POST" && revokeUser) {
      const { db, user, session } = auth();
      requirePerm(user, "canRevokeSessions");
      const targetUser = db.users.find((u: any) => u.id === revokeUser.userId);
      if (!targetUser) fail(404, "User not found");
      if (targetUser.role === "admin" && user.role !== "admin") {
        fail(403, "Only an Administrator can revoke an Administrator’s devices.");
      }
      let revokedCount = 0;
      for (const s of db.sessions) {
        if (s.userId === targetUser.id && s.status === "active" && s.id !== session.id) {
          revokeSession(s, user.fullName);
          revokedCount++;
        }
      }
      addAudit(user.id, "USER_ALL_SESSIONS_REVOKED", "user", targetUser.id, `Revoked ${revokedCount} devices`);
      touch();
      return { ok: true, revokedCount };
    }

    if (m === "GET" && pathname === "/api/cv") {
      const { db, user } = auth();
      const cv = db.cvs.find((c: any) => c.userId === user.id) || null;
      return { cv };
    }

    if (m === "POST" && pathname === "/api/cv") {
      const { db, user } = auth();
      const idx = db.cvs.findIndex((c: any) => c.userId === user.id);
      const record = {
        id: idx >= 0 ? db.cvs[idx].id : uid("cv"),
        userId: user.id,
        fullName: body.fullName || user.fullName,
        headline: body.headline || user.desiredRole,
        email: body.email || user.email,
        phone: body.phone || user.phone || "",
        location: body.location || "",
        summary: body.summary || "",
        education: Array.isArray(body.education) ? body.education : [],
        experience: Array.isArray(body.experience) ? body.experience : [],
        projects: Array.isArray(body.projects) ? body.projects : [],
        achievements: Array.isArray(body.achievements) ? body.achievements : [],
        technicalSkills: Array.isArray(body.technicalSkills) ? body.technicalSkills : [],
        softSkills: Array.isArray(body.softSkills) ? body.softSkills : [],
        uploadedFileName: body.uploadedFileName,
        uploadedFileMime: body.uploadedFileMime,
        rawExtractedText: body.rawExtractedText,
        updatedAt: nowIso(),
      };
      if (idx >= 0) db.cvs[idx] = record;
      else db.cvs.push(record);
      user.onboarding = user.onboarding || {};
      user.onboarding.cvCompleted = true;
      addAudit(user.id, "CV_SAVED", "cv", record.id, "Saved CV");
      touch();
      return { cv: record, onboarding: user.onboarding };
    }

    if (m === "POST" && pathname === "/api/cv/upload") {
      auth();
      const { fileName, mimeType, base64Data } = body || {};
      if (!fileName || !base64Data) fail(400, "File name and file payload are required.");
      let bytes: Uint8Array;
      try {
        bytes = decodeBase64(String(base64Data));
      } catch {
        fail(400, "Could not read the uploaded file.");
      }
      if (bytes!.byteLength > 6 * 1024 * 1024) fail(400, "File exceeds 6 MB limit.");
      const lower = String(fileName).toLowerCase();
      let extractedText = "";
      if (lower.endsWith(".txt") || lower.endsWith(".md")) extractedText = new TextDecoder().decode(bytes!);
      else if (lower.endsWith(".pdf") || lower.endsWith(".docx")) {
        extractedText = printable(bytes!) || `Uploaded ${fileName} (${Math.round(bytes!.byteLength / 1024)} KB).`;
      } else fail(400, "Supported CV formats are PDF, DOCX, TXT, or MD.");
      return {
        fileName,
        mimeType: mimeType || "application/octet-stream",
        extractedText,
        pdfBase64: lower.endsWith(".pdf") ? String(base64Data) : undefined,
      };
    }

    if (m === "POST" && pathname === "/api/ai/cv-analyze") {
      auth();
      return { analysis: analyzeCv(body?.cv || {}, body?.language === "ar" ? "ar" : "en") };
    }

    if (m === "GET" && pathname === "/api/assessments/captcha") {
      const { db } = auth();
      const a = 2 + Math.floor(Math.random() * 8);
      const b = 1 + Math.floor(Math.random() * 8);
      const challenge = { id: uid("cap"), answer: String(a + b) };
      db.captchas = (db.captchas || []).slice(-20);
      db.captchas.push(challenge);
      saveDb();
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="220" height="64" viewBox="0 0 220 64"><rect width="220" height="64" rx="8" fill="#0e1934"/><text x="18" y="40" fill="#00D4FF" font-family="monospace" font-size="22">${a} + ${b} = ?</text></svg>`;
      return { challengeId: challenge.id, svgDataUri: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}` };
    }

    if (m === "POST" && pathname === "/api/assessments/captcha/verify") {
      const { db, user } = auth();
      if (!body?.challengeId || body.answer === undefined || body.answer === "") {
        fail(400, "Challenge ID and answer are required.");
      }
      const challenge = (db.captchas || []).find((c: any) => c.id === body.challengeId);
      if (!challenge || String(challenge.answer) !== String(body.answer).trim()) {
        fail(400, "Incorrect CAPTCHA answer. Please try a new challenge.");
      }
      db.captchas = db.captchas.filter((c: any) => c.id !== challenge.id);
      user.humanVerified = true;
      user.onboarding = user.onboarding || {};
      user.onboarding.humanVerified = true;
      addAudit(user.id, "HUMAN_VERIFIED", "user", user.id, "Passed human verification");
      touch();
      return { verified: true, user: sanitize(user) };
    }

    if (m === "GET" && pathname === "/api/assessments") {
      const { db, user } = auth();
      const isPriv = privileged(user);
      const assessments = db.assessments
        .filter((a: any) => isPriv || a.assignedUserIds.includes(user.id) || a.assignedUserIds.length === 0)
        .map((a: any) => ({
          ...a,
          questions: isPriv ? a.questions : a.questions.map(({ correctAnswer, ...rest }: any) => rest),
        }));
      const attempts = db.attempts.filter((att: any) => isPriv || att.userId === user.id);
      return { assessments, attempts };
    }

    if (m === "POST" && pathname === "/api/assessments") {
      const { db, user } = auth();
      requirePerm(user, "canManageAssessments");
      if (!body?.title || !Array.isArray(body.questions) || body.questions.length === 0) {
        fail(400, "Assessment title and at least one question are required.");
      }
      const assessment = {
        id: uid("asm"),
        title: String(body.title).trim(),
        titleAr: body.titleAr,
        description: String(body.description || ""),
        category: String(body.category || "General"),
        timeLimitMinutes: Number(body.timeLimitMinutes) || 20,
        maxAttempts: Number(body.maxAttempts) || 2,
        passingScore: Number(body.passingScore) || 70,
        assignedUserIds: Array.isArray(body.assignedUserIds) ? body.assignedUserIds.map(String) : [],
        randomizeQuestions: Boolean(body.randomizeQuestions),
        questions: body.questions.map((q: any, idx: number) => ({
          id: q.id || `q-${idx + 1}-${uid("x").slice(-4)}`,
          type: q.type,
          prompt: String(q.prompt),
          promptAr: q.promptAr,
          options: Array.isArray(q.options) ? q.options.map(String) : undefined,
          correctAnswer: q.correctAnswer ? String(q.correctAnswer) : undefined,
          points: Number(q.points) || 10,
        })),
        createdBy: user.id,
        createdAt: nowIso(),
      };
      db.assessments.unshift(assessment);
      for (const id of assessment.assignedUserIds) {
        notify(id, "assessment", "New assessment assigned", `You were assigned “${assessment.title}”.`, "assessments");
      }
      addAudit(user.id, "ASSESSMENT_CREATED", "assessment", assessment.id, assessment.title);
      touch();
      return { assessment };
    }

    const startAsm = match(pathname, "/api/assessments/:id/start");
    if (m === "POST" && startAsm) {
      const { db, user } = auth();
      if (!user.humanVerified) fail(403, "Complete Human Verification (CAPTCHA) before starting an assessment.");
      const assessment = db.assessments.find((a: any) => a.id === startAsm.id);
      if (!assessment) fail(404, "Assessment not found");
      const prior = db.attempts.filter((att: any) => att.assessmentId === assessment.id && att.userId === user.id);
      if (prior.length >= assessment.maxAttempts) {
        fail(400, `Attempt limit (${assessment.maxAttempts}) reached for this assessment.`);
      }
      const questions = [...assessment.questions];
      if (assessment.randomizeQuestions) {
        for (let i = questions.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [questions[i], questions[j]] = [questions[j], questions[i]];
        }
      }
      const attempt = {
        id: uid("att"),
        assessmentId: assessment.id,
        userId: user.id,
        startedAt: nowIso(),
        answers: [],
        autoScore: 0,
        manualScore: 0,
        totalScore: 0,
        maxScore: questions.reduce((sum: number, q: any) => sum + q.points, 0),
        status: "in_progress",
      };
      db.attempts.unshift(attempt);
      touch();
      return { attempt, questions: questions.map(({ correctAnswer, ...rest }: any) => rest) };
    }

    const submitAtt = match(pathname, "/api/assessments/attempts/:attemptId/submit");
    if (m === "POST" && submitAtt) {
      const { db, user } = auth();
      const attempt = db.attempts.find((a: any) => a.id === submitAtt.attemptId && a.userId === user.id);
      if (!attempt) fail(404, "Attempt not found");
      if (attempt.status !== "in_progress") fail(400, "Attempt has already been submitted.");
      const assessment = db.assessments.find((a: any) => a.id === attempt.assessmentId);
      if (!assessment) fail(404, "Assessment not found");
      const submitted = new Map<string, string>(
        (Array.isArray(body?.answers) ? body.answers : []).map((item: any) => [item.questionId, String(item.answer || "")]),
      );
      let autoScore = 0;
      let needsManual = false;
      attempt.answers = assessment.questions.map((q: any) => {
        const answer = submitted.get(q.id) || "";
        if (q.type === "mcq" || q.type === "true_false") {
          const isCorrect = answer.trim().toLowerCase() === String(q.correctAnswer || "").trim().toLowerCase();
          const pts = isCorrect ? q.points : 0;
          autoScore += pts;
          return { questionId: q.id, answer, isCorrect, pointsAwarded: pts };
        }
        needsManual = true;
        return { questionId: q.id, answer, pointsAwarded: 0 };
      });
      attempt.autoScore = autoScore;
      attempt.totalScore = autoScore;
      attempt.submittedAt = nowIso();
      attempt.status = needsManual ? "pending_review" : "graded";
      if (!needsManual) attempt.passed = attempt.maxScore > 0 && (attempt.totalScore / attempt.maxScore) * 100 >= assessment.passingScore;
      user.onboarding = user.onboarding || {};
      user.onboarding.assessmentCompleted = true;
      addAudit(user.id, "ASSESSMENT_SUBMITTED", "attempt", attempt.id, `Submitted ${assessment.title}`);
      if (needsManual) {
        for (const sup of db.users.filter((u: any) => privileged(u))) {
          notify(sup.id, "assessment", "Assessment needs review", `${user.fullName} submitted “${assessment.title}”.`, "assessments");
        }
      }
      touch();
      return { attempt, onboarding: user.onboarding };
    }

    const gradeAtt = match(pathname, "/api/assessments/attempts/:attemptId/grade");
    if (m === "POST" && gradeAtt) {
      const { db, user } = auth();
      requirePerm(user, "canManageAssessments");
      const attempt = db.attempts.find((a: any) => a.id === gradeAtt.attemptId);
      if (!attempt) fail(404, "Attempt not found");
      const assessment = db.assessments.find((a: any) => a.id === attempt.assessmentId);
      if (!assessment) fail(404, "Assessment not found");
      const grades: any[] = body?.grades || [];
      const gradeMap = new Map(grades.map((g) => [g.questionId, g]));
      let manualScore = 0;
      attempt.answers = attempt.answers.map((ans: any) => {
        const q = assessment.questions.find((item: any) => item.id === ans.questionId);
        if (q && (q.type === "written" || q.type === "scenario")) {
          const g = gradeMap.get(q.id) as any;
          const awarded = g ? Math.max(0, Math.min(q.points, Number(g.pointsAwarded) || 0)) : ans.pointsAwarded;
          manualScore += awarded;
          return { ...ans, pointsAwarded: awarded, feedback: g?.feedback };
        }
        return ans;
      });
      attempt.manualScore = manualScore;
      attempt.totalScore = attempt.autoScore + manualScore;
      attempt.passed = attempt.maxScore > 0 && (attempt.totalScore / attempt.maxScore) * 100 >= assessment.passingScore;
      attempt.status = "graded";
      attempt.reviewedBy = user.id;
      addAudit(user.id, "ASSESSMENT_GRADED", "attempt", attempt.id, `Graded ${attempt.totalScore}/${attempt.maxScore}`);
      notify(attempt.userId, "assessment", "Assessment graded", `“${assessment.title}” scored ${attempt.totalScore}/${attempt.maxScore}.`, "assessments");
      touch();
      return { attempt };
    }

    if (m === "GET" && pathname === "/api/conversations") {
      const { db, user } = auth();
      const conversations = db.conversations
        .filter((c: any) => c.memberIds.includes(user.id))
        .sort((a: any, b: any) => b.updatedAt.localeCompare(a.updatedAt));
      return { conversations, onlineUserIds: [...online] };
    }

    if (m === "POST" && pathname === "/api/conversations") {
      const { db, user } = auth();
      const members = Array.from(new Set([user.id, ...(Array.isArray(body?.memberIds) ? body.memberIds.map(String) : [])]));
      if (body?.type === "direct" && members.length === 2) {
        const existing = db.conversations.find(
          (c: any) => c.type === "direct" && c.memberIds.length === 2 && members.every((id) => c.memberIds.includes(id)),
        );
        if (existing) return { conversation: existing };
      }
      const other = members.length === 2 ? db.users.find((u: any) => u.id !== user.id && members.includes(u.id)) : null;
      const conv = {
        id: uid("conv"),
        type: body?.type === "direct" ? "direct" : "group",
        name: body?.name ? String(body.name).trim() : other ? `${user.fullName} & ${other.fullName}` : "Team channel",
        description: body?.description,
        memberIds: members,
        adminIds: [user.id],
        pinnedMessageIds: [],
        createdAt: nowIso(),
        updatedAt: nowIso(),
      };
      db.conversations.unshift(conv);
      emitLive("conversation:new", conv);
      touch();
      return { conversation: conv };
    }

    const patchConv = match(pathname, "/api/conversations/:id");
    if (m === "PATCH" && patchConv) {
      const { db, user } = auth();
      const conv = db.conversations.find((c: any) => c.id === patchConv.id);
      if (!conv || !conv.memberIds.includes(user.id)) fail(404, "Conversation not found");
      const isAdmin = conv.adminIds.includes(user.id) || user.role === "admin";
      if (!isAdmin) fail(403, "Only group administrators can update group settings.");
      if (body?.name) conv.name = String(body.name).trim();
      if (body?.announcement !== undefined) conv.announcement = String(body.announcement);
      if (Array.isArray(body?.memberIds)) conv.memberIds = Array.from(new Set([...conv.adminIds, ...body.memberIds.map(String)]));
      if (body?.togglePinMessageId) {
        const id = String(body.togglePinMessageId);
        conv.pinnedMessageIds = conv.pinnedMessageIds.includes(id)
          ? conv.pinnedMessageIds.filter((p: string) => p !== id)
          : [...conv.pinnedMessageIds, id];
      }
      conv.updatedAt = nowIso();
      emitLive("conversation:updated", conv);
      touch();
      return { conversation: conv };
    }

    const listMsg = match(pathname, "/api/conversations/:id/messages");
    if (m === "GET" && listMsg) {
      const { db, user } = auth();
      const conv = db.conversations.find((c: any) => c.id === listMsg.id);
      if (!conv || !conv.memberIds.includes(user.id)) fail(404, "Conversation not found");
      const query = (q.get("q") || "").trim().toLowerCase();
      const messages = db.messages.filter(
        (msg: any) => msg.conversationId === conv.id && (!query || String(msg.content || "").toLowerCase().includes(query)),
      );
      return { messages };
    }

    const postMsg = match(pathname, "/api/conversations/:id/messages");
    if (m === "POST" && postMsg) {
      const { db, user } = auth();
      const conv = db.conversations.find((c: any) => c.id === postMsg.id);
      if (!conv || !conv.memberIds.includes(user.id)) fail(404, "Conversation not found");
      if (!body?.content && !body?.attachment) fail(400, "Message content or attachment is required.");
      const msg = {
        id: uid("msg"),
        conversationId: conv.id,
        senderId: user.id,
        content: String(body.content || "").trim(),
        replyToId: body.replyToId ? String(body.replyToId) : undefined,
        reactions: {},
        attachment: body.attachment?.name && body.attachment?.dataUrl ? body.attachment : undefined,
        readBy: [user.id],
        createdAt: nowIso(),
      };
      db.messages.push(msg);
      conv.updatedAt = msg.createdAt;
      for (const memberId of conv.memberIds) {
        if (memberId !== user.id) {
          notify(memberId, "message", conv.type === "group" ? `#${conv.name}` : user.fullName, msg.content || `File: ${msg.attachment?.name}`, "messages");
        }
      }
      emitLive("message:new", msg);
      touch();
      return { message: msg };
    }

    const react = match(pathname, "/api/messages/:id/react");
    if (m === "POST" && react) {
      const { db, user } = auth();
      const msg = db.messages.find((item: any) => item.id === react.id);
      if (!msg) fail(404, "Message not found");
      const conv = db.conversations.find((c: any) => c.id === msg.conversationId);
      if (!conv || !conv.memberIds.includes(user.id)) fail(403, "Not permitted");
      const emoji = String(body?.emoji || "👍");
      const existing: string[] = msg.reactions[emoji] || [];
      msg.reactions[emoji] = existing.includes(user.id) ? existing.filter((id) => id !== user.id) : [...existing, user.id];
      emitLive("message:reaction", { messageId: msg.id, reactions: msg.reactions });
      touch();
      return { message: msg };
    }

    const readConv = match(pathname, "/api/conversations/:id/read");
    if (m === "POST" && readConv) {
      const { db, user } = auth();
      const conv = db.conversations.find((c: any) => c.id === readConv.id);
      if (!conv || !conv.memberIds.includes(user.id)) fail(404, "Conversation not found");
      let changed = false;
      for (const msg of db.messages) {
        if (msg.conversationId === conv.id && !msg.readBy.includes(user.id)) {
          msg.readBy.push(user.id);
          changed = true;
        }
      }
      if (changed) {
        emitLive("message:read", { conversationId: conv.id, userId: user.id });
        saveDb();
      }
      return { ok: true };
    }

    if (m === "GET" && pathname === "/api/tasks") {
      const { db } = auth();
      return { projects: db.projects, tasks: db.tasks };
    }

    if (m === "POST" && pathname === "/api/tasks") {
      const { db, user } = auth();
      if (!body?.title) fail(400, "Task title is required.");
      const assigneeId = body.assigneeId ? String(body.assigneeId) : user.id;
      const item = {
        id: uid("tsk"),
        projectId: body.projectId ? String(body.projectId) : db.projects[0]?.id,
        title: String(body.title).trim(),
        description: String(body.description || ""),
        assigneeId,
        reporterId: user.id,
        status: "backlog",
        priority: ["low", "medium", "high", "urgent"].includes(body.priority) ? body.priority : "medium",
        progress: 0,
        deadline: body.deadline || new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
        comments: [],
        createdAt: nowIso(),
        updatedAt: nowIso(),
      };
      db.tasks.unshift(item);
      if (assigneeId !== user.id) {
        notify(assigneeId, "task", "New task assigned", `${user.fullName} assigned “${item.title}” (due ${item.deadline}).`, "tasks");
      }
      addAudit(user.id, "TASK_CREATED", "task", item.id, item.title);
      touch();
      return { task: item };
    }

    const patchTask = match(pathname, "/api/tasks/:id");
    if (m === "PATCH" && patchTask) {
      const { db } = auth();
      const item = db.tasks.find((t: any) => t.id === patchTask.id);
      if (!item) fail(404, "Task not found");
      if (body.status && ["backlog", "in_progress", "in_review", "done"].includes(body.status)) {
        item.status = body.status;
        if (body.status === "done") item.progress = 100;
      }
      if (body.priority && ["low", "medium", "high", "urgent"].includes(body.priority)) item.priority = body.priority;
      if (body.progress !== undefined) item.progress = Math.max(0, Math.min(100, Number(body.progress)));
      if (body.assigneeId) item.assigneeId = String(body.assigneeId);
      if (body.title) item.title = String(body.title).trim();
      if (body.description !== undefined) item.description = String(body.description);
      if (body.deadline) item.deadline = String(body.deadline);
      item.updatedAt = nowIso();
      touch();
      return { task: item };
    }

    const commentTask = match(pathname, "/api/tasks/:id/comments");
    if (m === "POST" && commentTask) {
      const { db, user } = auth();
      const item = db.tasks.find((t: any) => t.id === commentTask.id);
      if (!item) fail(404, "Task not found");
      const text = String(body?.text || "").trim();
      if (!text) fail(400, "Comment text is required.");
      const comment = { id: uid("cmt"), authorId: user.id, text, createdAt: nowIso() };
      item.comments.push(comment);
      item.updatedAt = comment.createdAt;
      touch();
      return { task: item, comment };
    }

    if (m === "GET" && pathname === "/api/meetings") {
      const { db } = auth();
      return { meetings: db.meetings, integrations: db.integrations };
    }

    if (m === "POST" && pathname === "/api/meetings") {
      const { db, user } = auth();
      if (!body?.title || !body?.startTime || !body?.endTime) {
        fail(400, "Meeting title, start time, and end time are required.");
      }
      const provider = body.provider === "google_meet" || body.provider === "zoom" ? body.provider : "internal";
      if (provider !== "internal") {
        const integ = db.integrations.find((i: any) => i.provider === (provider === "google_meet" ? "google" : "zoom"));
        if (!integ?.connected && !body.meetingUrl) {
          fail(
            400,
            `${provider === "google_meet" ? "Google" : "Zoom"} integration is not connected yet. Connect credentials first or provide a verified meeting join link.`,
          );
        }
      }
      const participants = Array.from(new Set([user.id, ...(Array.isArray(body.participantIds) ? body.participantIds.map(String) : [])]));
      const meeting = {
        id: uid("mtg"),
        title: String(body.title).trim(),
        description: String(body.description || ""),
        organizerId: user.id,
        participantIds: participants,
        startTime: String(body.startTime),
        endTime: String(body.endTime),
        provider,
        meetingUrl: body.meetingUrl ? String(body.meetingUrl).trim() : undefined,
        createdAt: nowIso(),
      };
      db.meetings.unshift(meeting);
      for (const pid of participants) {
        if (pid !== user.id) notify(pid, "meeting", "Meeting invitation", `${user.fullName} invited you to “${meeting.title}”.`, "meetings");
      }
      touch();
      return { meeting };
    }

    if (m === "POST" && pathname === "/api/integrations/verify") {
      const { db, user } = auth();
      requirePerm(user, "canManageIntegrations");
      const integ = db.integrations.find((i: any) => i.provider === body?.provider);
      if (!integ) fail(400, "Unsupported integration provider.");
      if (body.provider === "google") {
        if (!body.accessToken) fail(400, "A real Google OAuth access token is required for verification.");
        try {
          const resp = await fetch(`https://oauth2.googleapis.com/tokeninfo?access_token=${encodeURIComponent(String(body.accessToken))}`);
          if (!resp.ok) fail(400, "Google token verification failed. Token is invalid or expired.");
          const info = (await resp.json()) as { email?: string; scope?: string };
          integ.connected = true;
          integ.accountEmail = info.email || user.email;
          integ.scopes = info.scope ? info.scope.split(" ") : [];
          integ.verifiedAt = nowIso();
          integ.note = `Verified Google account ${integ.accountEmail}`;
          touch();
          return { integration: integ };
        } catch (err) {
          if (err instanceof ApiError) throw err;
          fail(502, "Unable to reach Google to verify that token.");
        }
      }
      if (body.provider === "zoom") {
        if (!body.zoomAccountId || !body.zoomClientId || !body.zoomClientSecret) {
          fail(400, "Zoom Account ID, Client ID, and Client Secret are required.");
        }
        try {
          const basic = btoa(`${body.zoomClientId}:${body.zoomClientSecret}`);
          const resp = await fetch(
            `https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${encodeURIComponent(String(body.zoomAccountId))}`,
            { method: "POST", headers: { Authorization: `Basic ${basic}` } },
          );
          if (!resp.ok) fail(400, "Zoom OAuth credential verification failed. Check Account ID / Client keys.");
          const data = (await resp.json()) as { scope?: string };
          integ.connected = true;
          integ.scopes = data.scope ? data.scope.split(" ") : ["meeting:write"];
          integ.verifiedAt = nowIso();
          integ.note = `Verified Zoom account ${body.zoomAccountId}`;
          touch();
          return { integration: integ };
        } catch (err) {
          if (err instanceof ApiError) throw err;
          fail(502, "Unable to reach Zoom to verify those credentials.");
        }
      }
      fail(400, "Unsupported integration provider.");
    }

    if (m === "POST" && pathname === "/api/integrations/disconnect") {
      const { db, user } = auth();
      if (user.role !== "admin") fail(403, "Insufficient permissions for this action");
      const integ = db.integrations.find((i: any) => i.provider === body?.provider);
      if (!integ) fail(404, "Integration not found");
      integ.connected = false;
      integ.accountEmail = undefined;
      integ.scopes = [];
      integ.verifiedAt = undefined;
      integ.note = `${body.provider === "google" ? "Google" : "Zoom"} disconnected.`;
      touch();
      return { integration: integ };
    }

    if (m === "GET" && pathname === "/api/notifications") {
      const { db, user } = auth();
      return { notifications: db.notifications.filter((n: any) => n.userId === user.id).slice(0, 50) };
    }

    if (m === "POST" && pathname === "/api/notifications/read-all") {
      const { db, user } = auth();
      for (const n of db.notifications) if (n.userId === user.id) n.read = true;
      touch();
      return { ok: true };
    }

    if (m === "POST" && pathname === "/api/ai/assistant") {
      const { user } = auth();
      if (!body?.message) fail(400, "Message is required.");
      return { reply: assistantReply(user, String(body.message)) };
    }

    if (m === "GET" && pathname === "/api/analytics") {
      const { user } = auth();
      return analyticsFor(user);
    }

    fail(404, `Unknown route ${m} ${pathname}`);
  } catch (err) {
    if (err instanceof ApiError) throw err;
    fail(500, err instanceof Error ? err.message : "Workspace request failed.");
  }
}

export async function readText(path: string) {
  const res = await dispatch("GET", path);
  if (res && typeof res === "object" && "__text" in res) return String(res.__text);
  return typeof res === "string" ? res : JSON.stringify(res);
}
