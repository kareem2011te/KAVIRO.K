let inMemoryToken: string | null = null;

export function setAuthToken(token: string | null) {
  inMemoryToken = token;
  if (typeof sessionStorage === "undefined") return;
  if (token) sessionStorage.setItem("kaviro_session_token", token);
  else sessionStorage.removeItem("kaviro_session_token");
}

export function getAuthToken(): string | null {
  if (inMemoryToken) return inMemoryToken;
  if (typeof sessionStorage === "undefined") return null;
  const saved = sessionStorage.getItem("kaviro_session_token");
  if (saved) inMemoryToken = saved;
  return saved;
}
