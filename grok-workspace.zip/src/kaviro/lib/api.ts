import { buildWorkspaceZip, dispatch, readText } from "./engine";
import { getAuthToken, setAuthToken } from "./session";

export { getAuthToken, setAuthToken };

export async function apiRequest<T = any>(path: string, options: RequestInit = {}): Promise<T> {
  const method = (options.method || "GET").toUpperCase();
  let body: unknown = undefined;
  if (typeof options.body === "string" && options.body) {
    try {
      body = JSON.parse(options.body);
    } catch {
      body = undefined;
    }
  }
  try {
    const data = await dispatch(method, path, body);
    if (data && typeof data === "object" && "__text" in (data as object)) {
      return (data as { __text: string }).__text as T;
    }
    return data as T;
  } catch (err) {
    const error = err as Error & { status?: number; payload?: unknown };
    if (!error.payload) error.payload = { error: error.message };
    throw error;
  }
}

export async function downloadTextFile(path: string, filename: string, mime: string) {
  const text = await readText(path);
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export async function downloadProjectZip(): Promise<void> {
  const blob = await buildWorkspaceZip();
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "kaviro-platform-web.zip";
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
