import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { $ as Check, A as Moon, B as Laptop, C as Printer, D as Paperclip, E as Phone, F as Mail, G as FileText, H as Inbox, I as LogOut, J as ExternalLink, K as FileSpreadsheet, L as Lock, M as MessageSquare, N as Menu, O as Palette, P as Megaphone, Q as CircleCheck, R as Link2, S as RefreshCw, T as Pin, U as Globe, V as KeyRound, W as FileUp, X as Clock, Y as Download, Z as CircleX, _ as ShieldCheck, a as UserX, at as ArrowRight, b as Search, c as Upload, d as Tablet, et as CheckCheck, f as Sun, g as Shield, h as Smartphone, i as User, it as Bell, j as Monitor, k as Package, l as TriangleAlert, m as Sparkles, n as Video, nt as Calendar, o as UserCog, p as SquareCheckBig, q as Eye, r as Users, rt as Bot, s as UserCheck, t as X, tt as ChartColumn, u as Trash2, v as ShieldAlert, w as Plus, x as Reply, y as Send, z as LayoutDashboard } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CLorKf_z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KAVIRO_LOGO_SRC = "/assets/aistudio/file_000000002dbc82108f86130fa3c28c94_3eb2cade.png";
/**
* Preserves the exact proportions and colors of the official attached KAVIRO logo.
* Uses a dark midnight-navy framing container on light backgrounds so the electric blue
* mark and crisp white wordmark maintain clear contrast without distortion or cropping.
*/
var KaviroLogo = ({ variant = "full", className = "" }) => {
	if (variant === "compact") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `inline-flex items-center gap-2.5 shrink-0 select-none ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-9 w-14 rounded-lg bg-[#02050d] border border-blue-500/25 p-1 flex items-center justify-center overflow-hidden shrink-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: KAVIRO_LOGO_SRC,
				alt: "KAVIRO Logo",
				referrerPolicy: "no-referrer",
				className: "h-full w-full object-contain"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display font-bold tracking-wider text-base text-slate-900 dark:text-white whitespace-nowrap shrink-0",
			children: "KAVIRO"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `rounded-xl bg-[#02050d] border border-blue-500/25 px-3 py-2 flex items-center justify-center shrink-0 select-none ${className}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: KAVIRO_LOGO_SRC,
			alt: "KAVIRO Official Brand Mark",
			referrerPolicy: "no-referrer",
			className: "w-full h-auto max-h-20 object-contain"
		})
	});
};
var SurfaceCard = ({ children, className = "", elevated = false }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: `rounded-xl border border-slate-200 dark:border-blue-500/20 ${elevated ? "bg-slate-50 dark:bg-[#0e1934]" : "bg-white dark:bg-[#091124]"} transition-colors duration-150 ${className}`,
	children
});
var PrimaryButton = ({ children, className = "", size = "md", ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	...props,
	className: `kaviro-gradient-btn text-white font-medium rounded-lg inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00D4FF] cursor-pointer ${size === "sm" ? "px-3.5 py-2 text-xs" : "px-5 py-2.5 text-sm"} ${className}`,
	children
});
var SecondaryButton = ({ children, className = "", size = "md", ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	...props,
	className: `bg-slate-100 hover:bg-slate-200 text-slate-800 dark:bg-[#0e1934] dark:hover:bg-[#142347] dark:text-slate-100 border border-slate-300 dark:border-blue-500/25 font-medium rounded-lg inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 transition-colors duration-150 disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1D7AFC] cursor-pointer ${size === "sm" ? "px-3.5 py-2 text-xs" : "px-4 py-2.5 text-sm"} ${className}`,
	children
});
var SectionHeader = ({ title, subtitle, action }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-5 border-b border-slate-200 dark:border-blue-500/15",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white",
			children: title
		}), subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-slate-600 dark:text-slate-400 max-w-2xl",
			children: subtitle
		})]
	}), action && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center gap-2.5 shrink-0",
		children: action
	})]
});
var MetricTile = ({ label, value, context, tone = "default" }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
		className: "p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-medium text-slate-500 dark:text-slate-400",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mt-2 text-2xl sm:text-3xl font-display font-bold tabular-nums ${tone === "accent" ? "text-[#1D7AFC] dark:text-[#00D4FF]" : tone === "success" ? "text-emerald-600 dark:text-emerald-400" : tone === "warning" ? "text-amber-600 dark:text-amber-400" : tone === "danger" ? "text-rose-600 dark:text-rose-400" : "text-slate-900 dark:text-white"}`,
				children: value
			}),
			context && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1.5 text-xs text-slate-500 dark:text-slate-400 truncate",
				children: context
			})
		]
	});
};
var EmptyState = ({ title, description, action }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "py-12 px-6 text-center flex flex-col items-center justify-center",
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-11 w-11 rounded-xl bg-slate-100 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20 flex items-center justify-center text-slate-500 dark:text-cyan-400",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "w-5 h-5" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-3 text-sm font-semibold text-slate-900 dark:text-white",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-slate-500 dark:text-slate-400 max-w-sm",
			children: description
		}),
		action && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4",
			children: action
		})
	]
});
var handlers = /* @__PURE__ */ new Set();
function subscribeLive(handler) {
	handlers.add(handler);
	return () => {
		handlers.delete(handler);
	};
}
function emitLive(event, payload) {
	for (const handler of handlers) handler(event, payload);
}
var inMemoryToken = null;
function setAuthToken(token) {
	inMemoryToken = token;
	if (typeof sessionStorage === "undefined") return;
	if (token) sessionStorage.setItem("kaviro_session_token", token);
	else sessionStorage.removeItem("kaviro_session_token");
}
function getAuthToken() {
	if (inMemoryToken) return inMemoryToken;
	if (typeof sessionStorage === "undefined") return null;
	const saved = sessionStorage.getItem("kaviro_session_token");
	if (saved) inMemoryToken = saved;
	return saved;
}
var DEFAULT_PERMS = {
	canApproveMembers: true,
	canManageAssessments: true,
	canViewSessions: true,
	canRevokeSessions: true,
	canManageTasksAndGroups: true,
	canViewAnalytics: true,
	canManageIntegrations: false
};
var DB_KEY = "kaviro.workspace.v1";
var ApiError = class extends Error {
	status;
	payload;
	constructor(status, message, extra = {}) {
		super(message);
		this.status = status;
		this.payload = {
			error: message,
			...extra
		};
	}
};
function fail(status, message, extra) {
	throw new ApiError(status, message, extra);
}
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}
function nowIso() {
	return (/* @__PURE__ */ new Date()).toISOString();
}
function code6() {
	return String(Math.floor(1e5 + Math.random() * 9e5));
}
function hashPassword(password) {
	let h = 2166136261;
	const s = `kaviro::${password}`;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return `fnv1a:${(h >>> 0).toString(16)}`;
}
function hashToken(token) {
	return hashPassword(`tok:${token}`);
}
function sanitize(user) {
	const copy = { ...user };
	delete copy.passwordHash;
	delete copy.emailVerificationCode;
	delete copy.resetPasswordCode;
	delete copy.twoFactorSecret;
	return copy;
}
function parseUa() {
	const lower = (typeof navigator !== "undefined" ? navigator.userAgent : "").toLowerCase();
	let deviceType = "Desktop";
	if (/ipad|tablet/.test(lower)) deviceType = "Tablet";
	else if (/mobile|iphone|android/.test(lower)) deviceType = "Mobile";
	let browser = "Web Browser";
	if (lower.includes("edg/")) browser = "Microsoft Edge";
	else if (lower.includes("chrome/")) browser = "Google Chrome";
	else if (lower.includes("firefox/")) browser = "Mozilla Firefox";
	else if (lower.includes("safari/")) browser = "Apple Safari";
	let os = "Unknown OS";
	if (lower.includes("windows")) os = "Windows";
	else if (lower.includes("mac os")) os = "macOS";
	else if (lower.includes("android")) os = "Android";
	else if (lower.includes("iphone") || lower.includes("ipad")) os = "iOS";
	else if (lower.includes("linux")) os = "Linux";
	return {
		deviceType,
		browser,
		os
	};
}
var online = /* @__PURE__ */ new Set();
function presence() {
	emitLive("presence:update", { onlineUserIds: [...online] });
}
function touch() {
	saveDb();
	emitLive("workspace:changed", { at: nowIso() });
}
var cache = null;
function seed() {
	const now = nowIso();
	const hourAgo = (/* @__PURE__ */ new Date(Date.now() - 36e5)).toISOString();
	const dayAgo = (/* @__PURE__ */ new Date(Date.now() - 864e5)).toISOString();
	const tomorrow = new Date(Date.now() + 864e5).toISOString();
	const twoDays = new Date(Date.now() + 1728e5).toISOString();
	const base = {
		passwordHash: hashPassword("Kaviro@2026"),
		emailVerified: true,
		twoFactorEnabled: false,
		humanVerified: true,
		createdAt: dayAgo,
		lastActiveAt: now
	};
	return {
		users: [
			{
				...base,
				id: "usr-admin-01",
				fullName: "Tariq Al-Mansoor",
				email: "admin@kaviro.ai",
				phone: "+971 50 482 9104",
				whatsapp: "+971 50 482 9104",
				desiredRole: "Platform Administrator",
				department: "Executive Operations",
				skills: [
					"Security Architecture",
					"System Governance",
					"AI Strategy",
					"RBAC"
				],
				interests: ["Enterprise Security", "Team Scaling"],
				bio: "Head of Platform Operations & Security Governance at KAVIRO.",
				role: "admin",
				status: "approved",
				onboarding: doneOnboarding(),
				preferredLanguage: "en"
			},
			{
				...base,
				id: "usr-sup-01",
				fullName: "Sarah Chen",
				email: "supervisor@kaviro.ai",
				phone: "+1 415 890 3312",
				whatsapp: "+1 415 890 3312",
				desiredRole: "Engineering Team Lead",
				department: "Core Product Engineering",
				skills: [
					"TypeScript",
					"Distributed Systems",
					"Technical Interviews",
					"Agile Delivery"
				],
				interests: ["Mentorship", "Code Quality"],
				bio: "Engineering Supervisor overseeing onboarding, technical assessments, and project delivery.",
				role: "supervisor",
				supervisorPermissions: { ...DEFAULT_PERMS },
				status: "approved",
				onboarding: doneOnboarding(),
				preferredLanguage: "en",
				lastActiveAt: hourAgo
			},
			{
				...base,
				id: "usr-mem-01",
				fullName: "Omar El-Sayed",
				email: "member@kaviro.ai",
				phone: "+20 100 742 8819",
				whatsapp: "+20 100 742 8819",
				desiredRole: "Senior Full-Stack Engineer",
				department: "Core Product Engineering",
				skills: [
					"React",
					"TypeScript",
					"PostgreSQL",
					"Node.js"
				],
				interests: ["AI Workflows", "Realtime Collaboration"],
				bio: "Full-stack engineer focused on resilient web platforms and bilingual interfaces.",
				role: "member",
				status: "approved",
				onboarding: {
					profileCompleted: true,
					cvCompleted: true,
					humanVerified: true,
					assessmentCompleted: false,
					applicationSubmitted: true
				},
				preferredLanguage: "en"
			},
			{
				...base,
				id: "usr-mem-02",
				fullName: "Lina Haddad",
				email: "lina.haddad@kaviro.ai",
				phone: "+962 79 514 2201",
				desiredRole: "Product Designer",
				department: "Design Systems",
				skills: [
					"Figma",
					"Design Tokens",
					"Accessibility",
					"Arabic RTL UI"
				],
				interests: ["Design Engineering"],
				bio: "Product designer specializing in bilingual RTL enterprise interfaces.",
				role: "member",
				status: "pending",
				onboarding: doneOnboarding(),
				preferredLanguage: "ar",
				createdAt: hourAgo,
				lastActiveAt: hourAgo
			}
		],
		sessions: [{
			id: "ses-seed-01",
			userId: "usr-mem-02",
			tokenHash: hashToken("seed-inactive"),
			deviceType: "Mobile",
			browser: "Apple Safari",
			os: "iOS",
			ipAddress: "192.168.10.42",
			loginAt: hourAgo,
			lastActivityAt: hourAgo,
			status: "active",
			isUnusual: true,
			alertReason: "First sign-in from a new iOS mobile device"
		}],
		cvs: [{
			id: "cv-mem-01",
			userId: "usr-mem-01",
			fullName: "Omar El-Sayed",
			headline: "Senior Full-Stack Engineer · TypeScript & Cloud Architecture",
			email: "member@kaviro.ai",
			phone: "+20 100 742 8819",
			location: "Cairo, Egypt",
			summary: "Full-stack software engineer with 6+ years building real-time SaaS, data pipelines, and accessible bilingual web products.",
			education: [{
				id: "edu-1",
				institution: "Cairo University",
				degree: "B.Sc.",
				field: "Computer Engineering",
				startYear: "2015",
				endYear: "2019"
			}],
			experience: [{
				id: "exp-1",
				company: "NileCloud Systems",
				title: "Senior Software Engineer",
				period: "2022 – Present",
				description: "Led the workspace dashboard migration to TypeScript and live sync, cutting latency by 42%."
			}],
			projects: [{
				id: "prj-1",
				name: "Realtime Collab Engine",
				role: "Lead Architect",
				summary: "Multi-room messaging and presence with offline recovery.",
				impact: "4,500 concurrent channels at 99.95% delivery."
			}],
			achievements: ["Cut CI from 14 minutes to 4 minutes."],
			technicalSkills: [
				"TypeScript",
				"React",
				"Node.js",
				"PostgreSQL",
				"WebSockets"
			],
			softSkills: ["Mentorship", "System Ownership"],
			updatedAt: hourAgo
		}],
		assessments: [{
			id: "asm-eng-01",
			title: "Full-Stack Architecture & Security Readiness",
			titleAr: "اختبار جاهزية البنية البرمجية والأمن السيبراني",
			description: "Practical judgment across authentication, real-time state, API security, and trade-offs.",
			category: "Engineering",
			timeLimitMinutes: 20,
			maxAttempts: 3,
			passingScore: 70,
			assignedUserIds: ["usr-mem-01", "usr-mem-02"],
			randomizeQuestions: true,
			createdBy: "usr-sup-01",
			createdAt: dayAgo,
			questions: [
				{
					id: "q-1",
					type: "mcq",
					prompt: "Where should RBAC permissions be enforced in a production SaaS platform?",
					promptAr: "أين يجب فرض صلاحيات الوصول المعتمدة على الأدوار في منصة احترافية؟",
					options: [
						"Only in React UI route guards",
						"On the server API layer for every protected endpoint",
						"Inside browser localStorage flags",
						"Only during user login"
					],
					correctAnswer: "On the server API layer for every protected endpoint",
					points: 25
				},
				{
					id: "q-2",
					type: "true_false",
					prompt: "True or False: Password hashes should always use a unique per-user cryptographic salt.",
					promptAr: "صح أم خطأ: يجب استخدام ملح تشفير فريد لكل مستخدم عند تجزئة كلمات المرور.",
					options: ["True", "False"],
					correctAnswer: "True",
					points: 20
				},
				{
					id: "q-3",
					type: "scenario",
					prompt: "A supervisor notices a team account signed in from an unrecognized OS and location. Outline the immediate containment and audit steps.",
					promptAr: "لاحظ المشرف تسجيل دخول من جهاز غير معتاد. ما خطوات الاحتواء والمراجعة الفورية؟",
					points: 30
				},
				{
					id: "q-4",
					type: "written",
					prompt: "How do you prevent duplicate messages when a realtime client reconnects after a brief network drop?",
					promptAr: "كيف تمنع تكرار الرسائل عند إعادة الاتصال بعد انقطاع الشبكة؟",
					points: 25
				}
			]
		}, {
			id: "asm-design-01",
			title: "Bilingual Design Systems & Accessibility",
			titleAr: "أنظمة التصميم ثنائية اللغة وإتاحة الوصول",
			description: "RTL mirroring, contrast ratios, and token consistency.",
			category: "Design",
			timeLimitMinutes: 15,
			maxAttempts: 2,
			passingScore: 75,
			assignedUserIds: ["usr-mem-02"],
			randomizeQuestions: false,
			createdBy: "usr-sup-01",
			createdAt: dayAgo,
			questions: [{
				id: "q-d1",
				type: "mcq",
				prompt: "What is the minimum WCAG AA contrast ratio for standard body text?",
				options: [
					"2.5:1",
					"3.0:1",
					"4.5:1",
					"7.0:1"
				],
				correctAnswer: "4.5:1",
				points: 50
			}, {
				id: "q-d2",
				type: "written",
				prompt: "Explain two layout adjustments required when switching a dashboard from LTR English to RTL Arabic.",
				points: 50
			}]
		}],
		attempts: [{
			id: "att-lina-01",
			assessmentId: "asm-design-01",
			userId: "usr-mem-02",
			startedAt: hourAgo,
			submittedAt: hourAgo,
			answers: [{
				questionId: "q-d1",
				answer: "4.5:1",
				isCorrect: true,
				pointsAwarded: 50
			}, {
				questionId: "q-d2",
				answer: "Mirror the sidebar and directional icons, and keep numeric metrics tabular.",
				pointsAwarded: 0
			}],
			autoScore: 50,
			manualScore: 0,
			totalScore: 50,
			maxScore: 100,
			status: "pending_review"
		}],
		conversations: [{
			id: "conv-grp-core",
			type: "group",
			name: "Core Engineering & Onboarding",
			description: "Architecture, sprint updates, and onboarding.",
			announcement: "Complete human verification before the weekly sync.",
			memberIds: [
				"usr-admin-01",
				"usr-sup-01",
				"usr-mem-01",
				"usr-mem-02"
			],
			adminIds: ["usr-admin-01", "usr-sup-01"],
			pinnedMessageIds: ["msg-01"],
			createdAt: dayAgo,
			updatedAt: hourAgo
		}, {
			id: "conv-dm-sup-mem",
			type: "direct",
			name: "Sarah Chen & Omar El-Sayed",
			memberIds: ["usr-sup-01", "usr-mem-01"],
			adminIds: ["usr-sup-01", "usr-mem-01"],
			pinnedMessageIds: [],
			createdAt: dayAgo,
			updatedAt: hourAgo
		}],
		messages: [
			{
				id: "msg-01",
				conversationId: "conv-grp-core",
				senderId: "usr-sup-01",
				content: "Welcome to the core channel. Review your onboarding checklist and the upcoming skill assessment.",
				reactions: { "👍": ["usr-admin-01", "usr-mem-01"] },
				readBy: [
					"usr-sup-01",
					"usr-admin-01",
					"usr-mem-01"
				],
				createdAt: dayAgo
			},
			{
				id: "msg-02",
				conversationId: "conv-grp-core",
				senderId: "usr-mem-01",
				content: "Thanks Sarah — CV draft is uploaded and ready for review.",
				replyToId: "msg-01",
				reactions: {},
				readBy: ["usr-mem-01", "usr-sup-01"],
				createdAt: hourAgo
			},
			{
				id: "msg-03",
				conversationId: "conv-dm-sup-mem",
				senderId: "usr-sup-01",
				content: "Omar, finish the architecture assessment so we can lock your project assignment.",
				reactions: {},
				readBy: ["usr-sup-01", "usr-mem-01"],
				createdAt: hourAgo
			}
		],
		projects: [{
			id: "proj-01",
			name: "KAVIRO Platform v2 Rollout",
			description: "Onboarding, CV intelligence, and session security.",
			leadId: "usr-sup-01",
			memberIds: [
				"usr-admin-01",
				"usr-sup-01",
				"usr-mem-01",
				"usr-mem-02"
			],
			status: "active",
			createdAt: dayAgo
		}, {
			id: "proj-02",
			name: "Security & Compliance Audit",
			description: "Session monitoring, RBAC, and assessment integrity.",
			leadId: "usr-admin-01",
			memberIds: ["usr-admin-01", "usr-sup-01"],
			status: "active",
			createdAt: dayAgo
		}],
		tasks: [
			task("tsk-01", "proj-01", "Finalize bilingual RTL navigation", "usr-mem-02", "usr-sup-01", "in_review", "high", 85, tomorrow, dayAgo, hourAgo, [{
				id: "cmt-1",
				authorId: "usr-sup-01",
				text: "Looks crisp on desktop. Check the mobile drawer next.",
				createdAt: hourAgo
			}]),
			task("tsk-02", "proj-01", "Complete the architecture assessment", "usr-mem-01", "usr-sup-01", "in_progress", "urgent", 50, tomorrow, dayAgo, hourAgo),
			task("tsk-03", "proj-02", "Review pending applications and unusual sessions", "usr-sup-01", "usr-admin-01", "backlog", "medium", 20, twoDays, dayAgo, dayAgo),
			task("tsk-04", "proj-02", "Confirm session revocation actually signs devices out", "usr-admin-01", "usr-admin-01", "done", "high", 100, now, dayAgo, hourAgo)
		],
		meetings: [{
			id: "mtg-01",
			title: "Weekly Engineering & Onboarding Sync",
			description: "Assessments, milestones, and security alerts.",
			organizerId: "usr-sup-01",
			participantIds: [
				"usr-admin-01",
				"usr-sup-01",
				"usr-mem-01"
			],
			startTime: tomorrow,
			endTime: new Date(new Date(tomorrow).getTime() + 27e5).toISOString(),
			provider: "internal",
			createdAt: dayAgo
		}],
		integrations: [{
			provider: "google",
			connected: false,
			scopes: [],
			note: "Google is not connected. Paste a real OAuth access token, or schedule with an internal room / join link."
		}, {
			provider: "zoom",
			connected: false,
			scopes: [],
			note: "Zoom is not connected. Provide Account ID, Client ID, and Client Secret, or paste a join link."
		}],
		notifications: [
			note("notif-01", "usr-sup-01", "application", "New application ready", "Lina Haddad submitted her onboarding application.", hourAgo, "dashboard"),
			note("notif-02", "usr-mem-01", "assessment", "Assessment waiting", "Full-Stack Architecture assessment is assigned to you.", hourAgo, "assessments"),
			note("notif-03", "usr-admin-01", "security", "Unusual mobile session", "Lina Haddad has an active iOS session flagged as unusual.", dayAgo, "security")
		],
		auditLogs: [audit("aud-01", "usr-admin-01", "SECURITY_POLICY_INIT", "system", "kaviro", "Initialized RBAC and session audit logging.", dayAgo), audit("aud-02", "usr-sup-01", "ASSESSMENT_CREATED", "assessment", "asm-eng-01", "Published the architecture readiness assessment.", dayAgo)],
		captchas: []
	};
}
function doneOnboarding() {
	return {
		profileCompleted: true,
		cvCompleted: true,
		humanVerified: true,
		assessmentCompleted: true,
		applicationSubmitted: true
	};
}
function task(id, projectId, title, assigneeId, reporterId, status, priority, progress, deadline, createdAt, updatedAt, comments = []) {
	return {
		id,
		projectId,
		title,
		description: title,
		assigneeId,
		reporterId,
		status,
		priority,
		progress,
		deadline: deadline.slice(0, 10),
		comments,
		createdAt,
		updatedAt
	};
}
function note(id, userId, category, title, body, createdAt, targetTab) {
	return {
		id,
		userId,
		category,
		title,
		body,
		read: false,
		createdAt,
		targetTab
	};
}
function audit(id, actorId, action, targetType, targetId, details, createdAt) {
	return {
		id,
		actorId,
		action,
		targetType,
		targetId,
		details,
		ipAddress: "workspace",
		createdAt
	};
}
function getDb() {
	if (cache) return cache;
	if (typeof localStorage !== "undefined") try {
		const raw = localStorage.getItem(DB_KEY);
		if (raw) {
			cache = JSON.parse(raw);
			if (cache?.users?.length) return cache;
		}
	} catch {}
	cache = seed();
	saveDb();
	return cache;
}
function saveDb() {
	if (typeof localStorage === "undefined" || !cache) return;
	try {
		localStorage.setItem(DB_KEY, JSON.stringify(cache));
	} catch {}
}
function notify(userId, category, title, body, targetTab) {
	const db = getDb();
	const item = {
		id: uid("ntf"),
		userId,
		category,
		title,
		body,
		read: false,
		createdAt: nowIso(),
		targetTab
	};
	db.notifications.unshift(item);
	emitLive("notification:new", item);
	return item;
}
function addAudit(actorId, action, targetType, targetId, details) {
	const db = getDb();
	db.auditLogs.unshift(audit(uid("aud"), actorId, action, targetType, targetId, details, nowIso()));
	if (db.auditLogs.length > 200) db.auditLogs.length = 200;
}
function privileged(user) {
	return user.role === "admin" || user.role === "supervisor";
}
function hasPerm(user, perm) {
	if (user.role === "admin") return true;
	if (user.role === "supervisor") return Boolean((user.supervisorPermissions || DEFAULT_PERMS)[perm]);
	return false;
}
function requirePerm(user, perm) {
	if (!hasPerm(user, perm)) fail(403, `Missing permission: ${perm}`);
}
function auth() {
	const token = getAuthToken();
	if (!token) fail(401, "Authentication required");
	const db = getDb();
	const tokenHash = hashToken(token);
	const session = db.sessions.find((s) => s.tokenHash === tokenHash && s.status === "active");
	if (!session) fail(401, "Session expired or revoked");
	const user = db.users.find((u) => u.id === session.userId);
	if (!user) fail(401, "Account not found");
	if (user.status === "suspended" || user.status === "rejected") fail(403, "Account access is suspended or rejected");
	session.lastActivityAt = nowIso();
	user.lastActiveAt = session.lastActivityAt;
	if (!online.has(user.id)) {
		online.add(user.id);
		presence();
	}
	return {
		db,
		user,
		session
	};
}
function createSession(user) {
	const db = getDb();
	const rawToken = uid("tok") + uid("sec");
	const ua = parseUa();
	const past = db.sessions.filter((s) => s.userId === user.id);
	const known = past.some((s) => s.browser === ua.browser && s.os === ua.os && !s.isUnusual);
	const isUnusual = past.length > 0 && !known;
	const session = {
		id: uid("ses"),
		userId: user.id,
		tokenHash: hashToken(rawToken),
		deviceType: ua.deviceType,
		browser: ua.browser,
		os: ua.os,
		ipAddress: "workspace",
		loginAt: nowIso(),
		lastActivityAt: nowIso(),
		status: "active",
		isUnusual,
		alertReason: isUnusual ? `New ${ua.os} / ${ua.browser} sign-in` : void 0
	};
	db.sessions.unshift(session);
	online.add(user.id);
	if (isUnusual) for (const sup of db.users.filter((u) => privileged(u))) notify(sup.id, "security", "Unusual login", `${user.fullName} signed in from ${ua.browser} on ${ua.os}.`, "security");
	presence();
	return rawToken;
}
function revokeSession(session, actorName) {
	session.status = "revoked";
	session.logoutAt = nowIso();
	const token = getAuthToken();
	const affectsCurrent = Boolean(token && session.tokenHash === hashToken(token));
	if (affectsCurrent) online.delete(session.userId);
	emitLive("session:revoked", {
		userId: session.userId,
		sessionId: session.id,
		affectsCurrent,
		actorName
	});
	presence();
}
function publicUser(user, viewer) {
	const safe = sanitize(user);
	if (privileged(viewer) || user.id === viewer.id) return {
		...safe,
		isOnline: online.has(user.id)
	};
	return {
		id: safe.id,
		fullName: safe.fullName,
		email: safe.email,
		desiredRole: safe.desiredRole,
		department: safe.department,
		skills: safe.skills,
		role: safe.role,
		status: safe.status,
		avatarUrl: safe.avatarUrl,
		isOnline: online.has(user.id)
	};
}
function analyticsFor(user) {
	const db = getDb();
	const names = new Map(db.users.map((u) => [u.id, u.fullName]));
	const graded = db.attempts.filter((a) => a.status === "graded" && a.maxScore > 0);
	const avg = graded.length > 0 ? Math.round(graded.reduce((acc, a) => acc + a.totalScore / a.maxScore * 100, 0) / graded.length) : 0;
	const logs = (privileged(user) ? db.auditLogs : db.auditLogs.filter((l) => l.actorId === user.id)).slice(0, 40).map((log) => ({
		...log,
		actorName: names.get(log.actorId) || "System"
	}));
	return {
		memberStats: {
			total: db.users.length,
			approved: db.users.filter((u) => u.status === "approved").length,
			pending: db.users.filter((u) => u.status === "pending").length,
			humanVerified: db.users.filter((u) => u.humanVerified).length
		},
		taskStats: {
			total: db.tasks.length,
			backlog: db.tasks.filter((t) => t.status === "backlog").length,
			inProgress: db.tasks.filter((t) => t.status === "in_progress").length,
			inReview: db.tasks.filter((t) => t.status === "in_review").length,
			done: db.tasks.filter((t) => t.status === "done").length
		},
		assessmentStats: {
			totalAssessments: db.assessments.length,
			totalAttempts: db.attempts.length,
			pendingReviews: db.attempts.filter((a) => a.status === "pending_review").length,
			avgScorePct: avg
		},
		securityStats: {
			activeSessions: db.sessions.filter((s) => s.status === "active").length,
			unusualAlerts: db.sessions.filter((s) => s.status === "active" && s.isUnusual).length
		},
		projectProgress: db.projects.map((p) => {
			const pTasks = db.tasks.filter((t) => t.projectId === p.id);
			const progress = pTasks.length ? Math.round(pTasks.reduce((s, t) => s + t.progress, 0) / pTasks.length) : 0;
			return {
				id: p.id,
				name: p.name,
				taskCount: pTasks.length,
				progress
			};
		}),
		auditLogs: logs
	};
}
function assistantReply(user, message) {
	const db = getDb();
	const text = message.toLowerCase();
	const ar = /[\u0600-\u06FF]/.test(message) || user.preferredLanguage === "ar";
	const open = db.tasks.filter((t) => privileged(user) || t.assigneeId === user.id || t.reporterId === user.id).filter((t) => t.status !== "done");
	const meetings = db.meetings.filter((m) => privileged(user) || m.participantIds.includes(user.id));
	const pending = db.users.filter((u) => u.status === "pending");
	const unusual = db.sessions.filter((s) => s.status === "active" && s.isUnusual);
	const cv = db.cvs.find((c) => c.userId === user.id);
	if (/assess|اختبار|تقييم/.test(text)) {
		const mine = db.attempts.filter((a) => a.userId === user.id);
		return ar ? `عندك ${mine.length} محاولة. ابدأ من شاشة الاختبارات بعد التحقق البشري. الأسئلة الموضوعية تُصحح فوراً، والمقالية تنتظر المشرف.` : `You have ${mine.length} attempt(s). Open Assessments, pass the human check, then start. Multiple choice is graded instantly; written answers wait for a supervisor.`;
	}
	if (/task|مهم/.test(text)) {
		const titles = open.slice(0, 4).map((t) => `${t.title} (${t.status}, due ${t.deadline})`).join(ar ? "، " : "; ");
		return ar ? `المهام المفتوحة: ${open.length}. ${titles || "لا توجد مهام مفتوحة."}` : `Open tasks: ${open.length}. ${titles || "Nothing open right now."}`;
	}
	if (/meet|اجتماع/.test(text)) {
		const next = meetings[0];
		return ar ? next ? `أقرب اجتماع: ${next.title} في ${new Date(next.startTime).toLocaleString()}.` : "لا توجد اجتماعات على جدولك." : next ? `Next meeting: ${next.title} at ${new Date(next.startTime).toLocaleString()}.` : "No meetings on your calendar.";
	}
	if (/cv|سيرة|resume/.test(text)) return ar ? cv ? `سيرتك محفوظة بعنوان «${cv.headline}». افتح منشئ السيرة ثم شغّل التحليل لسد الثغرات قبل الاعتماد.` : "لا توجد سيرة بعد. افتح منشئ السيرة، املأ العنوان والملخص، ثم احفظ." : cv ? `Your CV is saved as “${cv.headline}”. Run AI analysis in the CV builder before you apply the draft.` : "No CV yet. Open the CV builder, add a headline and summary, then save.";
	if (/secur|جلسة|أمان|login/.test(text)) return ar ? `الجلسات النشطة غير المعتادة: ${unusual.length}. الإنهاء الفوري متاح من شاشة الجلسات والأمان لحسابك أو للفريق إذا كنت مشرفاً.` : `Unusual active sessions: ${unusual.length}. Force logout is on Sessions & Security — your own devices, or the whole team if you are a supervisor.`;
	if (privileged(user) && /pending|موافق|طلب|approv/.test(text)) return ar ? `طلبات بانتظار الموافقة: ${pending.length}${pending[0] ? ` — ${pending.map((u) => u.fullName).join("، ")}` : ""}.` : `Pending approvals: ${pending.length}${pending[0] ? ` — ${pending.map((u) => u.fullName).join(", ")}` : ""}.`;
	return ar ? `أنا مساعد KAVIRO. أقدر أساعدك في السيرة، الاختبارات (${db.assessments.length})، المهام المفتوحة (${open.length})، والاجتماعات (${meetings.length}). اسأل عن أي شاشة بالاسم.` : `I am KAVIRO AI for this workspace. I can help with your CV, ${db.assessments.length} assessments, ${open.length} open tasks, and ${meetings.length} meetings. Ask about a screen by name.`;
}
function analyzeCv(cv, language) {
	const ar = language === "ar";
	const missing = [];
	if (!cv?.headline) missing.push(ar ? "العنوان المهني" : "Professional headline");
	if (!cv?.summary || String(cv.summary).length < 40) missing.push(ar ? "ملخص أقوى (٤٠+ حرف)" : "A fuller summary (40+ characters)");
	if (!cv?.experience?.length) missing.push(ar ? "خبرة عملية واحدة على الأقل" : "At least one role");
	if (!cv?.technicalSkills?.length) missing.push(ar ? "مهارات تقنية" : "Technical skills");
	const skills = (cv?.technicalSkills || []).filter(Boolean);
	return {
		overallReadiness: missing.length === 0 ? ar ? "جاهزة للمراجعة" : "Ready for review" : ar ? "تحتاج استكمال" : "Needs a pass",
		missingInformation: missing.length ? missing : [ar ? "لا نواقص جوهرية" : "No critical gaps"],
		followUpQuestions: [ar ? "ما النتيجة الرقمية الأهم في آخر مشروع؟" : "What is the most concrete metric from your latest project?", ar ? "ما الأدوات التي استخدمتها يومياً؟" : "Which tools did you use every day?"],
		grammarAndWordingFixes: [ar ? "ابدأ كل نقطة خبرة بفعل قوي ورقم." : "Start each experience bullet with a strong verb and a number.", ar ? "اجعل العنوان دوراً لا جملة." : "Keep the headline to a role, not a sentence."],
		projectSuggestions: (cv?.projects || []).slice(0, 2).map((p) => ({
			projectName: p.name,
			improvedSummary: p.summary || (ar ? "صف المشكلة والحل في سطرين." : "Describe the problem and the fix in two lines."),
			improvedImpact: p.impact || (ar ? "أضف نسبة أو حجماً (مستخدمون، زمن، أخطاء)." : "Add a scale: users, time saved, or errors removed.")
		})),
		improvedDraft: {
			headline: cv?.headline || (ar ? "مهندس برمجيات" : "Software engineer"),
			summary: cv?.summary && String(cv.summary).length > 40 ? cv.summary : ar ? "مهندس يبني منتجات ويب ثنائية اللغة مع تركيز على الاعتمادية وتجربة الفريق." : "Engineer building bilingual web products with a focus on reliability and team workflows.",
			technicalSkills: skills.length ? skills : ["TypeScript", "React"],
			softSkills: cv?.softSkills?.length ? cv.softSkills : ar ? ["تواصل", "ملكية"] : ["Communication", "Ownership"]
		}
	};
}
function decodeBase64(b64) {
	const bin = atob(b64.replace(/\s/g, ""));
	const bytes = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
	return bytes;
}
function printable(bytes) {
	let run = "";
	let out = "";
	for (const b of bytes) if (b >= 32 && b < 127) run += String.fromCharCode(b);
	else {
		if (run.length > 5) out += `${run} `;
		run = "";
	}
	if (run.length > 5) out += run;
	return out.replace(/\s+/g, " ").trim().slice(0, 6e3);
}
function crc32(data) {
	let c = -1;
	for (const b of data) {
		c ^= b;
		for (let i = 0; i < 8; i++) c = c & 1 ? c >>> 1 ^ 3988292384 : c >>> 1;
	}
	return ~c >>> 0;
}
function u16(n) {
	return [n & 255, n >> 8 & 255];
}
function u32(n) {
	return [
		n & 255,
		n >> 8 & 255,
		n >> 16 & 255,
		n >> 24 & 255
	];
}
function buildZip(files) {
	const parts = [];
	const central = [];
	let offset = 0;
	for (const file of files) {
		const nameBytes = new TextEncoder().encode(file.name);
		const data = new TextEncoder().encode(file.text);
		const crc = crc32(data);
		const local = [
			...u32(67324752),
			...u16(20),
			...u16(0),
			...u16(0),
			...u16(0),
			...u16(0),
			...u32(crc),
			...u32(data.length),
			...u32(data.length),
			...u16(nameBytes.length),
			...u16(0),
			...nameBytes,
			...data
		];
		parts.push(...local);
		central.push(...u32(33639248), ...u16(20), ...u16(20), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nameBytes.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset), ...nameBytes);
		offset += local.length;
	}
	const end = [
		...u32(101010256),
		...u16(0),
		...u16(0),
		...u16(files.length),
		...u16(files.length),
		...u32(central.length),
		...u32(offset),
		...u16(0)
	];
	return new Uint8Array([
		...parts,
		...central,
		...end
	]);
}
async function buildWorkspaceZip() {
	const db = getDb();
	const snapshot = {
		members: db.users.map((u) => ({
			name: u.fullName,
			email: u.email,
			role: u.role,
			status: u.status
		})),
		projects: db.projects.map((p) => p.name),
		tasks: db.tasks.map((t) => ({
			title: t.title,
			status: t.status
		})),
		meetings: db.meetings.map((m) => ({
			title: m.title,
			start: m.startTime
		}))
	};
	const bytes = buildZip([{
		name: "README.txt",
		text: [
			"KAVIRO workspace package",
			"",
			"This archive is a portable snapshot of the live KAVIRO team workspace.",
			"Demo sign-in password: Kaviro@2026",
			"Accounts: admin@kaviro.ai · supervisor@kaviro.ai · member@kaviro.ai",
			"",
			"Screens: Dashboard, Design System, CV Builder, Assessments, Messages,",
			"Tasks, Meetings, Sessions & Security, Reports, Profile."
		].join("\n")
	}, {
		name: "workspace-snapshot.json",
		text: JSON.stringify(snapshot, null, 2)
	}]);
	return new Blob([bytes], { type: "application/zip" });
}
function csvReport() {
	const db = getDb();
	return [
		[
			"Type",
			"ID",
			"Title",
			"Status",
			"Owner",
			"Timestamp"
		].join(","),
		...db.users.map((u) => [
			"Member",
			u.id,
			`"${u.fullName}"`,
			u.status,
			u.role,
			u.createdAt
		].join(",")),
		...db.tasks.map((t) => [
			"Task",
			t.id,
			`"${t.title}"`,
			t.status,
			`${t.progress}%`,
			t.updatedAt
		].join(",")),
		...db.attempts.map((a) => [
			"AssessmentAttempt",
			a.id,
			a.assessmentId,
			a.status,
			`${a.totalScore}/${a.maxScore}`,
			a.startedAt
		].join(","))
	].join("\n");
}
function icsFor(id) {
	const { db } = auth();
	const m = db.meetings.find((item) => item.id === id);
	if (!m) fail(404, "Meeting not found");
	const fmt = (iso) => iso.replace(/[-:]/g, "").replace(/\.\d+Z$/, "Z");
	return [
		"BEGIN:VCALENDAR",
		"VERSION:2.0",
		"PRODID:-//KAVIRO//Team Workspace//EN",
		"BEGIN:VEVENT",
		`UID:${m.id}@kaviro.ai`,
		`DTSTAMP:${fmt(m.createdAt)}`,
		`DTSTART:${fmt(m.startTime)}`,
		`DTEND:${fmt(m.endTime)}`,
		`SUMMARY:${m.title}`,
		`DESCRIPTION:${(m.description || "").replace(/\n/g, " ")}`,
		"END:VEVENT",
		"END:VCALENDAR"
	].join("\r\n");
}
function match(pathname, pattern) {
	const a = pathname.split("/").filter(Boolean);
	const b = pattern.split("/").filter(Boolean);
	if (a.length !== b.length) return null;
	const params = {};
	for (let i = 0; i < b.length; i++) if (b[i].startsWith(":")) params[b[i].slice(1)] = decodeURIComponent(a[i]);
	else if (a[i] !== b[i]) return null;
	return params;
}
async function dispatch(method, path, body = {}) {
	const url = new URL(path, "http://kaviro.local");
	const pathname = url.pathname.replace(/\/$/, "") || "/";
	const q = url.searchParams;
	const m = method.toUpperCase();
	try {
		if (m === "GET" && pathname === "/api/analytics/export.csv") {
			auth();
			return {
				__text: csvReport(),
				__mime: "text/csv"
			};
		}
		const ics = match(pathname, "/api/meetings/:id/ics");
		if (m === "GET" && ics) return {
			__text: icsFor(ics.id),
			__mime: "text/calendar"
		};
		if (m === "POST" && pathname === "/api/auth/register") {
			const db = getDb();
			const { fullName, email, password, phone, whatsapp, avatarUrl, desiredRole, department, skills, interests, preferredLanguage } = body || {};
			if (!fullName || !email || !password || !phone || !desiredRole) fail(400, "Full name, email, password, phone, and desired role are required.");
			if (String(password).length < 8) fail(400, "Password must be at least 8 characters long.");
			const normalized = String(email).trim().toLowerCase();
			if (db.users.some((u) => u.email.toLowerCase() === normalized)) fail(409, "An account with this email already exists.");
			const verificationCode = code6();
			const user = {
				id: uid("usr"),
				fullName: String(fullName).trim(),
				email: normalized,
				passwordHash: hashPassword(String(password)),
				phone: String(phone).trim(),
				whatsapp: whatsapp ? String(whatsapp).trim() : void 0,
				avatarUrl: avatarUrl || void 0,
				desiredRole: String(desiredRole).trim(),
				department: department ? String(department).trim() : "General Operations",
				skills: Array.isArray(skills) ? skills.map(String) : [],
				interests: Array.isArray(interests) ? interests.map(String) : [],
				role: "member",
				status: "pending",
				emailVerified: false,
				emailVerificationCode: verificationCode,
				twoFactorEnabled: false,
				humanVerified: false,
				onboarding: {
					profileCompleted: true,
					cvCompleted: false,
					humanVerified: false,
					assessmentCompleted: false,
					applicationSubmitted: false
				},
				preferredLanguage: preferredLanguage === "ar" ? "ar" : "en",
				createdAt: nowIso(),
				lastActiveAt: nowIso()
			};
			db.users.push(user);
			addAudit(user.id, "USER_REGISTERED", "user", user.id, `New member registered: ${user.email}`);
			for (const sup of db.users.filter((u) => privileged(u) && u.id !== user.id)) notify(sup.id, "application", "New member registration", `${user.fullName} (${user.desiredRole}) is completing onboarding.`, "dashboard");
			touch();
			return {
				requiresEmailVerification: true,
				email: user.email,
				verificationCodePreview: verificationCode
			};
		}
		if (m === "POST" && pathname === "/api/auth/verify-email") {
			const user = getDb().users.find((u) => u.email.toLowerCase() === String(body?.email || "").trim().toLowerCase());
			if (!user) fail(404, "Account not found.");
			if (!user.emailVerified && user.emailVerificationCode !== String(body?.code || "").trim()) fail(400, "Invalid verification code.");
			user.emailVerified = true;
			user.emailVerificationCode = void 0;
			const token = createSession(user);
			addAudit(user.id, "EMAIL_VERIFIED", "user", user.id, "Email verified");
			touch();
			return {
				token,
				user: sanitize(user)
			};
		}
		if (m === "POST" && pathname === "/api/auth/login") {
			const { email, password } = body || {};
			if (!email || !password) fail(400, "Email and password are required.");
			const user = getDb().users.find((u) => u.email.toLowerCase() === String(email).trim().toLowerCase());
			if (!user || user.passwordHash !== hashPassword(String(password))) fail(401, "Invalid email or password.");
			if (user.status === "suspended" || user.status === "rejected") fail(403, "This account is suspended or rejected.");
			if (!user.emailVerified) {
				user.emailVerificationCode = user.emailVerificationCode || code6();
				touch();
				fail(403, "Email verification required.", {
					requiresEmailVerification: true,
					email: user.email,
					verificationCodePreview: user.emailVerificationCode
				});
			}
			if (user.twoFactorEnabled) {
				user.twoFactorSecret = code6();
				touch();
				return {
					requiresTwoFactor: true,
					email: user.email,
					twoFactorCodePreview: user.twoFactorSecret
				};
			}
			const token = createSession(user);
			addAudit(user.id, "USER_LOGIN", "user", user.id, "Signed in");
			touch();
			return {
				token,
				user: sanitize(user)
			};
		}
		if (m === "POST" && pathname === "/api/auth/verify-2fa") {
			const user = getDb().users.find((u) => u.email.toLowerCase() === String(body?.email || "").trim().toLowerCase());
			if (!user || !user.twoFactorEnabled) fail(400, "2FA challenge not active.");
			if (user.twoFactorSecret !== String(body?.code || "").trim()) fail(401, "Invalid 2FA verification code.");
			user.twoFactorSecret = void 0;
			const token = createSession(user);
			addAudit(user.id, "USER_LOGIN_2FA", "user", user.id, "Completed 2FA sign-in");
			touch();
			return {
				token,
				user: sanitize(user)
			};
		}
		if (m === "POST" && pathname === "/api/auth/forgot-password") {
			const user = getDb().users.find((u) => u.email.toLowerCase() === String(body?.email || "").trim().toLowerCase());
			if (!user) return { message: "If an account matches that email, a recovery code has been issued." };
			user.resetPasswordCode = code6();
			touch();
			return {
				message: "Password recovery code issued.",
				resetCodePreview: user.resetPasswordCode
			};
		}
		if (m === "POST" && pathname === "/api/auth/reset-password") {
			const { email, code, newPassword } = body || {};
			if (!email || !code || !newPassword || String(newPassword).length < 8) fail(400, "Valid email, code, and 8+ character password are required.");
			const user = getDb().users.find((u) => u.email.toLowerCase() === String(email).trim().toLowerCase());
			if (!user || user.resetPasswordCode !== String(code).trim()) fail(400, "Invalid recovery code.");
			user.passwordHash = hashPassword(String(newPassword));
			user.resetPasswordCode = void 0;
			addAudit(user.id, "PASSWORD_RESET", "user", user.id, "Password reset completed");
			touch();
			return { ok: true };
		}
		if (m === "POST" && pathname === "/api/auth/logout") {
			const { db, user, session } = auth();
			session.status = "logged_out";
			session.logoutAt = nowIso();
			online.delete(user.id);
			addAudit(user.id, "USER_LOGOUT", "session", session.id, "Signed out");
			presence();
			touch();
			return { ok: true };
		}
		if (m === "GET" && pathname === "/api/auth/me") {
			const { user, session } = auth();
			return {
				user: sanitize(user),
				sessionId: session.id
			};
		}
		if (m === "PATCH" && pathname === "/api/auth/profile") {
			const { db, user } = auth();
			if (body.email) {
				const normalized = String(body.email).trim().toLowerCase();
				if (db.users.some((u) => u.id !== user.id && u.email.toLowerCase() === normalized)) fail(409, "That email address is already in use by another account.");
				user.email = normalized;
			}
			if (body.fullName) user.fullName = String(body.fullName).trim();
			if (body.phone) user.phone = String(body.phone).trim();
			if (body.whatsapp !== void 0) user.whatsapp = body.whatsapp ? String(body.whatsapp).trim() : void 0;
			if (body.avatarUrl !== void 0) user.avatarUrl = body.avatarUrl || void 0;
			if (body.desiredRole) user.desiredRole = String(body.desiredRole).trim();
			if (body.department) user.department = String(body.department).trim();
			if (Array.isArray(body.skills)) user.skills = body.skills.map(String);
			if (Array.isArray(body.interests)) user.interests = body.interests.map(String);
			if (body.bio !== void 0) user.bio = String(body.bio);
			if (body.preferredLanguage === "ar" || body.preferredLanguage === "en") user.preferredLanguage = body.preferredLanguage;
			user.onboarding = user.onboarding || {};
			user.onboarding.profileCompleted = Boolean(user.fullName && user.phone && user.desiredRole);
			addAudit(user.id, "PROFILE_UPDATED", "user", user.id, "Updated profile");
			touch();
			return { user: sanitize(user) };
		}
		if (m === "POST" && pathname === "/api/auth/change-password") {
			const { user } = auth();
			if (!body?.currentPassword || !body?.newPassword || String(body.newPassword).length < 8) fail(400, "Current password and an 8+ character new password are required.");
			if (user.passwordHash !== hashPassword(String(body.currentPassword))) fail(401, "Current password is incorrect.");
			user.passwordHash = hashPassword(String(body.newPassword));
			addAudit(user.id, "PASSWORD_CHANGED", "user", user.id, "Updated password");
			touch();
			return { ok: true };
		}
		if (m === "POST" && pathname === "/api/auth/2fa/toggle") {
			const { user } = auth();
			user.twoFactorEnabled = Boolean(body?.enabled);
			addAudit(user.id, user.twoFactorEnabled ? "2FA_ENABLED" : "2FA_DISABLED", "user", user.id, "2FA toggled");
			touch();
			return { user: sanitize(user) };
		}
		if (m === "POST" && pathname === "/api/auth/onboarding/submit") {
			const { db, user } = auth();
			user.onboarding = user.onboarding || {};
			user.onboarding.applicationSubmitted = true;
			addAudit(user.id, "APPLICATION_SUBMITTED", "user", user.id, "Submitted application");
			for (const sup of db.users.filter((u) => privileged(u))) notify(sup.id, "application", "Application submitted", `${user.fullName} submitted their onboarding application.`, "dashboard");
			touch();
			return { user: sanitize(user) };
		}
		if (m === "GET" && pathname === "/api/users") {
			const { db, user } = auth();
			return { users: db.users.map((u) => publicUser(u, user)) };
		}
		const statusRoute = match(pathname, "/api/admin/users/:id/status");
		if (m === "PATCH" && statusRoute) {
			const { db, user } = auth();
			requirePerm(user, "canApproveMembers");
			if (![
				"approved",
				"pending",
				"rejected",
				"suspended"
			].includes(body?.status)) fail(400, "Invalid status");
			const target = db.users.find((u) => u.id === statusRoute.id);
			if (!target) fail(404, "User not found");
			if (target.role === "admin" && user.role !== "admin") fail(403, "Only administrators can modify administrator accounts.");
			target.status = body.status;
			if (body.status === "suspended" || body.status === "rejected") {
				for (const s of db.sessions) if (s.userId === target.id && s.status === "active") revokeSession(s, user.fullName);
			}
			addAudit(user.id, "USER_STATUS_CHANGED", "user", target.id, `Status → ${body.status}`);
			notify(target.id, "application", `Account ${body.status}`, `${user.fullName} set your status to ${body.status}.`, "dashboard");
			touch();
			return { user: sanitize(target) };
		}
		const roleRoute = match(pathname, "/api/admin/users/:id/role");
		if (m === "PATCH" && roleRoute) {
			const { db, user } = auth();
			if (user.role !== "admin") fail(403, "Insufficient permissions for this action");
			if (![
				"member",
				"supervisor",
				"admin"
			].includes(body?.role)) fail(400, "Invalid role");
			const target = db.users.find((u) => u.id === roleRoute.id);
			if (!target) fail(404, "User not found");
			if (target.id === user.id && body.role !== "admin") fail(400, "You cannot demote your own administrator account.");
			target.role = body.role;
			if (body.role === "supervisor" && !target.supervisorPermissions) target.supervisorPermissions = { ...DEFAULT_PERMS };
			addAudit(user.id, "USER_ROLE_CHANGED", "user", target.id, `Role → ${body.role}`);
			notify(target.id, "security", `Role updated: ${body.role}`, `${user.fullName} updated your role.`, "security");
			touch();
			return { user: sanitize(target) };
		}
		const permRoute = match(pathname, "/api/admin/users/:id/permissions");
		if (m === "PATCH" && permRoute) {
			const { db, user } = auth();
			if (user.role !== "admin") fail(403, "Insufficient permissions for this action");
			const target = db.users.find((u) => u.id === permRoute.id);
			if (!target) fail(404, "User not found");
			const incoming = body?.permissions || {};
			target.supervisorPermissions = {
				canApproveMembers: Boolean(incoming.canApproveMembers),
				canManageAssessments: Boolean(incoming.canManageAssessments),
				canViewSessions: Boolean(incoming.canViewSessions),
				canRevokeSessions: Boolean(incoming.canRevokeSessions),
				canManageTasksAndGroups: Boolean(incoming.canManageTasksAndGroups),
				canViewAnalytics: Boolean(incoming.canViewAnalytics),
				canManageIntegrations: Boolean(incoming.canManageIntegrations)
			};
			addAudit(user.id, "SUPERVISOR_PERMISSIONS_UPDATED", "user", target.id, `Updated permissions for ${target.fullName}`);
			touch();
			return { user: sanitize(target) };
		}
		const delUser = match(pathname, "/api/admin/users/:id");
		if (m === "DELETE" && delUser && !pathname.includes("/status") && !pathname.includes("/role")) {
			const { db, user } = auth();
			if (user.role !== "admin") fail(403, "Insufficient permissions for this action");
			if (delUser.id === user.id) fail(400, "You cannot delete your own currently signed-in administrator account.");
			const idx = db.users.findIndex((u) => u.id === delUser.id);
			if (idx < 0) fail(404, "User not found");
			const removed = db.users[idx];
			for (const s of db.sessions) if (s.userId === removed.id && s.status === "active") revokeSession(s, user.fullName);
			db.users.splice(idx, 1);
			addAudit(user.id, "USER_DELETED", "user", removed.id, `Removed ${removed.email}`);
			touch();
			return { ok: true };
		}
		if (m === "GET" && pathname === "/api/sessions") {
			const { db, user, session } = auth();
			const canViewAll = hasPerm(user, "canViewSessions");
			return { sessions: db.sessions.filter((s) => canViewAll || s.userId === user.id).map((s) => {
				const owner = db.users.find((u) => u.id === s.userId);
				return {
					id: s.id,
					userId: s.userId,
					userName: owner?.fullName || "Unknown user",
					userEmail: owner?.email || "",
					userRole: owner?.role || "member",
					deviceType: s.deviceType,
					browser: s.browser,
					os: s.os,
					ipAddress: s.ipAddress,
					loginAt: s.loginAt,
					logoutAt: s.logoutAt,
					lastActivityAt: s.lastActivityAt,
					status: s.status,
					isUnusual: s.isUnusual,
					alertReason: s.alertReason,
					isCurrent: s.id === session.id
				};
			}) };
		}
		const delSession = match(pathname, "/api/sessions/:id");
		if (m === "DELETE" && delSession) {
			const { db, user } = auth();
			const target = db.sessions.find((s) => s.id === delSession.id);
			if (!target) fail(404, "Session not found");
			if (!hasPerm(user, "canRevokeSessions") && target.userId !== user.id) fail(403, "Not authorized to revoke this session");
			if (db.users.find((u) => u.id === target.userId)?.role === "admin" && user.role !== "admin" && target.userId !== user.id) fail(403, "Only an Administrator can revoke an Administrator session.");
			revokeSession(target, user.fullName);
			addAudit(user.id, "SESSION_REVOKED", "session", target.id, `Revoked ${target.browser} on ${target.os}`);
			notify(target.userId, "security", "Session terminated", `${user.fullName} revoked a ${target.browser} session.`, "security");
			touch();
			return { ok: true };
		}
		const revokeUser = match(pathname, "/api/sessions/revoke-user/:userId");
		if (m === "POST" && revokeUser) {
			const { db, user, session } = auth();
			requirePerm(user, "canRevokeSessions");
			const targetUser = db.users.find((u) => u.id === revokeUser.userId);
			if (!targetUser) fail(404, "User not found");
			if (targetUser.role === "admin" && user.role !== "admin") fail(403, "Only an Administrator can revoke an Administrator’s devices.");
			let revokedCount = 0;
			for (const s of db.sessions) if (s.userId === targetUser.id && s.status === "active" && s.id !== session.id) {
				revokeSession(s, user.fullName);
				revokedCount++;
			}
			addAudit(user.id, "USER_ALL_SESSIONS_REVOKED", "user", targetUser.id, `Revoked ${revokedCount} devices`);
			touch();
			return {
				ok: true,
				revokedCount
			};
		}
		if (m === "GET" && pathname === "/api/cv") {
			const { db, user } = auth();
			return { cv: db.cvs.find((c) => c.userId === user.id) || null };
		}
		if (m === "POST" && pathname === "/api/cv") {
			const { db, user } = auth();
			const idx = db.cvs.findIndex((c) => c.userId === user.id);
			const record = {
				id: idx >= 0 ? db.cvs[idx].id : uid("cv"),
				userId: user.id,
				fullName: body.fullName || user.fullName,
				headline: body.headline || user.desiredRole,
				email: body.email || user.email,
				phone: body.phone || user.phone || "",
				location: body.location || "",
				summary: body.summary || "",
				education: Array.isArray(body.education) ? body.education : [],
				experience: Array.isArray(body.experience) ? body.experience : [],
				projects: Array.isArray(body.projects) ? body.projects : [],
				achievements: Array.isArray(body.achievements) ? body.achievements : [],
				technicalSkills: Array.isArray(body.technicalSkills) ? body.technicalSkills : [],
				softSkills: Array.isArray(body.softSkills) ? body.softSkills : [],
				uploadedFileName: body.uploadedFileName,
				uploadedFileMime: body.uploadedFileMime,
				rawExtractedText: body.rawExtractedText,
				updatedAt: nowIso()
			};
			if (idx >= 0) db.cvs[idx] = record;
			else db.cvs.push(record);
			user.onboarding = user.onboarding || {};
			user.onboarding.cvCompleted = true;
			addAudit(user.id, "CV_SAVED", "cv", record.id, "Saved CV");
			touch();
			return {
				cv: record,
				onboarding: user.onboarding
			};
		}
		if (m === "POST" && pathname === "/api/cv/upload") {
			auth();
			const { fileName, mimeType, base64Data } = body || {};
			if (!fileName || !base64Data) fail(400, "File name and file payload are required.");
			let bytes;
			try {
				bytes = decodeBase64(String(base64Data));
			} catch {
				fail(400, "Could not read the uploaded file.");
			}
			if (bytes.byteLength > 6291456) fail(400, "File exceeds 6 MB limit.");
			const lower = String(fileName).toLowerCase();
			let extractedText = "";
			if (lower.endsWith(".txt") || lower.endsWith(".md")) extractedText = new TextDecoder().decode(bytes);
			else if (lower.endsWith(".pdf") || lower.endsWith(".docx")) extractedText = printable(bytes) || `Uploaded ${fileName} (${Math.round(bytes.byteLength / 1024)} KB).`;
			else fail(400, "Supported CV formats are PDF, DOCX, TXT, or MD.");
			return {
				fileName,
				mimeType: mimeType || "application/octet-stream",
				extractedText,
				pdfBase64: lower.endsWith(".pdf") ? String(base64Data) : void 0
			};
		}
		if (m === "POST" && pathname === "/api/ai/cv-analyze") {
			auth();
			return { analysis: analyzeCv(body?.cv || {}, body?.language === "ar" ? "ar" : "en") };
		}
		if (m === "GET" && pathname === "/api/assessments/captcha") {
			const { db } = auth();
			const a = 2 + Math.floor(Math.random() * 8);
			const b = 1 + Math.floor(Math.random() * 8);
			const challenge = {
				id: uid("cap"),
				answer: String(a + b)
			};
			db.captchas = (db.captchas || []).slice(-20);
			db.captchas.push(challenge);
			saveDb();
			const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="220" height="64" viewBox="0 0 220 64"><rect width="220" height="64" rx="8" fill="#0e1934"/><text x="18" y="40" fill="#00D4FF" font-family="monospace" font-size="22">${a} + ${b} = ?</text></svg>`;
			return {
				challengeId: challenge.id,
				svgDataUri: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`
			};
		}
		if (m === "POST" && pathname === "/api/assessments/captcha/verify") {
			const { db, user } = auth();
			if (!body?.challengeId || body.answer === void 0 || body.answer === "") fail(400, "Challenge ID and answer are required.");
			const challenge = (db.captchas || []).find((c) => c.id === body.challengeId);
			if (!challenge || String(challenge.answer) !== String(body.answer).trim()) fail(400, "Incorrect CAPTCHA answer. Please try a new challenge.");
			db.captchas = db.captchas.filter((c) => c.id !== challenge.id);
			user.humanVerified = true;
			user.onboarding = user.onboarding || {};
			user.onboarding.humanVerified = true;
			addAudit(user.id, "HUMAN_VERIFIED", "user", user.id, "Passed human verification");
			touch();
			return {
				verified: true,
				user: sanitize(user)
			};
		}
		if (m === "GET" && pathname === "/api/assessments") {
			const { db, user } = auth();
			const isPriv = privileged(user);
			return {
				assessments: db.assessments.filter((a) => isPriv || a.assignedUserIds.includes(user.id) || a.assignedUserIds.length === 0).map((a) => ({
					...a,
					questions: isPriv ? a.questions : a.questions.map(({ correctAnswer, ...rest }) => rest)
				})),
				attempts: db.attempts.filter((att) => isPriv || att.userId === user.id)
			};
		}
		if (m === "POST" && pathname === "/api/assessments") {
			const { db, user } = auth();
			requirePerm(user, "canManageAssessments");
			if (!body?.title || !Array.isArray(body.questions) || body.questions.length === 0) fail(400, "Assessment title and at least one question are required.");
			const assessment = {
				id: uid("asm"),
				title: String(body.title).trim(),
				titleAr: body.titleAr,
				description: String(body.description || ""),
				category: String(body.category || "General"),
				timeLimitMinutes: Number(body.timeLimitMinutes) || 20,
				maxAttempts: Number(body.maxAttempts) || 2,
				passingScore: Number(body.passingScore) || 70,
				assignedUserIds: Array.isArray(body.assignedUserIds) ? body.assignedUserIds.map(String) : [],
				randomizeQuestions: Boolean(body.randomizeQuestions),
				questions: body.questions.map((q, idx) => ({
					id: q.id || `q-${idx + 1}-${uid("x").slice(-4)}`,
					type: q.type,
					prompt: String(q.prompt),
					promptAr: q.promptAr,
					options: Array.isArray(q.options) ? q.options.map(String) : void 0,
					correctAnswer: q.correctAnswer ? String(q.correctAnswer) : void 0,
					points: Number(q.points) || 10
				})),
				createdBy: user.id,
				createdAt: nowIso()
			};
			db.assessments.unshift(assessment);
			for (const id of assessment.assignedUserIds) notify(id, "assessment", "New assessment assigned", `You were assigned “${assessment.title}”.`, "assessments");
			addAudit(user.id, "ASSESSMENT_CREATED", "assessment", assessment.id, assessment.title);
			touch();
			return { assessment };
		}
		const startAsm = match(pathname, "/api/assessments/:id/start");
		if (m === "POST" && startAsm) {
			const { db, user } = auth();
			if (!user.humanVerified) fail(403, "Complete Human Verification (CAPTCHA) before starting an assessment.");
			const assessment = db.assessments.find((a) => a.id === startAsm.id);
			if (!assessment) fail(404, "Assessment not found");
			if (db.attempts.filter((att) => att.assessmentId === assessment.id && att.userId === user.id).length >= assessment.maxAttempts) fail(400, `Attempt limit (${assessment.maxAttempts}) reached for this assessment.`);
			const questions = [...assessment.questions];
			if (assessment.randomizeQuestions) for (let i = questions.length - 1; i > 0; i--) {
				const j = Math.floor(Math.random() * (i + 1));
				[questions[i], questions[j]] = [questions[j], questions[i]];
			}
			const attempt = {
				id: uid("att"),
				assessmentId: assessment.id,
				userId: user.id,
				startedAt: nowIso(),
				answers: [],
				autoScore: 0,
				manualScore: 0,
				totalScore: 0,
				maxScore: questions.reduce((sum, q) => sum + q.points, 0),
				status: "in_progress"
			};
			db.attempts.unshift(attempt);
			touch();
			return {
				attempt,
				questions: questions.map(({ correctAnswer, ...rest }) => rest)
			};
		}
		const submitAtt = match(pathname, "/api/assessments/attempts/:attemptId/submit");
		if (m === "POST" && submitAtt) {
			const { db, user } = auth();
			const attempt = db.attempts.find((a) => a.id === submitAtt.attemptId && a.userId === user.id);
			if (!attempt) fail(404, "Attempt not found");
			if (attempt.status !== "in_progress") fail(400, "Attempt has already been submitted.");
			const assessment = db.assessments.find((a) => a.id === attempt.assessmentId);
			if (!assessment) fail(404, "Assessment not found");
			const submitted = new Map((Array.isArray(body?.answers) ? body.answers : []).map((item) => [item.questionId, String(item.answer || "")]));
			let autoScore = 0;
			let needsManual = false;
			attempt.answers = assessment.questions.map((q) => {
				const answer = submitted.get(q.id) || "";
				if (q.type === "mcq" || q.type === "true_false") {
					const isCorrect = answer.trim().toLowerCase() === String(q.correctAnswer || "").trim().toLowerCase();
					const pts = isCorrect ? q.points : 0;
					autoScore += pts;
					return {
						questionId: q.id,
						answer,
						isCorrect,
						pointsAwarded: pts
					};
				}
				needsManual = true;
				return {
					questionId: q.id,
					answer,
					pointsAwarded: 0
				};
			});
			attempt.autoScore = autoScore;
			attempt.totalScore = autoScore;
			attempt.submittedAt = nowIso();
			attempt.status = needsManual ? "pending_review" : "graded";
			if (!needsManual) attempt.passed = attempt.maxScore > 0 && attempt.totalScore / attempt.maxScore * 100 >= assessment.passingScore;
			user.onboarding = user.onboarding || {};
			user.onboarding.assessmentCompleted = true;
			addAudit(user.id, "ASSESSMENT_SUBMITTED", "attempt", attempt.id, `Submitted ${assessment.title}`);
			if (needsManual) for (const sup of db.users.filter((u) => privileged(u))) notify(sup.id, "assessment", "Assessment needs review", `${user.fullName} submitted “${assessment.title}”.`, "assessments");
			touch();
			return {
				attempt,
				onboarding: user.onboarding
			};
		}
		const gradeAtt = match(pathname, "/api/assessments/attempts/:attemptId/grade");
		if (m === "POST" && gradeAtt) {
			const { db, user } = auth();
			requirePerm(user, "canManageAssessments");
			const attempt = db.attempts.find((a) => a.id === gradeAtt.attemptId);
			if (!attempt) fail(404, "Attempt not found");
			const assessment = db.assessments.find((a) => a.id === attempt.assessmentId);
			if (!assessment) fail(404, "Assessment not found");
			const grades = body?.grades || [];
			const gradeMap = new Map(grades.map((g) => [g.questionId, g]));
			let manualScore = 0;
			attempt.answers = attempt.answers.map((ans) => {
				const q = assessment.questions.find((item) => item.id === ans.questionId);
				if (q && (q.type === "written" || q.type === "scenario")) {
					const g = gradeMap.get(q.id);
					const awarded = g ? Math.max(0, Math.min(q.points, Number(g.pointsAwarded) || 0)) : ans.pointsAwarded;
					manualScore += awarded;
					return {
						...ans,
						pointsAwarded: awarded,
						feedback: g?.feedback
					};
				}
				return ans;
			});
			attempt.manualScore = manualScore;
			attempt.totalScore = attempt.autoScore + manualScore;
			attempt.passed = attempt.maxScore > 0 && attempt.totalScore / attempt.maxScore * 100 >= assessment.passingScore;
			attempt.status = "graded";
			attempt.reviewedBy = user.id;
			addAudit(user.id, "ASSESSMENT_GRADED", "attempt", attempt.id, `Graded ${attempt.totalScore}/${attempt.maxScore}`);
			notify(attempt.userId, "assessment", "Assessment graded", `“${assessment.title}” scored ${attempt.totalScore}/${attempt.maxScore}.`, "assessments");
			touch();
			return { attempt };
		}
		if (m === "GET" && pathname === "/api/conversations") {
			const { db, user } = auth();
			return {
				conversations: db.conversations.filter((c) => c.memberIds.includes(user.id)).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)),
				onlineUserIds: [...online]
			};
		}
		if (m === "POST" && pathname === "/api/conversations") {
			const { db, user } = auth();
			const members = Array.from(/* @__PURE__ */ new Set([user.id, ...Array.isArray(body?.memberIds) ? body.memberIds.map(String) : []]));
			if (body?.type === "direct" && members.length === 2) {
				const existing = db.conversations.find((c) => c.type === "direct" && c.memberIds.length === 2 && members.every((id) => c.memberIds.includes(id)));
				if (existing) return { conversation: existing };
			}
			const other = members.length === 2 ? db.users.find((u) => u.id !== user.id && members.includes(u.id)) : null;
			const conv = {
				id: uid("conv"),
				type: body?.type === "direct" ? "direct" : "group",
				name: body?.name ? String(body.name).trim() : other ? `${user.fullName} & ${other.fullName}` : "Team channel",
				description: body?.description,
				memberIds: members,
				adminIds: [user.id],
				pinnedMessageIds: [],
				createdAt: nowIso(),
				updatedAt: nowIso()
			};
			db.conversations.unshift(conv);
			emitLive("conversation:new", conv);
			touch();
			return { conversation: conv };
		}
		const patchConv = match(pathname, "/api/conversations/:id");
		if (m === "PATCH" && patchConv) {
			const { db, user } = auth();
			const conv = db.conversations.find((c) => c.id === patchConv.id);
			if (!conv || !conv.memberIds.includes(user.id)) fail(404, "Conversation not found");
			if (!(conv.adminIds.includes(user.id) || user.role === "admin")) fail(403, "Only group administrators can update group settings.");
			if (body?.name) conv.name = String(body.name).trim();
			if (body?.announcement !== void 0) conv.announcement = String(body.announcement);
			if (Array.isArray(body?.memberIds)) conv.memberIds = Array.from(/* @__PURE__ */ new Set([...conv.adminIds, ...body.memberIds.map(String)]));
			if (body?.togglePinMessageId) {
				const id = String(body.togglePinMessageId);
				conv.pinnedMessageIds = conv.pinnedMessageIds.includes(id) ? conv.pinnedMessageIds.filter((p) => p !== id) : [...conv.pinnedMessageIds, id];
			}
			conv.updatedAt = nowIso();
			emitLive("conversation:updated", conv);
			touch();
			return { conversation: conv };
		}
		const listMsg = match(pathname, "/api/conversations/:id/messages");
		if (m === "GET" && listMsg) {
			const { db, user } = auth();
			const conv = db.conversations.find((c) => c.id === listMsg.id);
			if (!conv || !conv.memberIds.includes(user.id)) fail(404, "Conversation not found");
			const query = (q.get("q") || "").trim().toLowerCase();
			return { messages: db.messages.filter((msg) => msg.conversationId === conv.id && (!query || String(msg.content || "").toLowerCase().includes(query))) };
		}
		const postMsg = match(pathname, "/api/conversations/:id/messages");
		if (m === "POST" && postMsg) {
			const { db, user } = auth();
			const conv = db.conversations.find((c) => c.id === postMsg.id);
			if (!conv || !conv.memberIds.includes(user.id)) fail(404, "Conversation not found");
			if (!body?.content && !body?.attachment) fail(400, "Message content or attachment is required.");
			const msg = {
				id: uid("msg"),
				conversationId: conv.id,
				senderId: user.id,
				content: String(body.content || "").trim(),
				replyToId: body.replyToId ? String(body.replyToId) : void 0,
				reactions: {},
				attachment: body.attachment?.name && body.attachment?.dataUrl ? body.attachment : void 0,
				readBy: [user.id],
				createdAt: nowIso()
			};
			db.messages.push(msg);
			conv.updatedAt = msg.createdAt;
			for (const memberId of conv.memberIds) if (memberId !== user.id) notify(memberId, "message", conv.type === "group" ? `#${conv.name}` : user.fullName, msg.content || `File: ${msg.attachment?.name}`, "messages");
			emitLive("message:new", msg);
			touch();
			return { message: msg };
		}
		const react = match(pathname, "/api/messages/:id/react");
		if (m === "POST" && react) {
			const { db, user } = auth();
			const msg = db.messages.find((item) => item.id === react.id);
			if (!msg) fail(404, "Message not found");
			const conv = db.conversations.find((c) => c.id === msg.conversationId);
			if (!conv || !conv.memberIds.includes(user.id)) fail(403, "Not permitted");
			const emoji = String(body?.emoji || "👍");
			const existing = msg.reactions[emoji] || [];
			msg.reactions[emoji] = existing.includes(user.id) ? existing.filter((id) => id !== user.id) : [...existing, user.id];
			emitLive("message:reaction", {
				messageId: msg.id,
				reactions: msg.reactions
			});
			touch();
			return { message: msg };
		}
		const readConv = match(pathname, "/api/conversations/:id/read");
		if (m === "POST" && readConv) {
			const { db, user } = auth();
			const conv = db.conversations.find((c) => c.id === readConv.id);
			if (!conv || !conv.memberIds.includes(user.id)) fail(404, "Conversation not found");
			let changed = false;
			for (const msg of db.messages) if (msg.conversationId === conv.id && !msg.readBy.includes(user.id)) {
				msg.readBy.push(user.id);
				changed = true;
			}
			if (changed) {
				emitLive("message:read", {
					conversationId: conv.id,
					userId: user.id
				});
				saveDb();
			}
			return { ok: true };
		}
		if (m === "GET" && pathname === "/api/tasks") {
			const { db } = auth();
			return {
				projects: db.projects,
				tasks: db.tasks
			};
		}
		if (m === "POST" && pathname === "/api/tasks") {
			const { db, user } = auth();
			if (!body?.title) fail(400, "Task title is required.");
			const assigneeId = body.assigneeId ? String(body.assigneeId) : user.id;
			const item = {
				id: uid("tsk"),
				projectId: body.projectId ? String(body.projectId) : db.projects[0]?.id,
				title: String(body.title).trim(),
				description: String(body.description || ""),
				assigneeId,
				reporterId: user.id,
				status: "backlog",
				priority: [
					"low",
					"medium",
					"high",
					"urgent"
				].includes(body.priority) ? body.priority : "medium",
				progress: 0,
				deadline: body.deadline || new Date(Date.now() + 6048e5).toISOString().slice(0, 10),
				comments: [],
				createdAt: nowIso(),
				updatedAt: nowIso()
			};
			db.tasks.unshift(item);
			if (assigneeId !== user.id) notify(assigneeId, "task", "New task assigned", `${user.fullName} assigned “${item.title}” (due ${item.deadline}).`, "tasks");
			addAudit(user.id, "TASK_CREATED", "task", item.id, item.title);
			touch();
			return { task: item };
		}
		const patchTask = match(pathname, "/api/tasks/:id");
		if (m === "PATCH" && patchTask) {
			const { db } = auth();
			const item = db.tasks.find((t) => t.id === patchTask.id);
			if (!item) fail(404, "Task not found");
			if (body.status && [
				"backlog",
				"in_progress",
				"in_review",
				"done"
			].includes(body.status)) {
				item.status = body.status;
				if (body.status === "done") item.progress = 100;
			}
			if (body.priority && [
				"low",
				"medium",
				"high",
				"urgent"
			].includes(body.priority)) item.priority = body.priority;
			if (body.progress !== void 0) item.progress = Math.max(0, Math.min(100, Number(body.progress)));
			if (body.assigneeId) item.assigneeId = String(body.assigneeId);
			if (body.title) item.title = String(body.title).trim();
			if (body.description !== void 0) item.description = String(body.description);
			if (body.deadline) item.deadline = String(body.deadline);
			item.updatedAt = nowIso();
			touch();
			return { task: item };
		}
		const commentTask = match(pathname, "/api/tasks/:id/comments");
		if (m === "POST" && commentTask) {
			const { db, user } = auth();
			const item = db.tasks.find((t) => t.id === commentTask.id);
			if (!item) fail(404, "Task not found");
			const text = String(body?.text || "").trim();
			if (!text) fail(400, "Comment text is required.");
			const comment = {
				id: uid("cmt"),
				authorId: user.id,
				text,
				createdAt: nowIso()
			};
			item.comments.push(comment);
			item.updatedAt = comment.createdAt;
			touch();
			return {
				task: item,
				comment
			};
		}
		if (m === "GET" && pathname === "/api/meetings") {
			const { db } = auth();
			return {
				meetings: db.meetings,
				integrations: db.integrations
			};
		}
		if (m === "POST" && pathname === "/api/meetings") {
			const { db, user } = auth();
			if (!body?.title || !body?.startTime || !body?.endTime) fail(400, "Meeting title, start time, and end time are required.");
			const provider = body.provider === "google_meet" || body.provider === "zoom" ? body.provider : "internal";
			if (provider !== "internal") {
				if (!db.integrations.find((i) => i.provider === (provider === "google_meet" ? "google" : "zoom"))?.connected && !body.meetingUrl) fail(400, `${provider === "google_meet" ? "Google" : "Zoom"} integration is not connected yet. Connect credentials first or provide a verified meeting join link.`);
			}
			const participants = Array.from(/* @__PURE__ */ new Set([user.id, ...Array.isArray(body.participantIds) ? body.participantIds.map(String) : []]));
			const meeting = {
				id: uid("mtg"),
				title: String(body.title).trim(),
				description: String(body.description || ""),
				organizerId: user.id,
				participantIds: participants,
				startTime: String(body.startTime),
				endTime: String(body.endTime),
				provider,
				meetingUrl: body.meetingUrl ? String(body.meetingUrl).trim() : void 0,
				createdAt: nowIso()
			};
			db.meetings.unshift(meeting);
			for (const pid of participants) if (pid !== user.id) notify(pid, "meeting", "Meeting invitation", `${user.fullName} invited you to “${meeting.title}”.`, "meetings");
			touch();
			return { meeting };
		}
		if (m === "POST" && pathname === "/api/integrations/verify") {
			const { db, user } = auth();
			requirePerm(user, "canManageIntegrations");
			const integ = db.integrations.find((i) => i.provider === body?.provider);
			if (!integ) fail(400, "Unsupported integration provider.");
			if (body.provider === "google") {
				if (!body.accessToken) fail(400, "A real Google OAuth access token is required for verification.");
				try {
					const resp = await fetch(`https://oauth2.googleapis.com/tokeninfo?access_token=${encodeURIComponent(String(body.accessToken))}`);
					if (!resp.ok) fail(400, "Google token verification failed. Token is invalid or expired.");
					const info = await resp.json();
					integ.connected = true;
					integ.accountEmail = info.email || user.email;
					integ.scopes = info.scope ? info.scope.split(" ") : [];
					integ.verifiedAt = nowIso();
					integ.note = `Verified Google account ${integ.accountEmail}`;
					touch();
					return { integration: integ };
				} catch (err) {
					if (err instanceof ApiError) throw err;
					fail(502, "Unable to reach Google to verify that token.");
				}
			}
			if (body.provider === "zoom") {
				if (!body.zoomAccountId || !body.zoomClientId || !body.zoomClientSecret) fail(400, "Zoom Account ID, Client ID, and Client Secret are required.");
				try {
					const basic = btoa(`${body.zoomClientId}:${body.zoomClientSecret}`);
					const resp = await fetch(`https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${encodeURIComponent(String(body.zoomAccountId))}`, {
						method: "POST",
						headers: { Authorization: `Basic ${basic}` }
					});
					if (!resp.ok) fail(400, "Zoom OAuth credential verification failed. Check Account ID / Client keys.");
					const data = await resp.json();
					integ.connected = true;
					integ.scopes = data.scope ? data.scope.split(" ") : ["meeting:write"];
					integ.verifiedAt = nowIso();
					integ.note = `Verified Zoom account ${body.zoomAccountId}`;
					touch();
					return { integration: integ };
				} catch (err) {
					if (err instanceof ApiError) throw err;
					fail(502, "Unable to reach Zoom to verify those credentials.");
				}
			}
			fail(400, "Unsupported integration provider.");
		}
		if (m === "POST" && pathname === "/api/integrations/disconnect") {
			const { db, user } = auth();
			if (user.role !== "admin") fail(403, "Insufficient permissions for this action");
			const integ = db.integrations.find((i) => i.provider === body?.provider);
			if (!integ) fail(404, "Integration not found");
			integ.connected = false;
			integ.accountEmail = void 0;
			integ.scopes = [];
			integ.verifiedAt = void 0;
			integ.note = `${body.provider === "google" ? "Google" : "Zoom"} disconnected.`;
			touch();
			return { integration: integ };
		}
		if (m === "GET" && pathname === "/api/notifications") {
			const { db, user } = auth();
			return { notifications: db.notifications.filter((n) => n.userId === user.id).slice(0, 50) };
		}
		if (m === "POST" && pathname === "/api/notifications/read-all") {
			const { db, user } = auth();
			for (const n of db.notifications) if (n.userId === user.id) n.read = true;
			touch();
			return { ok: true };
		}
		if (m === "POST" && pathname === "/api/ai/assistant") {
			const { user } = auth();
			if (!body?.message) fail(400, "Message is required.");
			return { reply: assistantReply(user, String(body.message)) };
		}
		if (m === "GET" && pathname === "/api/analytics") {
			const { user } = auth();
			return analyticsFor(user);
		}
		fail(404, `Unknown route ${m} ${pathname}`);
	} catch (err) {
		if (err instanceof ApiError) throw err;
		fail(500, err instanceof Error ? err.message : "Workspace request failed.");
	}
}
async function readText(path) {
	const res = await dispatch("GET", path);
	if (res && typeof res === "object" && "__text" in res) return String(res.__text);
	return typeof res === "string" ? res : JSON.stringify(res);
}
async function apiRequest(path, options = {}) {
	const method = (options.method || "GET").toUpperCase();
	let body = void 0;
	if (typeof options.body === "string" && options.body) try {
		body = JSON.parse(options.body);
	} catch {
		body = void 0;
	}
	try {
		const data = await dispatch(method, path, body);
		if (data && typeof data === "object" && "__text" in data) return data.__text;
		return data;
	} catch (err) {
		const error = err;
		if (!error.payload) error.payload = { error: error.message };
		throw error;
	}
}
async function downloadTextFile(path, filename, mime) {
	const text = await readText(path);
	const blob = new Blob([text], { type: mime });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	document.body.appendChild(link);
	link.click();
	link.remove();
	setTimeout(() => URL.revokeObjectURL(url), 4e3);
}
async function downloadProjectZip() {
	const blob = await buildWorkspaceZip();
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = "kaviro-platform-web.zip";
	document.body.appendChild(link);
	link.click();
	link.remove();
	setTimeout(() => URL.revokeObjectURL(url), 4e3);
}
var translations = {
	en: {
		brand: "KAVIRO",
		tagline: "AI-Powered Team Management Platform",
		nav: {
			dashboard: "Dashboard",
			"design-system": "Design System",
			"cv-builder": "AI CV Builder",
			assessments: "Assessments",
			messages: "Messages",
			tasks: "Tasks & Projects",
			meetings: "Meetings & Sync",
			security: "Sessions & Security",
			analytics: "Reports & Export",
			profile: "Profile & 2FA"
		},
		actions: {
			signIn: "Sign In",
			register: "Create Account",
			signOut: "Sign Out",
			save: "Save Changes",
			cancel: "Cancel",
			approve: "Approve",
			reject: "Reject",
			revoke: "Force Logout",
			downloadZip: "Download Website (.zip)",
			downloadCsv: "Export CSV",
			askAi: "KAVIRO AI",
			lightMode: "Light Mode",
			darkMode: "Dark Mode"
		},
		dashboard: {
			welcome: "Workspace Overview",
			subtitle: "Unified control center for team onboarding, assessments, projects, and security telemetry.",
			totalMembers: "Total Members",
			activeMembers: "Approved Active",
			pendingApps: "Pending Applications",
			securityAlerts: "Unusual Logins",
			onboardingTitle: "Member Onboarding Pipeline",
			onboardingSteps: [
				"Profile completion",
				"CV creation or upload",
				"Human verification",
				"Assigned skill assessment",
				"Application submission"
			],
			submitApplication: "Submit Application",
			applicationSubmitted: "Application Submitted",
			pendingQueue: "Pending Member Approvals",
			recentActivity: "Recent Audit Activity"
		},
		designSystem: {
			title: "KAVIRO Design System",
			subtitle: "Visual architecture anchored to the official KAVIRO brand mark, Blue Dark surfaces, and bilingual RTL/LTR typography."
		}
	},
	ar: {
		brand: "KAVIRO",
		tagline: "منصة إدارة الفرق الذكية المدعومة بالذكاء الاصطناعي",
		nav: {
			dashboard: "لوحة التحكم",
			"design-system": "نظام التصميم",
			"cv-builder": "منشئ السيرة الذاتية",
			assessments: "الاختبارات والتقييم",
			messages: "المراسلات الفورية",
			tasks: "المهام والمشاريع",
			meetings: "الاجتماعات والتكامل",
			security: "الجلسات والأمان",
			analytics: "التقارير والتنزيل",
			profile: "الملف الشخصي و 2FA"
		},
		actions: {
			signIn: "تسجيل الدخول",
			register: "إنشاء حساب",
			signOut: "تسجيل الخروج",
			save: "حفظ التغييرات",
			cancel: "إلغاء",
			approve: "موافقة",
			reject: "رفض",
			revoke: "إنهاء الجلسة فوراً",
			downloadZip: "تنزيل الموقع (.zip)",
			downloadCsv: "تصدير CSV",
			askAi: "مساعد KAVIRO",
			lightMode: "الوضع الفاتح",
			darkMode: "الوضع الداكن"
		},
		dashboard: {
			welcome: "مركز عمليات الفريق",
			subtitle: "لوحة تحكم موحدة لمتابعة انضمام الأعضاء، التقييمات، المشاريع، ومراقبة الجلسات.",
			totalMembers: "إجمالي الأعضاء",
			activeMembers: "الأعضاء المعتمدون",
			pendingApps: "طلبات بانتظار المراجعة",
			securityAlerts: "تنبيهات دخول غير معتادة",
			onboardingTitle: "مسار تأهيل العضو الجديد",
			onboardingSteps: [
				"استكمال الملف الشخصي",
				"إنشاء أو رفع السيرة الذاتية",
				"التحقق البشري (CAPTCHA)",
				"إتمام اختبار المهارات المخصص",
				"تقديم طلب الانضمام النهائي"
			],
			submitApplication: "تقديم الطلب النهائي",
			applicationSubmitted: "تم تقديم الطلب بنجاح",
			pendingQueue: "طلبات الانضمام المعلقة",
			recentActivity: "أحدث سجلات التدقيق والنشاط"
		},
		designSystem: {
			title: "نظام تصميم KAVIRO",
			subtitle: "الهوية البصرية المشتقة مباشرة من شعار KAVIRO الرسمي، مع ألوان الأزرق الداكن ودعم كامل للغة العربية RTL."
		}
	}
};
var LoadingScreen = ({ label = "Initializing workspace" }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "min-h-screen w-full bg-[#040814] flex flex-col items-center justify-center px-6",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-xs flex flex-col items-center gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-56 p-3 rounded-2xl bg-[#02050d] border border-blue-500/25 shadow-[0_20px_50px_-15px_rgba(29,122,252,0.45)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: KAVIRO_LOGO_SRC,
					alt: "KAVIRO",
					referrerPolicy: "no-referrer",
					className: "w-full h-auto object-contain"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-48 h-1 rounded-full bg-slate-800 overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-1/2 rounded-full bg-gradient-to-r from-[#1D7AFC] to-[#00D4FF] animate-pulse" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-slate-400 tracking-wide",
				children: label
			})
		]
	})
});
var AiAssistantWidget = ({ lang }) => {
	const isAr = lang === "ar";
	const [open, setOpen] = (0, import_react.useState)(false);
	const [input, setInput] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const greeting = isAr ? "مرحباً! أنا مساعد KAVIRO. اسألني عن السيرة، الاختبارات، المهام، أو الاجتماعات." : "Hello! I am KAVIRO AI. Ask about your CV, assessments, tasks, meetings, or security sessions.";
	const [messages, setMessages] = (0, import_react.useState)([{
		role: "assistant",
		text: greeting
	}]);
	(0, import_react.useEffect)(() => {
		setMessages((prev) => prev.length <= 1 ? [{
			role: "assistant",
			text: greeting
		}] : prev);
	}, [greeting]);
	const handleSend = async (e) => {
		e.preventDefault();
		const trimmed = input.trim();
		if (!trimmed || loading) return;
		const nextHistory = [...messages, {
			role: "user",
			text: trimmed
		}];
		setMessages(nextHistory);
		setInput("");
		setLoading(true);
		try {
			const res = await apiRequest("/api/ai/assistant", {
				method: "POST",
				body: JSON.stringify({
					message: trimmed,
					history: nextHistory
				})
			});
			setMessages([...nextHistory, {
				role: "assistant",
				text: res.reply
			}]);
		} catch (err) {
			setMessages([...nextHistory, {
				role: "assistant",
				text: err.message || "Unable to reach KAVIRO AI right now."
			}]);
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed bottom-5 end-5 z-40 no-print",
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-[340px] sm:w-[390px] h-[480px] rounded-2xl bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/30 shadow-2xl flex flex-col overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-4 py-3 bg-[#02050d] border-b border-blue-500/20 flex items-center justify-between text-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "w-4 h-4 text-[#00D4FF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-sm font-semibold",
							children: "KAVIRO AI"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpen(false),
						className: "p-1 text-slate-400 hover:text-white cursor-pointer",
						"aria-label": "Close AI assistant",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 p-3.5 space-y-3 overflow-y-auto",
					children: [messages.map((m, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `p-3 rounded-xl text-xs leading-relaxed whitespace-pre-wrap ${m.role === "user" ? "ms-8 bg-[#1D7AFC]/15 border border-blue-500/30 text-slate-900 dark:text-white" : "me-6 bg-slate-100 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20 text-slate-800 dark:text-slate-200"}`,
						children: m.text
					}, idx)), loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-[#1D7AFC] dark:text-[#00D4FF] px-2",
						children: isAr ? "جاري التفكير..." : "Thinking..."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSend,
					className: "p-3 border-t border-slate-200 dark:border-blue-500/15 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: input,
						onChange: (e) => setInput(e.target.value),
						placeholder: isAr ? "اسأل KAVIRO AI..." : "Ask KAVIRO AI in EN or AR...",
						className: "flex-1 px-3 py-2 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						size: "sm",
						type: "submit",
						disabled: loading,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5" })
					})]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
			onClick: () => setOpen(true),
			className: "rounded-full px-4 py-3 shadow-[0_12px_30px_-8px_rgba(0,212,255,0.65)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "مساعد KAVIRO" : "KAVIRO AI" })]
		})
	});
};
var NotificationsDrawer = ({ open, lang, notifications, onClose, onMarkAllRead, onNavigate }) => {
	if (!open) return null;
	const isAr = lang === "ar";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md h-full bg-white dark:bg-[#091124] border-s border-slate-200 dark:border-blue-500/20 flex flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-4 border-b border-slate-200 dark:border-blue-500/15 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 font-display font-semibold text-slate-900 dark:text-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "w-4 h-4 text-[#1D7AFC] dark:text-[#00D4FF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "مركز الإشعارات" : "Notifications Center" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
						size: "sm",
						onClick: onMarkAllRead,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تحديد الكل كمقروء" : "Mark Read" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto divide-y divide-slate-200 dark:divide-blue-500/15",
				children: notifications.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-8 text-center text-xs text-slate-500 dark:text-slate-400",
					children: isAr ? "لا توجد إشعارات جديدة." : "You are all caught up."
				}) : notifications.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						if (n.targetTab) onNavigate(n.targetTab);
						onClose();
					},
					className: `w-full text-start p-4 hover:bg-slate-50 dark:hover:bg-[#0e1934] transition-colors cursor-pointer ${n.read ? "opacity-70" : ""}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-slate-900 dark:text-white",
							children: n.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono-tabular text-[11px] text-slate-500",
							children: new Date(n.createdAt).toLocaleTimeString([], {
								hour: "2-digit",
								minute: "2-digit"
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-slate-600 dark:text-slate-300 leading-relaxed",
						children: n.body
					})]
				}, n.id))
			})]
		})
	});
};
var AuthView = ({ lang, theme, onToggleLang, onToggleTheme, onAuthenticated }) => {
	const isAr = lang === "ar";
	const [mode, setMode] = (0, import_react.useState)("login");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [info, setInfo] = (0, import_react.useState)(null);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [code, setCode] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [whatsapp, setWhatsapp] = (0, import_react.useState)("");
	const [desiredRole, setDesiredRole] = (0, import_react.useState)("");
	const [department, setDepartment] = (0, import_react.useState)("Engineering");
	const [skillsText, setSkillsText] = (0, import_react.useState)("");
	const [interestsText, setInterestsText] = (0, import_react.useState)("");
	const [avatarUrl, setAvatarUrl] = (0, import_react.useState)(void 0);
	const handleAvatarUpload = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		if (file.size > 15e5) {
			setError(isAr ? "حجم الصورة يجب أن يكون أقل من 1.5 ميجابايت." : "Profile photo must be under 1.5 MB.");
			return;
		}
		const reader = new FileReader();
		reader.onload = () => setAvatarUrl(String(reader.result || ""));
		reader.readAsDataURL(file);
	};
	const handleLogin = async (loginEmail = email, loginPass = password) => {
		setError(null);
		setInfo(null);
		setLoading(true);
		try {
			const res = await apiRequest("/api/auth/login", {
				method: "POST",
				body: JSON.stringify({
					email: loginEmail,
					password: loginPass
				})
			});
			if (res.requiresTwoFactor) {
				setEmail(res.email);
				setInfo(`${isAr ? "رمز التحقق الثنائي 2FA:" : "Two-factor verification code:"} ${res.twoFactorCodePreview}`);
				setMode("verify-2fa");
				return;
			}
			setAuthToken(res.token);
			onAuthenticated(res.user, res.token);
		} catch (err) {
			if (err.payload?.requiresEmailVerification) {
				setEmail(err.payload.email);
				setInfo(`${isAr ? "رمز تأكيد البريد الإلكتروني:" : "Email verification code:"} ${err.payload.verificationCodePreview}`);
				setMode("verify-email");
			} else setError(err.message);
		} finally {
			setLoading(false);
		}
	};
	const handleRegister = async (e) => {
		e.preventDefault();
		setError(null);
		setInfo(null);
		setLoading(true);
		try {
			const res = await apiRequest("/api/auth/register", {
				method: "POST",
				body: JSON.stringify({
					fullName,
					email,
					password,
					phone,
					whatsapp: whatsapp || void 0,
					avatarUrl,
					desiredRole,
					department,
					skills: skillsText.split(",").map((s) => s.trim()).filter(Boolean),
					interests: interestsText.split(",").map((s) => s.trim()).filter(Boolean),
					preferredLanguage: lang
				})
			});
			setInfo(`${isAr ? "تم إنشاء الحساب! رمز تفعيل البريد:" : "Account created! Verification code:"} ${res.verificationCodePreview}`);
			setMode("verify-email");
		} catch (err) {
			setError(err.message);
		} finally {
			setLoading(false);
		}
	};
	const handleVerifyEmail = async (e) => {
		e.preventDefault();
		setError(null);
		setLoading(true);
		try {
			const res = await apiRequest("/api/auth/verify-email", {
				method: "POST",
				body: JSON.stringify({
					email,
					code
				})
			});
			setAuthToken(res.token);
			onAuthenticated(res.user, res.token);
		} catch (err) {
			setError(err.message);
		} finally {
			setLoading(false);
		}
	};
	const handleVerify2FA = async (e) => {
		e.preventDefault();
		setError(null);
		setLoading(true);
		try {
			const res = await apiRequest("/api/auth/verify-2fa", {
				method: "POST",
				body: JSON.stringify({
					email,
					code
				})
			});
			setAuthToken(res.token);
			onAuthenticated(res.user, res.token);
		} catch (err) {
			setError(err.message);
		} finally {
			setLoading(false);
		}
	};
	const handleForgot = async (e) => {
		e.preventDefault();
		setError(null);
		setLoading(true);
		try {
			const res = await apiRequest("/api/auth/forgot-password", {
				method: "POST",
				body: JSON.stringify({ email })
			});
			setInfo(res.resetCodePreview ? `${isAr ? "رمز استعادة كلمة المرور:" : "Recovery code:"} ${res.resetCodePreview}` : res.message);
			setMode("reset");
		} catch (err) {
			setError(err.message);
		} finally {
			setLoading(false);
		}
	};
	const handleReset = async (e) => {
		e.preventDefault();
		setError(null);
		setLoading(true);
		try {
			await apiRequest("/api/auth/reset-password", {
				method: "POST",
				body: JSON.stringify({
					email,
					code,
					newPassword
				})
			});
			setInfo(isAr ? "تم تحديث كلمة المرور بنجاح." : "Password updated. Sign in with your new password.");
			setMode("login");
		} catch (err) {
			setError(err.message);
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: isAr ? "rtl" : "ltr",
		className: "min-h-screen w-full bg-slate-50 dark:bg-[#040814] flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "w-full px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-blue-500/15",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-9 w-16 rounded-lg bg-[#02050d] border border-blue-500/25 p-1 flex items-center justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: KAVIRO_LOGO_SRC,
						alt: "KAVIRO",
						referrerPolicy: "no-referrer",
						className: "h-full w-full object-contain"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display font-bold tracking-wider text-slate-900 dark:text-white",
					children: "KAVIRO"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
						size: "sm",
						type: "button",
						onClick: () => downloadProjectZip().catch((e) => setError(e.message)),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: isAr ? "تنزيل الموقع (.zip)" : "Download Site (.zip)"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
						size: "sm",
						onClick: onToggleTheme,
						children: [theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: theme === "dark" ? isAr ? "فاتح" : "Light" : isAr ? "داكن" : "Dark" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
						size: "sm",
						onClick: onToggleLang,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "English" : "العربية" })]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5 space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-2xl bg-[#02050d] border border-blue-500/25 p-6 shadow-[0_20px_60px_-20px_rgba(29,122,252,0.45)] flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: KAVIRO_LOGO_SRC,
							alt: "KAVIRO Official Logo",
							referrerPolicy: "no-referrer",
							className: "w-full max-w-[280px] h-auto object-contain"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white",
							children: isAr ? "بيئة العمل الذكية لإدارة الفرق والمواهب" : "Intelligent Team Operations & Talent Intelligence"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-slate-600 dark:text-slate-400 leading-relaxed",
							children: isAr ? "منصة ويب متكاملة تدعم تأهيل الأعضاء، تحليل السيرة الذاتية بالذكاء الاصطناعي، الاختبارات، المراسلات الفورية، ومراقبة الجلسات." : "Unified web workspace combining member onboarding, Gemini AI CV analysis, human verification, assessments, real-time chat, and security monitoring."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
						className: "p-4 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
							children: isAr ? "حسابات التقييم الفوري (كلمة المرور: Kaviro@2026)" : "Instant Role Access (Password: Kaviro@2026)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
									size: "sm",
									type: "button",
									onClick: () => handleLogin("admin@kaviro.ai", "Kaviro@2026"),
									children: "Admin"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
									size: "sm",
									type: "button",
									onClick: () => handleLogin("supervisor@kaviro.ai", "Kaviro@2026"),
									children: "Supervisor"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
									size: "sm",
									type: "button",
									onClick: () => handleLogin("member@kaviro.ai", "Kaviro@2026"),
									children: "Member"
								})
							]
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
				className: "lg:col-span-7 p-6 sm:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4 pb-5 border-b border-slate-200 dark:border-blue-500/15",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-bold text-slate-900 dark:text-white",
							children: mode === "login" ? isAr ? "تسجيل الدخول إلى KAVIRO" : "Sign In to KAVIRO" : mode === "register" ? isAr ? "إنشاء حساب عضو جديد" : "Create Team Member Account" : mode === "verify-email" ? isAr ? "تأكيد البريد الإلكتروني" : "Verify Email Address" : mode === "verify-2fa" ? isAr ? "التحقق بخطوتين (2FA)" : "Two-Factor Verification" : isAr ? "استعادة كلمة المرور" : "Recover Password"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2 text-xs",
							children: mode !== "login" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setError(null);
									setMode("login");
								},
								className: "text-[#1D7AFC] dark:text-[#00D4FF] font-medium hover:underline cursor-pointer",
								children: isAr ? "العودة للدخول" : "Back to Sign In"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setError(null);
									setMode("register");
								},
								className: "text-[#1D7AFC] dark:text-[#00D4FF] font-medium hover:underline cursor-pointer",
								children: isAr ? "تسجيل عضو جديد" : "Create Account"
							})
						})]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-300",
						children: error
					}),
					info && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 p-3 rounded-lg bg-blue-500/10 border border-blue-500/30 text-xs text-blue-700 dark:text-cyan-300",
						children: info
					}),
					mode === "login" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: (e) => {
							e.preventDefault();
							handleLogin();
						},
						className: "mt-6 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5",
								children: isAr ? "البريد الإلكتروني" : "Email Address"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "w-4 h-4 text-slate-400 absolute top-3 start-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									required: true,
									value: email,
									onChange: (e) => setEmail(e.target.value),
									placeholder: "name@company.com",
									className: "w-full ps-9 pe-3 py-2.5 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white focus:outline-none focus:border-[#00D4FF]"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-medium text-slate-600 dark:text-slate-300",
									children: isAr ? "كلمة المرور" : "Password"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMode("forgot"),
									className: "text-xs text-[#1D7AFC] dark:text-[#00D4FF] hover:underline cursor-pointer",
									children: isAr ? "نسيت كلمة المرور؟" : "Forgot password?"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "w-4 h-4 text-slate-400 absolute top-3 start-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									required: true,
									value: password,
									onChange: (e) => setPassword(e.target.value),
									placeholder: "••••••••",
									className: "w-full ps-9 pe-3 py-2.5 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white focus:outline-none focus:border-[#00D4FF]"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								type: "submit",
								disabled: loading,
								className: "w-full",
								children: loading ? isAr ? "جاري التحقق..." : "Signing in..." : isAr ? "تسجيل الدخول" : "Sign In"
							})
						]
					}),
					mode === "register" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleRegister,
						className: "mt-6 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
										children: isAr ? "الاسم الكامل *" : "Full Name *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-4 h-4 text-slate-400 absolute top-3 start-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											value: fullName,
											onChange: (e) => setFullName(e.target.value),
											className: "w-full ps-9 pe-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
										})]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
										children: isAr ? "البريد الإلكتروني *" : "Email Address *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "email",
										required: true,
										value: email,
										onChange: (e) => setEmail(e.target.value),
										className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
										children: isAr ? "كلمة المرور (8 أحرف+) *" : "Password (8+ chars) *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "password",
										required: true,
										minLength: 8,
										value: password,
										onChange: (e) => setPassword(e.target.value),
										className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
										children: isAr ? "رقم الهاتف *" : "Phone Number *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "w-4 h-4 text-slate-400 absolute top-3 start-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											required: true,
											value: phone,
											onChange: (e) => setPhone(e.target.value),
											className: "w-full ps-9 pe-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
										})]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
										children: isAr ? "رقم واتساب (اختياري)" : "WhatsApp Number (Optional)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: whatsapp,
										onChange: (e) => setWhatsapp(e.target.value),
										className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
										children: isAr ? "الدور المطلوب في الفريق *" : "Desired Team Role *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										value: desiredRole,
										onChange: (e) => setDesiredRole(e.target.value),
										placeholder: isAr ? "مطور واجهات / مصمم..." : "Frontend Engineer / Analyst...",
										className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
										children: isAr ? "القسم" : "Department"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: department,
										onChange: (e) => setDepartment(e.target.value),
										className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
										children: isAr ? "الصورة الشخصية (اختياري)" : "Profile Picture (Optional)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2 px-3 py-2 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-dashed border-slate-300 dark:border-blue-500/30 text-slate-600 dark:text-slate-300 cursor-pointer",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "w-3.5 h-3.5" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: avatarUrl ? isAr ? "تم اختيار الصورة" : "Photo selected" : isAr ? "رفع صورة" : "Upload image" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												accept: "image/*",
												onChange: handleAvatarUpload,
												className: "hidden"
											})
										]
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
									children: isAr ? "المهارات (مفصولة بفاصلة)" : "Skills (comma-separated)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: skillsText,
									onChange: (e) => setSkillsText(e.target.value),
									placeholder: "TypeScript, React, Security",
									className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
									children: isAr ? "الاهتمامات (مفصولة بفاصلة)" : "Interests (comma-separated)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: interestsText,
									onChange: (e) => setInterestsText(e.target.value),
									placeholder: "AI Workflows, Product Design",
									className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								type: "submit",
								disabled: loading,
								className: "w-full",
								children: loading ? isAr ? "جاري التسجيل..." : "Creating Account..." : isAr ? "إنشاء الحساب والمتابعة" : "Create Account & Verify Email"
							})
						]
					}),
					(mode === "verify-email" || mode === "verify-2fa") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: mode === "verify-email" ? handleVerifyEmail : handleVerify2FA,
						className: "mt-6 space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5",
							children: isAr ? "أدخل رمز التحقق المكون من 6 أرقام" : "Enter 6-digit verification code"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-4 h-4 text-slate-400 absolute top-3 start-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: code,
								onChange: (e) => setCode(e.target.value),
								placeholder: "123456",
								className: "w-full ps-9 pe-3 py-2.5 text-sm font-mono-tabular rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
							})]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							type: "submit",
							disabled: loading,
							className: "w-full",
							children: isAr ? "تأكيد ومتابعة" : "Verify & Continue"
						})]
					}),
					mode === "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleForgot,
						className: "mt-6 space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5",
							children: isAr ? "البريد الإلكتروني المسجل" : "Registered Email"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "email",
							required: true,
							value: email,
							onChange: (e) => setEmail(e.target.value),
							className: "w-full px-3 py-2.5 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							type: "submit",
							disabled: loading,
							className: "w-full",
							children: isAr ? "إرسال رمز الاستعادة" : "Issue Recovery Code"
						})]
					}),
					mode === "reset" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleReset,
						className: "mt-6 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
								children: isAr ? "رمز الاستعادة" : "Recovery Code"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: code,
								onChange: (e) => setCode(e.target.value),
								className: "w-full px-3 py-2 text-sm font-mono-tabular rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1",
								children: isAr ? "كلمة المرور الجديدة" : "New Password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								required: true,
								minLength: 8,
								value: newPassword,
								onChange: (e) => setNewPassword(e.target.value),
								className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								type: "submit",
								disabled: loading,
								className: "w-full",
								children: isAr ? "تحديث كلمة المرور" : "Reset Password"
							})
						]
					})
				]
			})]
		})]
	});
};
var DashboardView = ({ lang, currentUser, users, analytics, onNavigate, onApproveUser, onSubmitApplication }) => {
	const isAr = lang === "ar";
	const t = translations[lang].dashboard;
	const isPrivileged = currentUser.role === "admin" || currentUser.role === "supervisor";
	const pendingUsers = users.filter((u) => u.status === "pending");
	const onboarding = currentUser.onboarding || {
		profileCompleted: true,
		cvCompleted: false,
		humanVerified: Boolean(currentUser.humanVerified),
		assessmentCompleted: false,
		applicationSubmitted: false
	};
	const stepsDone = [
		onboarding.profileCompleted,
		onboarding.cvCompleted,
		onboarding.humanVerified,
		onboarding.assessmentCompleted,
		onboarding.applicationSubmitted
	];
	const completedCount = stepsDone.filter(Boolean).length;
	const stepRoutes = [
		"profile",
		"cv-builder",
		"assessments",
		"assessments",
		"dashboard"
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: `${t.welcome}${isPrivileged ? "" : ` · ${currentUser.fullName}`}`,
				subtitle: t.subtitle,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
						size: "sm",
						onClick: () => onNavigate("design-system"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "نظام التصميم" : "Design System" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
						size: "sm",
						onClick: () => onNavigate(isPrivileged ? "analytics" : "cv-builder"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isPrivileged ? isAr ? "التقارير والتصدير" : "Reports & Export" : isAr ? "منشئ السيرة الذاتية" : "Open CV Builder" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-3.5 h-3.5 rtl:-scale-x-100" })]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: t.totalMembers,
						value: analytics?.memberStats.total ?? users.length,
						context: `${analytics?.memberStats.humanVerified ?? 0} ${isAr ? "تم التحقق البشري" : "human-verified"}`,
						tone: "accent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: t.activeMembers,
						value: analytics?.memberStats.approved ?? users.filter((u) => u.status === "approved").length,
						context: `${analytics?.taskStats.done ?? 0}/${analytics?.taskStats.total ?? 0} ${isAr ? "مهام منجزة" : "tasks completed"}`,
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: t.pendingApps,
						value: pendingUsers.length,
						context: `${analytics?.assessmentStats.pendingReviews ?? 0} ${isAr ? "اختبارات بانتظار التقييم" : "tests awaiting grading"}`,
						tone: pendingUsers.length > 0 ? "warning" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: t.securityAlerts,
						value: analytics?.securityStats.unusualAlerts ?? 0,
						context: `${analytics?.securityStats.activeSessions ?? 0} ${isAr ? "جلسة نشطة حالياً" : "active sessions"}`,
						tone: (analytics?.securityStats.unusualAlerts ?? 0) > 0 ? "danger" : "default"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
				className: "p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-200 dark:border-blue-500/15",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold text-slate-900 dark:text-white",
						children: t.onboardingTitle
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
						children: [
							completedCount,
							"/5 ",
							isAr ? "مراحل مكتملة" : "steps completed",
							" ·",
							" ",
							isAr ? `حالة الحساب: ${currentUser.status}` : `Account status: ${currentUser.status}`
						]
					})] }), !onboarding.applicationSubmitted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
						size: "sm",
						disabled: completedCount < 4,
						onClick: onSubmitApplication,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.submitApplication })]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.applicationSubmitted })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3",
					children: t.onboardingSteps.map((label, idx) => {
						const done = stepsDone[idx];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onNavigate(stepRoutes[idx]),
							className: `text-start p-3.5 rounded-lg border transition-colors cursor-pointer ${done ? "bg-emerald-500/5 border-emerald-500/30 text-slate-900 dark:text-white" : "bg-slate-50 dark:bg-[#0e1934] border-slate-200 dark:border-blue-500/20 text-slate-700 dark:text-slate-300 hover:border-[#1D7AFC]"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono-tabular text-xs text-slate-500 dark:text-slate-400",
									children: ["0", idx + 1]
								}), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-emerald-500 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-4 h-4 text-slate-400 shrink-0" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 text-xs font-semibold leading-snug",
								children: label
							})]
						}, label);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-6 items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "lg:col-span-7 p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-blue-500/15",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-semibold text-slate-900 dark:text-white",
							children: isPrivileged ? t.pendingQueue : isAr ? "تقدم المشاريع والمهام" : "Active Project Progress"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onNavigate(isPrivileged ? "security" : "tasks"),
							className: "text-xs font-medium text-[#1D7AFC] dark:text-[#00D4FF] hover:underline cursor-pointer",
							children: isAr ? "عرض الكل" : "View all"
						})]
					}), isPrivileged ? pendingUsers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: isAr ? "لا توجد طلبات معلقة" : "All Applications Reviewed",
						description: isAr ? "تمت مراجعة جميع طلبات الانضمام الجديدة في الوقت الحالي." : "Every registered team candidate has been reviewed."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y divide-slate-200 dark:divide-blue-500/15",
						children: pendingUsers.map((candidate) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold text-sm text-slate-900 dark:text-white truncate",
									children: candidate.fullName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate",
									children: [
										candidate.desiredRole,
										" · ",
										candidate.email,
										" ·",
										" ",
										candidate.humanVerified ? isAr ? "تم التحقق البشري" : "Human Verified" : isAr ? "بانتظار التحقق" : "Unverified"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
									size: "sm",
									onClick: () => onApproveUser(candidate.id, "approved"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: translations[lang].actions.approve })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
									size: "sm",
									onClick: () => onApproveUser(candidate.id, "rejected"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: translations[lang].actions.reject })]
								})]
							})]
						}, candidate.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "divide-y divide-slate-200 dark:divide-blue-500/15",
						children: [(analytics?.projectProgress || []).map((proj) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-4 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-slate-900 dark:text-white",
									children: proj.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono-tabular text-xs text-[#1D7AFC] dark:text-[#00D4FF]",
									children: [
										proj.progress,
										"% · ",
										proj.taskCount,
										" ",
										isAr ? "مهام" : "tasks"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 rounded-full bg-slate-100 dark:bg-[#0e1934] overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-gradient-to-r from-[#1D7AFC] to-[#00D4FF]",
									style: { width: `${proj.progress}%` }
								})
							})]
						}, proj.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-4 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
								size: "sm",
								onClick: () => onNavigate("cv-builder"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تحليل السيرة الذاتية" : "Analyze My CV" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
								size: "sm",
								onClick: () => onNavigate("assessments"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "بدء الاختبار" : "Take Assessment" })]
							})]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "lg:col-span-5 p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-blue-500/15",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-semibold text-slate-900 dark:text-white",
							children: t.recentActivity
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onNavigate("analytics"),
							className: "text-xs font-medium text-[#1D7AFC] dark:text-[#00D4FF] hover:underline cursor-pointer",
							children: isAr ? "السجل الكامل" : "Full log"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y divide-slate-200 dark:divide-blue-500/15 max-h-96 overflow-y-auto",
						children: (analytics?.auditLogs || []).slice(0, 7).map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-slate-900 dark:text-white truncate",
									children: log.actorName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono-tabular text-slate-500 dark:text-slate-400 shrink-0",
									children: new Date(log.createdAt).toLocaleTimeString([], {
										hour: "2-digit",
										minute: "2-digit"
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed",
								children: log.details
							})]
						}, log.id))
					})]
				})]
			})
		]
	});
};
var DesignSystemView = ({ lang, theme, onToggleTheme, onToggleLang }) => {
	const isAr = lang === "ar";
	const [sampleTab, setSampleTab] = (0, import_react.useState)("overview");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: isAr ? "نظام تصميم KAVIRO" : "KAVIRO Design System",
				subtitle: isAr ? "المصدر الموحد للهوية البصرية، الألوان المشتقة من شعار KAVIRO الرسمي، الخطوط ثنائية اللغة، والمكونات القابلة لإعادة الاستخدام." : "Single source of truth anchored to the official KAVIRO logo, midnight-navy dark surfaces, electric blue gradients, and bilingual RTL/LTR typography.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
							size: "sm",
							onClick: onToggleTheme,
							children: [theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: theme === "dark" ? isAr ? "فاتح" : "Light" : isAr ? "داكن" : "Dark" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
							size: "sm",
							onClick: onToggleLang,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "English" : "العربية" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
							size: "sm",
							type: "button",
							onClick: () => downloadProjectZip(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: isAr ? "تنزيل الموقع (.zip)" : "Download Site (.zip)"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "inline-flex items-center gap-1 p-1 rounded-lg bg-slate-200/70 dark:bg-[#091124] border border-slate-300 dark:border-blue-500/20",
				children: [
					"overview",
					"tokens",
					"components"
				].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setSampleTab(tab),
					className: `px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${sampleTab === tab ? "bg-white dark:bg-[#0e1934] text-slate-900 dark:text-white shadow-sm" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
					children: tab === "overview" ? isAr ? "الهوية والشعار" : "Brand & Logo" : tab === "tokens" ? isAr ? "الألوان والخطوط" : "Colors & Typography" : isAr ? "المكونات التفاعلية" : "UI Primitives"
				}, tab))
			}),
			sampleTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "lg:col-span-7 p-6 flex flex-col justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold text-slate-900 dark:text-white",
						children: isAr ? "الاستخدام الرسمي لشعار KAVIRO" : "Official KAVIRO Logo Lockup"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-sm text-slate-600 dark:text-slate-400",
						children: isAr ? "يُحافظ الشعار على نسبه وألوانه الأصلية دون قص أو تمديد مع مساحة فراغ كافية حوله في الشريط الجانبي وشاشات الدخول والأجهزة المحمولة." : "Original proportions and electric-cyan K-orbit geometry are preserved across sidebar, login, loading screen, favicon, and mobile compact headers."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 rounded-xl bg-[#02050d] border border-blue-500/25 flex flex-col items-center justify-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/assets/aistudio/file_000000002dbc82108f86130fa3c28c94_3eb2cade.png",
								alt: "KAVIRO Full Mark",
								referrerPolicy: "no-referrer",
								className: "w-44 h-auto object-contain"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-slate-400",
								children: isAr ? "الوضع الداكن الافتراضي" : "Primary Dark Lockup"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 rounded-xl bg-slate-100 border border-slate-200 flex flex-col items-center justify-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KaviroLogo, { variant: "compact" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-slate-600",
								children: isAr ? "الوضع المضغوط للهاتف والفاتح" : "Compact Mobile & Light Frame"
							})]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
					className: "lg:col-span-5 p-6 flex flex-col justify-between gap-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold text-slate-900 dark:text-white",
						children: isAr ? "قواعد التخطيط والتجاوب" : "Responsive & Spatial Rules"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 space-y-3 text-sm text-slate-600 dark:text-slate-300",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "pb-3 border-b border-slate-200 dark:border-blue-500/15",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-slate-900 dark:text-white",
										children: "60-30-10 Balance"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-500 dark:text-slate-400",
										children: " — "
									}),
									isAr ? "خلفية كحلية داكنة، بطاقات بحدود زرقاء دقيقة، وأزرار تدرج كهربائي." : "Midnight navy canvas, bordered dark navy cards, and focused electric-blue CTAs."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "pb-3 border-b border-slate-200 dark:border-blue-500/15",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-slate-900 dark:text-white",
										children: "Single-Elevation Surface"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-500 dark:text-slate-400",
										children: " — "
									}),
									isAr ? "فصل العناصر بالمساحات البيضاء والخطوط الدقيقة بدلاً من تكديس البطاقات." : "Flat 1px hairline borders without nested card clutter or heavy drop shadows."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-slate-900 dark:text-white",
									children: "Web-First Multi-Device"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-slate-500 dark:text-slate-400",
									children: " — "
								}),
								isAr ? "تجاوب كامل من شاشات سطح المكتب 1440px إلى الأجهزة اللوحية والهواتف." : "Fluid sidebar layout on 1440px desktop collapsing cleanly to drawer navigation on tablet and mobile."
							] })
						]
					})] })
				})]
			}),
			sampleTab === "tokens" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4",
					children: [
						{
							name: "Midnight Abyss",
							hex: "#040814",
							role: "Primary Dark Canvas (60%)"
						},
						{
							name: "Deep Navy Surface",
							hex: "#091124",
							role: "Card & Sidebar Surface (30%)"
						},
						{
							name: "Elevated Indigo Slate",
							hex: "#0E1934",
							role: "Interactive Panels & Modals"
						},
						{
							name: "Electric Blue",
							hex: "#1D7AFC",
							role: "Primary CTA & Brand Accent (10%)"
						},
						{
							name: "KAVIRO Cyan",
							hex: "#00D4FF",
							role: "Gradient Highlight & Focus Ring"
						},
						{
							name: "Light Canvas",
							hex: "#F4F7FB",
							role: "Light Mode Background"
						}
					].map((swatch) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
						className: "p-4 flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-14 w-14 rounded-lg border border-slate-300 dark:border-blue-500/30 shrink-0",
							style: { backgroundColor: swatch.hex }
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold text-sm text-slate-900 dark:text-white",
									children: swatch.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono-tabular text-xs text-[#1D7AFC] dark:text-[#00D4FF] mt-0.5",
									children: swatch.hex
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate",
									children: swatch.role
								})
							]
						})]
					}, swatch.hex))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "p-6 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-lg font-semibold text-slate-900 dark:text-white",
						children: isAr ? "التسلسل الهرمي للخطوط ثنائية اللغة" : "Bilingual Typography Scale"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-6 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "Display · Plus Jakarta Sans"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-3xl font-bold text-slate-900 dark:text-white",
									children: "Intelligent Team Operations"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-slate-500 dark:text-slate-400 pt-2",
									children: "Body · DM Sans"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-slate-600 dark:text-slate-300 leading-relaxed",
									children: "Unifies onboarding, AI CV analysis, human verification, real-time messaging, and security telemetry."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							dir: "rtl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "العناوين والنصوص · IBM Plex Sans Arabic"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-2xl font-bold text-slate-900 dark:text-white",
									children: "إدارة الفرق الذكية بالذكاء الاصطناعي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-slate-600 dark:text-slate-300 leading-relaxed",
									children: "منصة موحدة لتأهيل الأعضاء وتحليل السيرة الذاتية والاختبارات والمراسلات الفورية ومراقبة الجلسات."
								})
							]
						})]
					})]
				})]
			}),
			sampleTab === "components" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
							label: isAr ? "إجمالي الأعضاء" : "Active Seats",
							value: "128",
							context: "Q4 Roster · +14 this month",
							tone: "accent"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
							label: isAr ? "معدل النجاح" : "Assessment Pass",
							value: "91.4%",
							context: "Verified submissions",
							tone: "success"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
							label: isAr ? "قيد المراجعة" : "Pending Review",
							value: "7",
							context: "Supervisor queue",
							tone: "warning"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
							label: isAr ? "تنبيهات الأمان" : "Security Alerts",
							value: "2",
							context: "Unrecognized devices",
							tone: "danger"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "p-6 flex flex-wrap items-center gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, { children: isAr ? "زر رئيسي متدرج" : "Primary Gradient Action" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, { children: isAr ? "زر ثانوي متوازن" : "Secondary Surface Action" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Engineering" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									children: "·"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Updated Nov 2026" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": "true",
									children: "·"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono-tabular",
									children: "99.98% uptime"
								})
							]
						})
					]
				})]
			})
		]
	});
};
var CvBuilderView = ({ lang, currentUser, onUserUpdated }) => {
	const isAr = lang === "ar";
	const [cv, setCv] = (0, import_react.useState)({
		fullName: currentUser.fullName,
		headline: currentUser.desiredRole,
		email: currentUser.email,
		phone: currentUser.phone || "",
		location: "",
		summary: "",
		education: [],
		experience: [],
		projects: [],
		achievements: [],
		technicalSkills: currentUser.skills || [],
		softSkills: []
	});
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [analyzing, setAnalyzing] = (0, import_react.useState)(false);
	const [pdfBase64, setPdfBase64] = (0, import_react.useState)(void 0);
	const [analysis, setAnalysis] = (0, import_react.useState)(null);
	const [previewMode, setPreviewMode] = (0, import_react.useState)(false);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [newTechSkill, setNewTechSkill] = (0, import_react.useState)("");
	const [newSoftSkill, setNewSoftSkill] = (0, import_react.useState)("");
	const [newAchievement, setNewAchievement] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		apiRequest("/api/cv").then((res) => {
			if (res.cv) setCv(res.cv);
		}).catch((e) => setError(e.message)).finally(() => setLoading(false));
	}, []);
	const handleSave = async () => {
		setSaving(true);
		setError(null);
		setNotice(null);
		try {
			const res = await apiRequest("/api/cv", {
				method: "POST",
				body: JSON.stringify(cv)
			});
			setCv(res.cv);
			onUserUpdated({
				...currentUser,
				onboarding: res.onboarding
			});
			setNotice(isAr ? "تم حفظ السيرة الذاتية بنجاح." : "CV saved to your KAVIRO profile.");
		} catch (err) {
			setError(err.message);
		} finally {
			setSaving(false);
		}
	};
	const handleFileUpload = async (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		setError(null);
		setNotice(null);
		const reader = new FileReader();
		reader.onload = async () => {
			try {
				const resultStr = String(reader.result || "");
				const base64 = resultStr.includes(",") ? resultStr.split(",")[1] : resultStr;
				const parsed = await apiRequest("/api/cv/upload", {
					method: "POST",
					body: JSON.stringify({
						fileName: file.name,
						mimeType: file.type,
						base64Data: base64
					})
				});
				setPdfBase64(parsed.pdfBase64);
				setCv((prev) => ({
					...prev,
					uploadedFileName: parsed.fileName,
					uploadedFileMime: parsed.mimeType,
					rawExtractedText: parsed.extractedText
				}));
				setNotice(isAr ? `تم رفع الملف (${parsed.fileName}) بنجاح. يمكنك الآن تشغيل التحليل الذكي.` : `Uploaded ${parsed.fileName}. Run AI CV Analysis to inspect and refine it.`);
			} catch (err) {
				setError(err.message);
			}
		};
		reader.readAsDataURL(file);
	};
	const handleAnalyze = async () => {
		setAnalyzing(true);
		setError(null);
		try {
			const res = await apiRequest("/api/ai/cv-analyze", {
				method: "POST",
				body: JSON.stringify({
					cv,
					language: lang,
					pdfBase64,
					extractedText: cv.rawExtractedText
				})
			});
			setAnalysis(res.analysis);
		} catch (err) {
			setError(err.message);
		} finally {
			setAnalyzing(false);
		}
	};
	const applyApprovedDraft = () => {
		if (!analysis) return;
		setCv((prev) => ({
			...prev,
			headline: analysis.improvedDraft.headline || prev.headline,
			summary: analysis.improvedDraft.summary || prev.summary,
			technicalSkills: analysis.improvedDraft.technicalSkills?.length ? analysis.improvedDraft.technicalSkills : prev.technicalSkills,
			softSkills: analysis.improvedDraft.softSkills?.length ? analysis.improvedDraft.softSkills : prev.softSkills,
			projects: prev.projects.map((p) => {
				const sug = analysis.projectSuggestions.find((s) => s.projectName.toLowerCase() === p.name.toLowerCase());
				return sug ? {
					...p,
					summary: sug.improvedSummary,
					impact: sug.improvedImpact
				} : p;
			})
		}));
		setNotice(isAr ? "تم تطبيق المسودة المحسّنة بعد موافقتك. اضغط حفظ لتثبيت التغييرات." : "Approved AI draft applied to editor. Click Save CV to persist changes.");
		setAnalysis(null);
	};
	const exportCvJson = () => {
		const blob = new Blob([JSON.stringify(cv, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `${cv.fullName.replace(/\s+/g, "_").toLowerCase()}_cv.json`;
		a.click();
		URL.revokeObjectURL(url);
	};
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
		className: "p-8 text-sm text-slate-400",
		children: "Loading CV Workspace..."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: isAr ? "منشئ السيرة الذاتية والمساعد الذكي" : "AI CV Builder & Analyzer",
				subtitle: isAr ? "أنشئ سيرتك الذاتية أو ارفع ملف PDF / DOCX وحلله بالذكاء الاصطناعي دون أي اختلاق للبيانات." : "Build your CV from scratch or upload PDF/DOCX. Gemini AI refines wording and identifies gaps—never inventing qualifications.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
							size: "sm",
							onClick: () => setPreviewMode(!previewMode),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: previewMode ? isAr ? "وضع التحرير" : "Edit Mode" : isAr ? "معاينة السيرة" : "Preview CV" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
							size: "sm",
							onClick: () => window.print(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "طباعة / PDF" : "Print / PDF" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
							size: "sm",
							onClick: exportCvJson,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "JSON" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							size: "sm",
							onClick: handleSave,
							disabled: saving,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: saving ? isAr ? "جاري الحفظ..." : "Saving..." : isAr ? "حفظ السيرة" : "Save CV" })
						})
					]
				})
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-300",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3 rounded-lg bg-blue-500/10 border border-blue-500/30 text-xs text-blue-700 dark:text-cyan-300",
				children: notice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
				className: "p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4 no-print",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-semibold text-slate-900 dark:text-white",
						children: isAr ? "استيراد سيرة ذاتية حالية (PDF / DOCX / TXT)" : "Upload Existing CV (PDF / DOCX / TXT)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-slate-500 dark:text-slate-400",
						children: cv.uploadedFileName ? `${isAr ? "الملف المرفوع:" : "Attached:"} ${cv.uploadedFileName}` : isAr ? "ارفع ملفاً لاستخراج النص وتحليله عبر الذكاء الاصطناعي." : "Upload a file to extract text or analyze directly with Gemini AI."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "px-3.5 py-2 text-xs font-medium rounded-lg bg-slate-100 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-800 dark:text-slate-200 inline-flex items-center gap-2 cursor-pointer hover:border-[#1D7AFC]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { className: "w-3.5 h-3.5" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "اختيار ملف CV" : "Upload PDF / DOCX" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: ".pdf,.docx,.txt,.md",
								onChange: handleFileUpload,
								className: "hidden"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
						size: "sm",
						onClick: handleAnalyze,
						disabled: analyzing,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: analyzing ? isAr ? "جاري التحليل..." : "Analyzing..." : isAr ? "تحليل واقتراح تحسينات" : "Analyze with KAVIRO AI" })]
					})]
				})]
			}),
			analysis && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
				elevated: true,
				className: "p-6 space-y-5 no-print",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-200 dark:border-blue-500/20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-lg font-semibold text-slate-900 dark:text-white",
						children: isAr ? "تقرير مساعد السيرة الذاتية (بانتظار موافقتك)" : "AI CV Review & Draft (Approval Required)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-slate-600 dark:text-slate-300 mt-1",
						children: analysis.overallReadiness
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
							size: "sm",
							onClick: () => setAnalysis(null),
							children: isAr ? "تجاهل المسودة" : "Dismiss"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
							size: "sm",
							onClick: applyApprovedDraft,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "الموافقة وتطبيق التحسينات" : "Approve & Apply Draft" })]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-6 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-semibold text-slate-900 dark:text-white",
								children: isAr ? "معلومات مفقودة مقترحة" : "Missing Information"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "list-disc ps-5 space-y-1 text-slate-600 dark:text-slate-300",
								children: analysis.missingInformation.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, i))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-semibold text-slate-900 dark:text-white pt-3",
								children: isAr ? "أسئلة متابعة لتوضيح خبراتك" : "Follow-Up Questions"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "list-disc ps-5 space-y-1 text-slate-600 dark:text-slate-300",
								children: analysis.followUpQuestions.map((q, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: q }, i))
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-semibold text-slate-900 dark:text-white",
								children: isAr ? "تحسين الصياغة والقواعد" : "Grammar & Phrasing Improvements"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "list-disc ps-5 space-y-1 text-slate-600 dark:text-slate-300",
								children: analysis.grammarAndWordingFixes.map((fix, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: fix }, i))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-semibold text-slate-900 dark:text-white pt-3",
								children: isAr ? "معاينة الملخص المقترح" : "Proposed Improved Summary"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "p-3 rounded-lg bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20 text-slate-700 dark:text-slate-200 leading-relaxed",
								children: analysis.improvedDraft.summary
							})
						]
					})]
				})]
			}),
			previewMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
				className: "p-8 max-w-4xl mx-auto space-y-6 bg-white text-slate-900 dark:bg-white dark:text-slate-900",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-b border-slate-200 pb-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl font-bold text-slate-900",
								children: cv.fullName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-medium text-[#1D7AFC] mt-1",
								children: cv.headline
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-slate-600 mt-2 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cv.email }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cv.phone }),
									cv.location && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cv.location })] })
								]
							})
						]
					}),
					cv.summary && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-slate-500 mb-2",
						children: isAr ? "الملخص المهني" : "Professional Summary"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-slate-700 leading-relaxed",
						children: cv.summary
					})] }),
					cv.experience.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-slate-500 mb-3",
						children: isAr ? "الخبرات العملية" : "Experience"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-4",
						children: cv.experience.map((exp) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-sm font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								exp.title,
								" — ",
								exp.company
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-slate-500",
								children: exp.period
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-600 mt-1 leading-relaxed",
							children: exp.description
						})] }, exp.id))
					})] }),
					cv.projects.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-slate-500 mb-3",
						children: isAr ? "المشاريع" : "Projects"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3",
						children: cv.projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm font-semibold",
								children: [
									p.name,
									" · ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-normal text-slate-600",
										children: p.role
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-600 mt-0.5",
								children: p.summary
							}),
							p.impact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-[#1D7AFC] mt-0.5",
								children: p.impact
							})
						] }, p.id))
					})] }),
					cv.education.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-slate-500 mb-2",
						children: isAr ? "التعليم" : "Education"
					}), cv.education.map((edu) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-slate-700 flex justify-between py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: edu.degree }),
							" in ",
							edu.field,
							" — ",
							edu.institution
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							edu.startYear,
							"–",
							edu.endYear
						] })]
					}, edu.id))] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-200 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-slate-500 mb-1",
							children: "Technical Skills"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-slate-800",
							children: cv.technicalSkills.join(" · ")
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-slate-500 mb-1",
							children: "Soft Skills"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-slate-800",
							children: cv.softSkills.join(" · ")
						})] })]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "lg:col-span-6 p-6 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-base font-semibold text-slate-900 dark:text-white",
							children: isAr ? "البيانات الأساسية والملخص" : "Personal Information & Summary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: cv.fullName,
									onChange: (e) => setCv({
										...cv,
										fullName: e.target.value
									}),
									placeholder: isAr ? "الاسم الكامل" : "Full Name",
									className: "px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: cv.headline,
									onChange: (e) => setCv({
										...cv,
										headline: e.target.value
									}),
									placeholder: isAr ? "المسمى المهني" : "Headline / Role",
									className: "px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: cv.email,
									onChange: (e) => setCv({
										...cv,
										email: e.target.value
									}),
									placeholder: "Email",
									className: "px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: cv.phone,
									onChange: (e) => setCv({
										...cv,
										phone: e.target.value
									}),
									placeholder: "Phone",
									className: "px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: cv.location,
							onChange: (e) => setCv({
								...cv,
								location: e.target.value
							}),
							placeholder: isAr ? "المدينة / الدولة" : "City, Country",
							className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							rows: 4,
							value: cv.summary,
							onChange: (e) => setCv({
								...cv,
								summary: e.target.value
							}),
							placeholder: isAr ? "اكتب ملخصك المهني..." : "Write your professional summary...",
							className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 pt-2 border-t border-slate-200 dark:border-blue-500/15",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: newTechSkill,
										onChange: (e) => setNewTechSkill(e.target.value),
										placeholder: isAr ? "أضف مهارة تقنية..." : "Add technical skill...",
										className: "flex-1 px-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
										size: "sm",
										type: "button",
										onClick: () => {
											if (!newTechSkill.trim()) return;
											setCv({
												...cv,
												technicalSkills: [...cv.technicalSkills, newTechSkill.trim()]
											});
											setNewTechSkill("");
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-slate-600 dark:text-slate-300 flex flex-wrap gap-2",
									children: cv.technicalSkills.map((s, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setCv({
											...cv,
											technicalSkills: cv.technicalSkills.filter((_, i) => i !== idx)
										}),
										className: "px-2.5 py-1 rounded-md bg-slate-100 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20 hover:border-rose-500/50 cursor-pointer",
										children: [s, " ×"]
									}, `${s}-${idx}`))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: newSoftSkill,
										onChange: (e) => setNewSoftSkill(e.target.value),
										placeholder: isAr ? "أضف مهارة شخصية..." : "Add soft skill...",
										className: "flex-1 px-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
										size: "sm",
										type: "button",
										onClick: () => {
											if (!newSoftSkill.trim()) return;
											setCv({
												...cv,
												softSkills: [...cv.softSkills, newSoftSkill.trim()]
											});
											setNewSoftSkill("");
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-slate-600 dark:text-slate-300 flex flex-wrap gap-2",
									children: cv.softSkills.map((s, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setCv({
											...cv,
											softSkills: cv.softSkills.filter((_, i) => i !== idx)
										}),
										className: "px-2.5 py-1 rounded-md bg-slate-100 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20 hover:border-rose-500/50 cursor-pointer",
										children: [s, " ×"]
									}, `${s}-${idx}`))
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "lg:col-span-6 p-6 space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-base font-semibold text-slate-900 dark:text-white",
									children: isAr ? "الخبرات العملية" : "Work Experience"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
									size: "sm",
									type: "button",
									onClick: () => setCv({
										...cv,
										experience: [...cv.experience, {
											id: `exp-${Date.now()}`,
											company: "",
											title: "",
											period: "",
											description: ""
										}]
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إضافة خبرة" : "Add" })]
								})]
							}), cv.experience.map((exp, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20 space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: exp.title,
											onChange: (e) => {
												const next = [...cv.experience];
												next[idx] = {
													...exp,
													title: e.target.value
												};
												setCv({
													...cv,
													experience: next
												});
											},
											placeholder: "Role Title",
											className: "px-2.5 py-1.5 text-xs rounded bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: exp.company,
											onChange: (e) => {
												const next = [...cv.experience];
												next[idx] = {
													...exp,
													company: e.target.value
												};
												setCv({
													...cv,
													experience: next
												});
											},
											placeholder: "Company",
											className: "px-2.5 py-1.5 text-xs rounded bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: exp.period,
												onChange: (e) => {
													const next = [...cv.experience];
													next[idx] = {
														...exp,
														period: e.target.value
													};
													setCv({
														...cv,
														experience: next
													});
												},
												placeholder: "2022–2025",
												className: "flex-1 px-2.5 py-1.5 text-xs rounded bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setCv({
													...cv,
													experience: cv.experience.filter((_, i) => i !== idx)
												}),
												className: "p-1.5 text-rose-500 hover:bg-rose-500/10 rounded cursor-pointer",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3.5 h-3.5" })
											})]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									rows: 2,
									value: exp.description,
									onChange: (e) => {
										const next = [...cv.experience];
										next[idx] = {
											...exp,
											description: e.target.value
										};
										setCv({
											...cv,
											experience: next
										});
									},
									placeholder: "Key responsibilities and measurable results...",
									className: "w-full px-2.5 py-1.5 text-xs rounded bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20"
								})]
							}, exp.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 pt-4 border-t border-slate-200 dark:border-blue-500/15",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-base font-semibold text-slate-900 dark:text-white",
									children: isAr ? "المشاريع والإنجازات" : "Projects"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
									size: "sm",
									type: "button",
									onClick: () => setCv({
										...cv,
										projects: [...cv.projects, {
											id: `prj-${Date.now()}`,
											name: "",
											role: "",
											summary: "",
											impact: ""
										}]
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إضافة مشروع" : "Add" })]
								})]
							}), cv.projects.map((prj, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20 space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: prj.name,
												onChange: (e) => {
													const next = [...cv.projects];
													next[idx] = {
														...prj,
														name: e.target.value
													};
													setCv({
														...cv,
														projects: next
													});
												},
												placeholder: "Project Name",
												className: "flex-1 px-2.5 py-1.5 text-xs rounded bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: prj.role,
												onChange: (e) => {
													const next = [...cv.projects];
													next[idx] = {
														...prj,
														role: e.target.value
													};
													setCv({
														...cv,
														projects: next
													});
												},
												placeholder: "Your Role",
												className: "flex-1 px-2.5 py-1.5 text-xs rounded bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setCv({
													...cv,
													projects: cv.projects.filter((_, i) => i !== idx)
												}),
												className: "p-1.5 text-rose-500 hover:bg-rose-500/10 rounded cursor-pointer",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3.5 h-3.5" })
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: prj.summary,
										onChange: (e) => {
											const next = [...cv.projects];
											next[idx] = {
												...prj,
												summary: e.target.value
											};
											setCv({
												...cv,
												projects: next
											});
										},
										placeholder: "What did you build?",
										className: "w-full px-2.5 py-1.5 text-xs rounded bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: prj.impact,
										onChange: (e) => {
											const next = [...cv.projects];
											next[idx] = {
												...prj,
												impact: e.target.value
											};
											setCv({
												...cv,
												projects: next
											});
										},
										placeholder: "Outcome / impact",
										className: "w-full px-2.5 py-1.5 text-xs rounded bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20"
									})
								]
							}, prj.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 pt-4 border-t border-slate-200 dark:border-blue-500/15",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-base font-semibold text-slate-900 dark:text-white",
										children: isAr ? "التعليم" : "Education"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
										size: "sm",
										type: "button",
										onClick: () => setCv({
											...cv,
											education: [...cv.education, {
												id: `edu-${Date.now()}`,
												institution: "",
												degree: "",
												field: "",
												startYear: "",
												endYear: ""
											}]
										}),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" })
									})]
								}),
								cv.education.map((edu, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 sm:grid-cols-5 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: edu.institution,
											onChange: (e) => {
												const next = [...cv.education];
												next[idx] = {
													...edu,
													institution: e.target.value
												};
												setCv({
													...cv,
													education: next
												});
											},
											placeholder: "University",
											className: "col-span-2 px-2.5 py-1.5 text-xs rounded bg-slate-50 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: edu.degree,
											onChange: (e) => {
												const next = [...cv.education];
												next[idx] = {
													...edu,
													degree: e.target.value
												};
												setCv({
													...cv,
													education: next
												});
											},
											placeholder: "Degree",
											className: "px-2.5 py-1.5 text-xs rounded bg-slate-50 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: edu.field,
											onChange: (e) => {
												const next = [...cv.education];
												next[idx] = {
													...edu,
													field: e.target.value
												};
												setCv({
													...cv,
													education: next
												});
											},
											placeholder: "Field",
											className: "px-2.5 py-1.5 text-xs rounded bg-slate-50 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: edu.endYear,
												onChange: (e) => {
													const next = [...cv.education];
													next[idx] = {
														...edu,
														endYear: e.target.value
													};
													setCv({
														...cv,
														education: next
													});
												},
												placeholder: "Year",
												className: "w-full px-2 py-1.5 text-xs rounded bg-slate-50 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setCv({
													...cv,
													education: cv.education.filter((_, i) => i !== idx)
												}),
												className: "p-1.5 text-rose-500 cursor-pointer",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3.5 h-3.5" })
											})]
										})
									]
								}, edu.id)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-2 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: newAchievement,
										onChange: (e) => setNewAchievement(e.target.value),
										placeholder: isAr ? "أضف إنجازاً موثقاً..." : "Add achievement...",
										className: "flex-1 px-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
										size: "sm",
										type: "button",
										onClick: () => {
											if (!newAchievement.trim()) return;
											setCv({
												...cv,
												achievements: [...cv.achievements, newAchievement.trim()]
											});
											setNewAchievement("");
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-1 text-xs text-slate-600 dark:text-slate-300",
									children: cv.achievements.map((ach, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· ", ach] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setCv({
												...cv,
												achievements: cv.achievements.filter((_, i) => i !== idx)
											}),
											className: "text-rose-500 cursor-pointer",
											children: "×"
										})]
									}, idx))
								})
							]
						})
					]
				})]
			})
		]
	});
};
var AssessmentsView = ({ lang, currentUser, users, onUserUpdated }) => {
	const isAr = lang === "ar";
	const isPrivileged = currentUser.role === "admin" || currentUser.role === "supervisor";
	const [assessments, setAssessments] = (0, import_react.useState)([]);
	const [attempts, setAttempts] = (0, import_react.useState)([]);
	const [captcha, setCaptcha] = (0, import_react.useState)(null);
	const [captchaAnswer, setCaptchaAnswer] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [activeAttempt, setActiveAttempt] = (0, import_react.useState)(null);
	const [activeAssessment, setActiveAssessment] = (0, import_react.useState)(null);
	const [activeQuestions, setActiveQuestions] = (0, import_react.useState)([]);
	const [answersMap, setAnswersMap] = (0, import_react.useState)({});
	const [secondsLeft, setSecondsLeft] = (0, import_react.useState)(0);
	const [gradingAttempt, setGradingAttempt] = (0, import_react.useState)(null);
	const [gradeInputs, setGradeInputs] = (0, import_react.useState)({});
	const [showBuilder, setShowBuilder] = (0, import_react.useState)(false);
	const [newTitle, setNewTitle] = (0, import_react.useState)("");
	const [newCategory, setNewCategory] = (0, import_react.useState)("Engineering");
	const [newTimeLimit, setNewTimeLimit] = (0, import_react.useState)(15);
	const [newQuestions, setNewQuestions] = (0, import_react.useState)([{
		id: "q-new-1",
		type: "mcq",
		prompt: "",
		options: [
			"Option A",
			"Option B",
			"Option C",
			"Option D"
		],
		correctAnswer: "Option A",
		points: 50
	}]);
	const loadData = async () => {
		try {
			const res = await apiRequest("/api/assessments");
			setAssessments(res.assessments);
			setAttempts(res.attempts);
		} catch (e) {
			setError(e.message);
		}
	};
	const loadCaptcha = async () => {
		try {
			const res = await apiRequest("/api/assessments/captcha");
			setCaptcha(res);
			setCaptchaAnswer("");
		} catch (e) {
			setError(e.message);
		}
	};
	(0, import_react.useEffect)(() => {
		loadData();
		if (!currentUser.humanVerified) loadCaptcha();
	}, [currentUser.humanVerified]);
	(0, import_react.useEffect)(() => {
		if (!activeAttempt || secondsLeft <= 0) return;
		const timer = setInterval(() => {
			setSecondsLeft((s) => {
				if (s <= 1) {
					clearInterval(timer);
					handleSubmitAttempt();
					return 0;
				}
				return s - 1;
			});
		}, 1e3);
		return () => clearInterval(timer);
	}, [activeAttempt, secondsLeft]);
	const handleVerifyCaptcha = async (e) => {
		e.preventDefault();
		if (!captcha) return;
		setError(null);
		try {
			onUserUpdated((await apiRequest("/api/assessments/captcha/verify", {
				method: "POST",
				body: JSON.stringify({
					challengeId: captcha.challengeId,
					answer: captchaAnswer
				})
			})).user);
			setNotice(isAr ? "تم التحقق البشري بنجاح! يمكنك بدء الاختبارات الآن." : "Human verification passed. Assessments unlocked.");
		} catch (err) {
			setError(err.message);
			loadCaptcha();
		}
	};
	const handleStartAssessment = async (assessment) => {
		setError(null);
		setNotice(null);
		try {
			const res = await apiRequest(`/api/assessments/${assessment.id}/start`, { method: "POST" });
			setActiveAttempt(res.attempt);
			setActiveAssessment(assessment);
			setActiveQuestions(res.questions);
			setAnswersMap({});
			setSecondsLeft(assessment.timeLimitMinutes * 60);
		} catch (err) {
			setError(err.message);
		}
	};
	const handleSubmitAttempt = async () => {
		if (!activeAttempt) return;
		try {
			const answers = activeQuestions.map((q) => ({
				questionId: q.id,
				answer: answersMap[q.id] || ""
			}));
			const res = await apiRequest(`/api/assessments/attempts/${activeAttempt.id}/submit`, {
				method: "POST",
				body: JSON.stringify({ answers })
			});
			onUserUpdated({
				...currentUser,
				onboarding: res.onboarding
			});
			setActiveAttempt(null);
			setActiveAssessment(null);
			setActiveQuestions([]);
			setNotice(res.attempt.status === "graded" ? `Assessment graded: ${res.attempt.totalScore}/${res.attempt.maxScore}` : isAr ? "تم إرسال إجاباتك بنجاح وبانتظار التقييم اليدوي من المشرف." : "Submission recorded and queued for supervisor review.");
			loadData();
		} catch (err) {
			setError(err.message);
		}
	};
	const handleCreateAssessment = async (e) => {
		e.preventDefault();
		setError(null);
		try {
			await apiRequest("/api/assessments", {
				method: "POST",
				body: JSON.stringify({
					title: newTitle,
					category: newCategory,
					timeLimitMinutes: newTimeLimit,
					maxAttempts: 2,
					passingScore: 70,
					randomizeQuestions: true,
					assignedUserIds: [],
					questions: newQuestions
				})
			});
			setShowBuilder(false);
			setNewTitle("");
			loadData();
			setNotice(isAr ? "تم إنشاء الاختبار الجديد." : "Assessment published to workspace.");
		} catch (err) {
			setError(err.message);
		}
	};
	const handleSubmitGrade = async (e) => {
		e.preventDefault();
		if (!gradingAttempt) return;
		try {
			const grades = Object.entries(gradeInputs).map(([questionId, val]) => ({
				questionId,
				pointsAwarded: val.points,
				feedback: val.feedback
			}));
			await apiRequest(`/api/assessments/attempts/${gradingAttempt.id}/grade`, {
				method: "POST",
				body: JSON.stringify({ grades })
			});
			setGradingAttempt(null);
			loadData();
			setNotice(isAr ? "تم اعتماد التقييم اليدوي وإشعار العضو." : "Manual grading finalized.");
		} catch (err) {
			setError(err.message);
		}
	};
	const userNameMap = new Map(users.map((u) => [u.id, u.fullName]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: isAr ? "مركز التحقق البشري والاختبارات" : "Human Verification & Assessment Center",
				subtitle: isAr ? "تحقق أمني (CAPTCHA)، اختبارات عشوائية محددة بالوقت، وتقييم تلقائي ويدوي بواسطة المشرفين." : "CAPTCHA verification, randomized timed assessments, automatic objective grading, and supervisor manual evaluation.",
				action: isPrivileged ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
					size: "sm",
					onClick: () => setShowBuilder(!showBuilder),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إنشاء اختبار" : "Create Assessment" })]
				}) : void 0
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-300",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3 rounded-lg bg-blue-500/10 border border-blue-500/30 text-xs text-blue-700 dark:text-cyan-300",
				children: notice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
				className: "p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: `w-6 h-6 shrink-0 mt-0.5 ${currentUser.humanVerified ? "text-emerald-500" : "text-[#1D7AFC] dark:text-[#00D4FF]"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-base font-semibold text-slate-900 dark:text-white",
							children: isAr ? "التحقق البشري الأمني (CAPTCHA)" : "Human Verification Gate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5",
							children: currentUser.humanVerified ? isAr ? "تم التحقق من هويتك البشرية بنجاح — الاختبارات متاحة الآن." : "Your account is human-verified. Timed assessments are unlocked." : isAr ? "أكمل تحدي التحقق البشري لفتح اختبارات المهارات." : "Solve the server-verified challenge below to unlock skill assessments."
						})] })]
					}), currentUser.humanVerified ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "مُتحقق" : "Verified" })]
					}) : captcha && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleVerifyCaptcha,
						className: "flex flex-wrap items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: captcha.svgDataUri,
								alt: "Security Challenge",
								className: "h-12 rounded-lg border border-blue-500/30"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: loadCaptcha,
								title: "Refresh challenge",
								className: "p-2 rounded-lg bg-slate-100 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/20 text-slate-600 dark:text-slate-300 cursor-pointer",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "w-4 h-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: captchaAnswer,
								onChange: (e) => setCaptchaAnswer(e.target.value),
								placeholder: isAr ? "النتيجة" : "Answer",
								className: "w-24 px-3 py-2 text-sm font-mono-tabular rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								size: "sm",
								type: "submit",
								children: isAr ? "تحقق" : "Verify"
							})
						]
					})]
				})
			}),
			showBuilder && isPrivileged && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
				elevated: true,
				className: "p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg font-semibold text-slate-900 dark:text-white mb-4",
					children: isAr ? "إنشاء اختبار جديد" : "New Assessment Builder"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleCreateAssessment,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									value: newTitle,
									onChange: (e) => setNewTitle(e.target.value),
									placeholder: isAr ? "عنوان الاختبار" : "Assessment Title",
									className: "px-3 py-2 text-sm rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: newCategory,
									onChange: (e) => setNewCategory(e.target.value),
									placeholder: "Category",
									className: "px-3 py-2 text-sm rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 5,
									max: 120,
									value: newTimeLimit,
									onChange: (e) => setNewTimeLimit(Number(e.target.value)),
									placeholder: "Time limit (min)",
									className: "px-3 py-2 text-sm font-mono-tabular rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
								})
							]
						}),
						newQuestions.map((q, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-lg bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2 items-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: q.type,
											onChange: (e) => {
												const next = [...newQuestions];
												const type = e.target.value;
												next[idx] = {
													...q,
													type,
													options: type === "mcq" ? [
														"Option A",
														"Option B",
														"Option C",
														"Option D"
													] : type === "true_false" ? ["True", "False"] : void 0,
													correctAnswer: type === "true_false" ? "True" : type === "mcq" ? "Option A" : void 0
												};
												setNewQuestions(next);
											},
											className: "px-2.5 py-1.5 text-xs rounded bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/20",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "mcq",
													children: "Multiple Choice"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "true_false",
													children: "True / False"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "written",
													children: "Written"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "scenario",
													children: "Scenario-Based"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: 5,
											value: q.points,
											onChange: (e) => {
												const next = [...newQuestions];
												next[idx] = {
													...q,
													points: Number(e.target.value)
												};
												setNewQuestions(next);
											},
											className: "w-24 px-2.5 py-1.5 text-xs font-mono-tabular rounded bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/20"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-slate-400",
											children: "pts"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									value: q.prompt,
									onChange: (e) => {
										const next = [...newQuestions];
										next[idx] = {
											...q,
											prompt: e.target.value
										};
										setNewQuestions(next);
									},
									placeholder: "Enter question prompt...",
									className: "w-full px-3 py-2 text-xs rounded bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/20"
								}),
								q.type === "mcq" && q.options && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-2 gap-2",
									children: q.options.map((opt, oi) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: opt,
										onChange: (e) => {
											const next = [...newQuestions];
											const opts = [...q.options || []];
											opts[oi] = e.target.value;
											next[idx] = {
												...q,
												options: opts,
												correctAnswer: oi === 0 ? e.target.value : q.correctAnswer
											};
											setNewQuestions(next);
										},
										placeholder: `Option ${oi + 1}`,
										className: "px-2.5 py-1.5 text-xs rounded bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/20"
									}, oi))
								})
							]
						}, q.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
								size: "sm",
								type: "button",
								onClick: () => setNewQuestions([...newQuestions, {
									id: `q-new-${Date.now()}`,
									type: "written",
									prompt: "",
									points: 50
								}]),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إضافة سؤال" : "Add Question" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
									size: "sm",
									type: "button",
									onClick: () => setShowBuilder(false),
									children: isAr ? "إلغاء" : "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
									size: "sm",
									type: "submit",
									children: isAr ? "نشر الاختبار" : "Publish Assessment"
								})]
							})]
						})
					]
				})]
			}),
			activeAttempt && activeAssessment ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
				elevated: true,
				className: "p-6 space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-blue-500/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-xl font-bold text-slate-900 dark:text-white",
							children: isAr && activeAssessment.titleAr ? activeAssessment.titleAr : activeAssessment.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
							children: [
								activeQuestions.length,
								" ",
								isAr ? "أسئلة" : "questions"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 font-mono-tabular text-sm font-semibold text-[#1D7AFC] dark:text-[#00D4FF]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								String(Math.floor(secondsLeft / 60)).padStart(2, "0"),
								":",
								String(secondsLeft % 60).padStart(2, "0")
							] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-6",
						children: activeQuestions.map((q, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2.5 pb-5 border-b border-slate-200 dark:border-blue-500/15 last:border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-xs text-slate-500 dark:text-slate-400",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Question 0",
										idx + 1,
										" · ",
										q.type.replace("_", "/")
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono-tabular",
										children: [q.points, " pts"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-slate-900 dark:text-white",
									children: isAr && q.promptAr ? q.promptAr : q.prompt
								}),
								q.options ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1",
									children: q.options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setAnswersMap({
											...answersMap,
											[q.id]: opt
										}),
										className: `text-start px-3.5 py-2.5 text-xs rounded-lg border transition-colors cursor-pointer ${answersMap[q.id] === opt ? "bg-[#1D7AFC]/15 border-[#00D4FF] text-slate-900 dark:text-white font-semibold" : "bg-white dark:bg-[#091124] border-slate-200 dark:border-blue-500/20 text-slate-700 dark:text-slate-300"}`,
										children: opt
									}, opt))
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									rows: 4,
									value: answersMap[q.id] || "",
									onChange: (e) => setAnswersMap({
										...answersMap,
										[q.id]: e.target.value
									}),
									placeholder: isAr ? "اكتب إجابتك هنا..." : "Write your response...",
									className: "w-full px-3 py-2 text-sm rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
								})
							]
						}, q.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
							onClick: () => setActiveAttempt(null),
							children: isAr ? "إلغاء" : "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							onClick: handleSubmitAttempt,
							children: isAr ? "إرسال الإجابات" : "Submit Assessment"
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-base font-semibold text-slate-900 dark:text-white",
						children: isAr ? "الاختبارات المتاحة" : "Assigned & Available Assessments"
					}), assessments.map((asm) => {
						const myAttempts = attempts.filter((a) => a.assessmentId === asm.id && a.userId === currentUser.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
							className: "p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-semibold text-sm text-slate-900 dark:text-white",
										children: isAr && asm.titleAr ? asm.titleAr : asm.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-slate-600 dark:text-slate-400",
										children: asm.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-slate-500 dark:text-slate-400 pt-1",
										children: [
											asm.category,
											" · ",
											asm.timeLimitMinutes,
											" min · ",
											asm.questions.length,
											" Qs ·",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono-tabular",
												children: [
													myAttempts.length,
													"/",
													asm.maxAttempts,
													" attempts"
												]
											})
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								size: "sm",
								disabled: !currentUser.humanVerified || myAttempts.length >= asm.maxAttempts,
								onClick: () => handleStartAssessment(asm),
								children: isAr ? "بدء الاختبار" : "Start Test"
							})]
						}, asm.id);
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-base font-semibold text-slate-900 dark:text-white",
							children: isPrivileged ? isAr ? "سجل النتائج وطابور التقييم اليدوي" : "Results & Grading Queue" : isAr ? "سجل نتائجي" : "My Performance History"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
							className: "divide-y divide-slate-200 dark:divide-blue-500/15",
							children: attempts.map((att) => {
								const asm = assessments.find((a) => a.id === att.assessmentId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-semibold text-slate-900 dark:text-white truncate",
											children: [
												userNameMap.get(att.userId) || currentUser.fullName,
												" · ",
												asm?.title || att.assessmentId
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono-tabular text-xs font-bold text-[#1D7AFC] dark:text-[#00D4FF]",
											children: [
												att.totalScore,
												"/",
												att.maxScore
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-xs text-slate-500 dark:text-slate-400",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: att.status === "graded" ? att.passed ? "Passed" : "Needs Review / Failed" : "Pending Manual Review" }), isPrivileged && att.status === "pending_review" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												setGradingAttempt(att);
												const init = {};
												att.answers.forEach((a) => {
													init[a.questionId] = {
														points: a.pointsAwarded,
														feedback: a.feedback || ""
													};
												});
												setGradeInputs(init);
											},
											className: "text-[#1D7AFC] dark:text-[#00D4FF] font-semibold hover:underline cursor-pointer",
											children: isAr ? "تقييم الإجابات" : "Grade Submission"
										})]
									})]
								}, att.id);
							})
						}),
						gradingAttempt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
							elevated: true,
							className: "p-5 space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
								className: "font-display text-sm font-semibold text-slate-900 dark:text-white",
								children: ["Manual Grading · ", userNameMap.get(gradingAttempt.userId)]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleSubmitGrade,
								className: "space-y-4",
								children: [gradingAttempt.answers.map((ans) => {
									const q = assessments.find((a) => a.id === gradingAttempt.assessmentId)?.questions.find((item) => item.id === ans.questionId);
									if (!q || q.type !== "written" && q.type !== "scenario") return null;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2 text-xs",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-medium text-slate-800 dark:text-slate-200",
												children: q.prompt
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "p-2.5 rounded bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20 text-slate-600 dark:text-slate-300",
												children: ans.answer || "(No response)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "number",
													min: 0,
													max: q.points,
													value: gradeInputs[q.id]?.points ?? 0,
													onChange: (e) => setGradeInputs({
														...gradeInputs,
														[q.id]: {
															...gradeInputs[q.id],
															points: Number(e.target.value)
														}
													}),
													className: "w-24 px-2 py-1 rounded bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/20 font-mono-tabular"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													value: gradeInputs[q.id]?.feedback ?? "",
													onChange: (e) => setGradeInputs({
														...gradeInputs,
														[q.id]: {
															...gradeInputs[q.id],
															feedback: e.target.value
														}
													}),
													placeholder: "Reviewer feedback...",
													className: "flex-1 px-2 py-1 rounded bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/20"
												})]
											})
										]
									}, ans.questionId);
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
										size: "sm",
										type: "button",
										onClick: () => setGradingAttempt(null),
										children: "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
										size: "sm",
										type: "submit",
										children: "Finalize Grade"
									})]
								})]
							})]
						})
					]
				})]
			})
		]
	});
};
var MessagingView = ({ lang, currentUser, users, onlineUserIds, wsEvents, sendWsTyping }) => {
	const isAr = lang === "ar";
	const [conversations, setConversations] = (0, import_react.useState)([]);
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [draftText, setDraftText] = (0, import_react.useState)("");
	const [replyTo, setReplyTo] = (0, import_react.useState)(null);
	const [attachment, setAttachment] = (0, import_react.useState)(void 0);
	const [typingUsers, setTypingUsers] = (0, import_react.useState)({});
	const [showNewModal, setShowNewModal] = (0, import_react.useState)(false);
	const [newChatType, setNewChatType] = (0, import_react.useState)("group");
	const [newChatName, setNewChatName] = (0, import_react.useState)("");
	const [selectedMembers, setSelectedMembers] = (0, import_react.useState)([]);
	const [announcementInput, setAnnouncementInput] = (0, import_react.useState)("");
	const [showGroupPanel, setShowGroupPanel] = (0, import_react.useState)(false);
	const endRef = (0, import_react.useRef)(null);
	const userMap = new Map(users.map((u) => [u.id, u]));
	const onlineSet = new Set(onlineUserIds);
	const loadConversations = async () => {
		const res = await apiRequest("/api/conversations");
		setConversations(res.conversations);
		if (!selectedId && res.conversations.length > 0) setSelectedId(res.conversations[0].id);
	};
	const loadMessages = async (convId, q = searchQuery) => {
		const res = await apiRequest(`/api/conversations/${convId}/messages${q ? `?q=${encodeURIComponent(q)}` : ""}`);
		setMessages(res.messages);
		await apiRequest(`/api/conversations/${convId}/read`, { method: "POST" });
		setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), 60);
	};
	(0, import_react.useEffect)(() => {
		loadConversations();
	}, []);
	(0, import_react.useEffect)(() => {
		if (selectedId) {
			loadMessages(selectedId);
			const conv = conversations.find((c) => c.id === selectedId);
			setAnnouncementInput(conv?.announcement || "");
		}
	}, [selectedId]);
	(0, import_react.useEffect)(() => {
		if (!wsEvents) return;
		const { event, payload } = wsEvents;
		if (event === "message:new" && payload.conversationId === selectedId) {
			setMessages((prev) => prev.some((m) => m.id === payload.id) ? prev : [...prev, payload]);
			apiRequest(`/api/conversations/${selectedId}/read`, { method: "POST" }).catch(() => {});
			setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), 40);
		} else if (event === "message:reaction") setMessages((prev) => prev.map((m) => m.id === payload.messageId ? {
			...m,
			reactions: payload.reactions
		} : m));
		else if (event === "message:read" && payload.conversationId === selectedId) setMessages((prev) => prev.map((m) => m.readBy.includes(payload.userId) ? m : {
			...m,
			readBy: [...m.readBy, payload.userId]
		}));
		else if (event === "typing:update" && payload.conversationId === selectedId) setTypingUsers((prev) => ({
			...prev,
			[payload.userId]: payload.isTyping
		}));
		else if (event === "conversation:new" || event === "conversation:updated") loadConversations();
	}, [wsEvents, selectedId]);
	const activeConv = conversations.find((c) => c.id === selectedId) || null;
	const isGroupAdmin = activeConv && (activeConv.adminIds.includes(currentUser.id) || currentUser.role === "admin");
	const handleSend = async (e) => {
		e.preventDefault();
		if (!selectedId || !draftText.trim() && !attachment) return;
		const content = draftText.trim();
		setDraftText("");
		setReplyTo(null);
		const attached = attachment;
		setAttachment(void 0);
		sendWsTyping(selectedId, false);
		const res = await apiRequest(`/api/conversations/${selectedId}/messages`, {
			method: "POST",
			body: JSON.stringify({
				content,
				replyToId: replyTo?.id,
				attachment: attached
			})
		});
		setMessages((prev) => prev.some((m) => m.id === res.message.id) ? prev : [...prev, res.message]);
	};
	const handleFilePick = (e) => {
		const file = e.target.files?.[0];
		if (!file || file.size > 2e6) return;
		const reader = new FileReader();
		reader.onload = () => {
			setAttachment({
				name: file.name,
				mimeType: file.type || "application/octet-stream",
				size: file.size,
				dataUrl: String(reader.result || "")
			});
		};
		reader.readAsDataURL(file);
	};
	const handleCreateConversation = async (e) => {
		e.preventDefault();
		const res = await apiRequest("/api/conversations", {
			method: "POST",
			body: JSON.stringify({
				type: newChatType,
				name: newChatType === "group" ? newChatName : void 0,
				memberIds: selectedMembers
			})
		});
		setShowNewModal(false);
		setNewChatName("");
		setSelectedMembers([]);
		await loadConversations();
		setSelectedId(res.conversation.id);
	};
	const handlePinToggle = async (messageId) => {
		if (!activeConv) return;
		await apiRequest(`/api/conversations/${activeConv.id}`, {
			method: "PATCH",
			body: JSON.stringify({ togglePinMessageId: messageId })
		});
	};
	const handleUpdateAnnouncement = async () => {
		if (!activeConv) return;
		await apiRequest(`/api/conversations/${activeConv.id}`, {
			method: "PATCH",
			body: JSON.stringify({ announcement: announcementInput })
		});
	};
	const activeTypers = Object.entries(typingUsers).filter(([uid, active]) => active && uid !== currentUser.id).map(([uid]) => userMap.get(uid)?.fullName || "Someone");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: isAr ? "المراسلات الفورية والقنوات" : "Real-Time Team Messaging",
				subtitle: isAr ? "محادثات خاصة ومجموعات فريق مع مؤشرات الكتابة وتأكيدات القراءة وتبادل الملفات." : "Direct messages and group channels powered by live WebSockets with typing indicators, read receipts, replies, and shared files.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
					size: "sm",
					onClick: () => setShowNewModal(!showNewModal),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "محادثة / مجموعة جديدة" : "New Chat / Group" })]
				})
			}),
			showNewModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
				elevated: true,
				className: "p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleCreateConversation,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-3 items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: newChatType,
								onChange: (e) => setNewChatType(e.target.value),
								className: "px-3 py-2 text-xs rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "group",
									children: "Team Group"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "direct",
									children: "Direct Message"
								})]
							}), newChatType === "group" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: newChatName,
								onChange: (e) => setNewChatName(e.target.value),
								placeholder: "Channel name (e.g. Design Review)",
								className: "flex-1 min-w-[200px] px-3 py-2 text-xs rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: users.filter((u) => u.id !== currentUser.id).map((u) => {
								const chosen = selectedMembers.includes(u.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setSelectedMembers(newChatType === "direct" ? [u.id] : chosen ? selectedMembers.filter((id) => id !== u.id) : [...selectedMembers, u.id]),
									className: `px-3 py-1.5 text-xs rounded-lg border cursor-pointer ${chosen ? "bg-[#1D7AFC]/15 border-[#00D4FF] text-slate-900 dark:text-white" : "bg-white dark:bg-[#091124] border-slate-200 dark:border-blue-500/20 text-slate-600 dark:text-slate-300"}`,
									children: u.fullName
								}, u.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
								size: "sm",
								type: "button",
								onClick: () => setShowNewModal(false),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								size: "sm",
								type: "submit",
								disabled: selectedMembers.length === 0,
								children: "Create"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-4 min-h-[540px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "lg:col-span-4 p-3 flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-2 py-1 text-xs font-semibold text-slate-500 dark:text-slate-400",
						children: isAr ? "القنوات والمحادثات" : "Channels & Direct Messages"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-1 overflow-y-auto max-h-[480px]",
						children: conversations.map((conv) => {
							const otherId = conv.type === "direct" ? conv.memberIds.find((id) => id !== currentUser.id) : void 0;
							const isOnline = otherId ? onlineSet.has(otherId) : false;
							const active = conv.id === selectedId;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setSelectedId(conv.id),
								className: `w-full text-start px-3 py-2.5 rounded-lg transition-colors flex items-center justify-between gap-2 cursor-pointer ${active ? "bg-[#1D7AFC]/15 border border-blue-500/35 text-slate-900 dark:text-white" : "hover:bg-slate-100 dark:hover:bg-[#0e1934] text-slate-700 dark:text-slate-300"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-semibold truncate",
										children: conv.type === "group" ? `# ${conv.name}` : userMap.get(otherId || "")?.fullName || conv.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate",
										children: [
											conv.memberIds.length,
											" members · ",
											conv.type
										]
									})]
								}), conv.type === "direct" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `h-2 w-2 rounded-full shrink-0 ${isOnline ? "bg-emerald-500" : "bg-slate-400"}`,
									title: isOnline ? "Online" : "Offline"
								})]
							}, conv.id);
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
					className: "lg:col-span-8 flex flex-col overflow-hidden",
					children: activeConv ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-3 border-b border-slate-200 dark:border-blue-500/15 flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-semibold text-sm text-slate-900 dark:text-white",
								children: activeConv.type === "group" ? `# ${activeConv.name}` : activeConv.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-slate-500 dark:text-slate-400",
								children: [
									activeConv.memberIds.length,
									" members",
									activeConv.pinnedMessageIds.length > 0 && ` · ${activeConv.pinnedMessageIds.length} pinned`
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute top-2 start-2.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: searchQuery,
										onChange: (e) => {
											setSearchQuery(e.target.value);
											if (selectedId) loadMessages(selectedId, e.target.value);
										},
										placeholder: isAr ? "بحث في الرسائل..." : "Search messages...",
										className: "ps-8 pe-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/20"
									})]
								}), activeConv.type === "group" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
									size: "sm",
									onClick: () => setShowGroupPanel(!showGroupPanel),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إدارة المجموعة" : "Group Info" })]
								})]
							})]
						}),
						activeConv.announcement && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-2 bg-blue-500/10 border-b border-blue-500/20 text-xs text-blue-700 dark:text-cyan-300 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "w-3.5 h-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: activeConv.announcement
							})]
						}),
						showGroupPanel && activeConv.type === "group" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 bg-slate-50 dark:bg-[#0e1934] border-b border-slate-200 dark:border-blue-500/20 space-y-3 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold text-slate-900 dark:text-white",
									children: isAr ? "إعلان المجموعة والمشرفون" : "Group Announcement & Members"
								}),
								isGroupAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: announcementInput,
										onChange: (e) => setAnnouncementInput(e.target.value),
										placeholder: "Broadcast announcement to group...",
										className: "flex-1 px-3 py-1.5 rounded bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/20"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
										size: "sm",
										type: "button",
										onClick: handleUpdateAnnouncement,
										children: "Update"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-slate-600 dark:text-slate-300",
									children: ["Members: ", activeConv.memberIds.map((id) => userMap.get(id)?.fullName).filter(Boolean).join(" · ")]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 p-4 space-y-3 overflow-y-auto max-h-[380px]",
							children: [messages.map((msg) => {
								const sender = userMap.get(msg.senderId);
								const isMine = msg.senderId === currentUser.id;
								const isPinned = activeConv.pinnedMessageIds.includes(msg.id);
								const repliedMsg = msg.replyToId ? messages.find((m) => m.id === msg.replyToId) : void 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `flex flex-col ${isMine ? "items-end" : "items-start"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `max-w-[82%] rounded-xl px-3.5 py-2.5 border ${isMine ? "bg-[#1D7AFC]/15 border-blue-500/35 text-slate-900 dark:text-white" : "bg-slate-50 dark:bg-[#0e1934] border-slate-200 dark:border-blue-500/20 text-slate-900 dark:text-slate-100"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-4 text-[11px] text-slate-500 dark:text-slate-400",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-semibold text-slate-700 dark:text-slate-200",
													children: sender?.fullName || "Member"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-mono-tabular",
													children: [new Date(msg.createdAt).toLocaleTimeString([], {
														hour: "2-digit",
														minute: "2-digit"
													}), isPinned && " · Pinned"]
												})]
											}),
											repliedMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-1 px-2 py-1 rounded bg-slate-200/60 dark:bg-[#091124] text-[11px] text-slate-600 dark:text-slate-400 truncate",
												children: ["↩ ", repliedMsg.content]
											}),
											msg.content && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-xs leading-relaxed whitespace-pre-wrap",
												children: msg.content
											}),
											msg.attachment && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
												href: msg.attachment.dataUrl,
												download: msg.attachment.name,
												className: "mt-2 inline-flex items-center gap-1.5 text-xs text-[#1D7AFC] dark:text-[#00D4FF] underline",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: msg.attachment.name })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-2 flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => apiRequest(`/api/messages/${msg.id}/react`, {
															method: "POST",
															body: JSON.stringify({ emoji: "👍" })
														}),
														className: "hover:text-[#00D4FF] cursor-pointer",
														children: ["👍 ", msg.reactions["👍"]?.length || 0]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => setReplyTo(msg),
														className: "hover:text-[#00D4FF] inline-flex items-center gap-1 cursor-pointer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reply, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Reply" })]
													}),
													isGroupAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														type: "button",
														onClick: () => handlePinToggle(msg.id),
														className: "hover:text-[#00D4FF] inline-flex items-center gap-1 cursor-pointer",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isPinned ? "Unpin" : "Pin" })]
													}),
													isMine && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "ms-auto",
														children: msg.readBy.length > 1 ? "Read" : "Sent"
													})
												]
											})
										]
									})
								}, msg.id);
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: endRef })]
						}),
						activeTypers.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-1 text-[11px] text-[#1D7AFC] dark:text-[#00D4FF]",
							children: [
								activeTypers.join(", "),
								" ",
								isAr ? "يكتب الآن..." : "is typing..."
							]
						}),
						replyTo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-1.5 bg-slate-100 dark:bg-[#0e1934] text-xs flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "truncate text-slate-600 dark:text-slate-300",
								children: ["Replying to: ", replyTo.content]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setReplyTo(null),
								className: "text-rose-500 cursor-pointer",
								children: "×"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleSend,
							className: "p-3 border-t border-slate-200 dark:border-blue-500/15 flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "p-2 rounded-lg bg-slate-100 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/20 text-slate-600 dark:text-slate-300 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										onChange: handleFilePick,
										className: "hidden"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: draftText,
									onChange: (e) => {
										setDraftText(e.target.value);
										if (selectedId) sendWsTyping(selectedId, e.target.value.length > 0);
									},
									placeholder: attachment ? `Attached: ${attachment.name} — add note...` : isAr ? "اكتب رسالتك..." : "Write a message...",
									className: "flex-1 px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-900 dark:text-white"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
									size: "sm",
									type: "submit",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إرسال" : "Send" })]
								})
							]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-8 text-sm text-slate-400",
						children: "Select a conversation to begin."
					})
				})]
			})
		]
	});
};
var TasksProjectsView = ({ lang, currentUser, users }) => {
	const isAr = lang === "ar";
	const isPrivileged = currentUser.role === "admin" || currentUser.role === "supervisor";
	const [projects, setProjects] = (0, import_react.useState)([]);
	const [tasks, setTasks] = (0, import_react.useState)([]);
	const [selectedProjectId, setSelectedProjectId] = (0, import_react.useState)("all");
	const [showNewTask, setShowNewTask] = (0, import_react.useState)(false);
	const [selectedTask, setSelectedTask] = (0, import_react.useState)(null);
	const [commentText, setCommentText] = (0, import_react.useState)("");
	const [title, setTitle] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [assigneeId, setAssigneeId] = (0, import_react.useState)(currentUser.id);
	const [priority, setPriority] = (0, import_react.useState)("medium");
	const [deadline, setDeadline] = (0, import_react.useState)(new Date(Date.now() + 432e6).toISOString().slice(0, 10));
	const userMap = new Map(users.map((u) => [u.id, u]));
	const loadTasks = async () => {
		const res = await apiRequest("/api/tasks");
		setProjects(res.projects);
		setTasks(res.tasks);
		if (selectedTask) {
			const updated = res.tasks.find((t) => t.id === selectedTask.id);
			if (updated) setSelectedTask(updated);
		}
	};
	(0, import_react.useEffect)(() => {
		loadTasks();
	}, []);
	const handleCreateTask = async (e) => {
		e.preventDefault();
		await apiRequest("/api/tasks", {
			method: "POST",
			body: JSON.stringify({
				projectId: selectedProjectId === "all" ? projects[0]?.id : selectedProjectId,
				title,
				description,
				assigneeId,
				priority,
				deadline
			})
		});
		setShowNewTask(false);
		setTitle("");
		setDescription("");
		loadTasks();
	};
	const handleMoveStatus = async (taskId, status) => {
		await apiRequest(`/api/tasks/${taskId}`, {
			method: "PATCH",
			body: JSON.stringify({ status })
		});
		loadTasks();
	};
	const handleAddComment = async (e) => {
		e.preventDefault();
		if (!selectedTask || !commentText.trim()) return;
		await apiRequest(`/api/tasks/${selectedTask.id}/comments`, {
			method: "POST",
			body: JSON.stringify({ text: commentText.trim() })
		});
		setCommentText("");
		loadTasks();
	};
	const visibleTasks = tasks.filter((t) => selectedProjectId === "all" || t.projectId === selectedProjectId);
	const columns = [
		{
			key: "backlog",
			label: "Backlog",
			labelAr: "قائمة الانتظار"
		},
		{
			key: "in_progress",
			label: "In Progress",
			labelAr: "قيد التنفيذ"
		},
		{
			key: "in_review",
			label: "In Review",
			labelAr: "قيد المراجعة"
		},
		{
			key: "done",
			label: "Done",
			labelAr: "مكتمل"
		}
	];
	const workload = users.map((u) => ({
		user: u,
		openCount: tasks.filter((t) => t.assigneeId === u.id && t.status !== "done").length,
		doneCount: tasks.filter((t) => t.assigneeId === u.id && t.status === "done").length
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: isAr ? "إدارة المهام والمشاريع" : "Tasks & Project Boards",
				subtitle: isAr ? "توزيع المهام، تحديد الأولويات والمواعيد النهائية، ومتابعة عبء العمل الجماعي." : "Organize project sprints, assign tasks, track deadlines, collaborate in comments, and monitor team workload.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
					size: "sm",
					onClick: () => setShowNewTask(!showNewTask),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "مهمة جديدة" : "New Task" })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSelectedProjectId("all"),
					className: `px-3 py-1.5 text-xs font-medium rounded-lg border cursor-pointer ${selectedProjectId === "all" ? "bg-[#1D7AFC]/15 border-[#00D4FF] text-slate-900 dark:text-white" : "bg-white dark:bg-[#091124] border-slate-200 dark:border-blue-500/20 text-slate-600 dark:text-slate-400"}`,
					children: isAr ? "جميع المشاريع" : "All Projects"
				}), projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSelectedProjectId(p.id),
					className: `px-3 py-1.5 text-xs font-medium rounded-lg border cursor-pointer ${selectedProjectId === p.id ? "bg-[#1D7AFC]/15 border-[#00D4FF] text-slate-900 dark:text-white" : "bg-white dark:bg-[#091124] border-slate-200 dark:border-blue-500/20 text-slate-600 dark:text-slate-400"}`,
					children: p.name
				}, p.id))]
			}),
			showNewTask && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
				elevated: true,
				className: "p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleCreateTask,
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: title,
							onChange: (e) => setTitle(e.target.value),
							placeholder: isAr ? "عنوان المهمة" : "Task title",
							className: "lg:col-span-2 px-3 py-2 text-sm rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: assigneeId,
							onChange: (e) => setAssigneeId(e.target.value),
							disabled: !isPrivileged,
							className: "px-3 py-2 text-xs rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25",
							children: users.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: u.id,
								children: u.fullName
							}, u.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: priority,
							onChange: (e) => setPriority(e.target.value),
							className: "px-3 py-2 text-xs rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "low",
									children: "Low Priority"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "medium",
									children: "Medium Priority"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "high",
									children: "High Priority"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "urgent",
									children: "Urgent"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: description,
							onChange: (e) => setDescription(e.target.value),
							placeholder: isAr ? "وصف المهمة..." : "Description...",
							className: "sm:col-span-2 lg:col-span-3 px-3 py-2 text-xs rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							value: deadline,
							onChange: (e) => setDeadline(e.target.value),
							className: "px-3 py-2 text-xs font-mono-tabular rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:col-span-2 lg:col-span-4 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
								size: "sm",
								type: "button",
								onClick: () => setShowNewTask(false),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								size: "sm",
								type: "submit",
								children: "Create Task"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4",
				children: columns.map((col) => {
					const colTasks = visibleTasks.filter((t) => t.status === col.key);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
						className: "p-4 flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between pb-2 border-b border-slate-200 dark:border-blue-500/15",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-sm font-semibold text-slate-900 dark:text-white",
								children: isAr ? col.labelAr : col.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono-tabular text-xs text-slate-500 dark:text-slate-400",
								children: colTasks.length
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: colTasks.map((task) => {
								const assignee = userMap.get(task.assigneeId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									onClick: () => setSelectedTask(task),
									className: "p-3.5 rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-200 dark:border-blue-500/20 hover:border-[#00D4FF] transition-colors cursor-pointer space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs font-semibold text-slate-900 dark:text-white leading-snug",
											children: task.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[11px] text-slate-500 dark:text-slate-400",
											children: [
												task.priority,
												" · Due ",
												task.deadline,
												" · ",
												assignee?.fullName || "Unassigned"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-1.5 rounded-full bg-slate-200 dark:bg-[#091124] overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full bg-gradient-to-r from-[#1D7AFC] to-[#00D4FF]",
												style: { width: `${task.progress}%` }
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between pt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] text-slate-500 inline-flex items-center gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "w-3 h-3" }),
													" ",
													task.comments.length
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
												value: task.status,
												onClick: (e) => e.stopPropagation(),
												onChange: (e) => handleMoveStatus(task.id, e.target.value),
												className: "text-[11px] px-2 py-0.5 rounded bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/20",
												children: columns.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: c.key,
													children: c.label
												}, c.key))
											})]
										})
									]
								}, task.id);
							})
						})]
					}, col.key);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "lg:col-span-6 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-base font-semibold text-slate-900 dark:text-white mb-3",
						children: isAr ? "نظرة عامة على عبء عمل الفريق" : "Team Workload Overview"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y divide-slate-200 dark:divide-blue-500/15",
						children: workload.map(({ user, openCount, doneCount }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-2.5 flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-slate-900 dark:text-white",
								children: user.fullName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-slate-500 dark:text-slate-400",
								children: [" · ", user.desiredRole]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-mono-tabular text-slate-600 dark:text-slate-300",
								children: [
									openCount,
									" open · ",
									doneCount,
									" done"
								]
							})]
						}, user.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
					className: "lg:col-span-6 p-5",
					children: selectedTask ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-base font-semibold text-slate-900 dark:text-white",
									children: selectedTask.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
									children: selectedTask.description || "No additional description."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono-tabular text-xs text-[#1D7AFC] dark:text-[#00D4FF]",
									children: [selectedTask.progress, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2 max-h-40 overflow-y-auto",
								children: selectedTask.comments.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2.5 rounded-lg bg-slate-50 dark:bg-[#0e1934] text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-semibold text-slate-900 dark:text-white",
										children: userMap.get(c.authorId)?.fullName || "Member"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-slate-600 dark:text-slate-300 mt-0.5",
										children: c.text
									})]
								}, c.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleAddComment,
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: commentText,
									onChange: (e) => setCommentText(e.target.value),
									placeholder: isAr ? "أضف تعليقاً..." : "Write a task comment...",
									className: "flex-1 px-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
									size: "sm",
									type: "submit",
									children: "Post"
								})]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-slate-500 dark:text-slate-400 py-8 text-center",
						children: isAr ? "اختر مهمة من اللوحة لعرض تفاصيلها والتعليقات." : "Click any task card to inspect details and post comments."
					})
				})]
			})
		]
	});
};
var MeetingsIntegrationsView = ({ lang, currentUser, users }) => {
	const isAr = lang === "ar";
	const isPrivileged = currentUser.role === "admin" || currentUser.role === "supervisor";
	const [meetings, setMeetings] = (0, import_react.useState)([]);
	const [integrations, setIntegrations] = (0, import_react.useState)([]);
	const [showCreate, setShowCreate] = (0, import_react.useState)(false);
	const [title, setTitle] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [startTime, setStartTime] = (0, import_react.useState)("");
	const [endTime, setEndTime] = (0, import_react.useState)("");
	const [provider, setProvider] = (0, import_react.useState)("internal");
	const [meetingUrl, setMeetingUrl] = (0, import_react.useState)("");
	const [participants, setParticipants] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [googleToken, setGoogleToken] = (0, import_react.useState)("");
	const [zoomAccountId, setZoomAccountId] = (0, import_react.useState)("");
	const [zoomClientId, setZoomClientId] = (0, import_react.useState)("");
	const [zoomClientSecret, setZoomClientSecret] = (0, import_react.useState)("");
	const loadData = async () => {
		const res = await apiRequest("/api/meetings");
		setMeetings(res.meetings);
		setIntegrations(res.integrations);
	};
	(0, import_react.useEffect)(() => {
		loadData();
	}, []);
	const handleCreateMeeting = async (e) => {
		e.preventDefault();
		setError(null);
		try {
			await apiRequest("/api/meetings", {
				method: "POST",
				body: JSON.stringify({
					title,
					description,
					startTime: new Date(startTime).toISOString(),
					endTime: new Date(endTime).toISOString(),
					provider,
					meetingUrl: meetingUrl || void 0,
					participantIds: participants
				})
			});
			setShowCreate(false);
			setTitle("");
			setDescription("");
			setMeetingUrl("");
			loadData();
			setNotice(isAr ? "تمت جدولة الاجتماع وإرسال الدعوات." : "Meeting scheduled and invitations sent.");
		} catch (err) {
			setError(err.message);
		}
	};
	const handleVerifyIntegration = async (prov) => {
		setError(null);
		setNotice(null);
		try {
			await apiRequest("/api/integrations/verify", {
				method: "POST",
				body: JSON.stringify(prov === "google" ? {
					provider: "google",
					accessToken: googleToken
				} : {
					provider: "zoom",
					zoomAccountId,
					zoomClientId,
					zoomClientSecret
				})
			});
			setNotice(`${prov === "google" ? "Google" : "Zoom"} credentials verified and connected.`);
			loadData();
		} catch (err) {
			setError(err.message);
		}
	};
	const handleDownloadIcs = async (meetingId) => {
		await downloadTextFile(`/api/meetings/${meetingId}/ics`, `${meetingId}.ics`, "text/calendar");
	};
	const googleCfg = integrations.find((i) => i.provider === "google");
	const zoomCfg = integrations.find((i) => i.provider === "zoom");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: isAr ? "الاجتماعات وتكامل Google و Zoom" : "Meetings, Calendar & Integrations",
				subtitle: isAr ? "جدولة اجتماعات الفريق وتصدير ملفات التقويم (.ics) والتحقق الحقيقي من اتصال Google و Zoom." : "Schedule team meetings, download .ics calendar invites, and verify authentic Google and Zoom OAuth credentials.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
					size: "sm",
					onClick: () => setShowCreate(!showCreate),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "جدولة اجتماع" : "Schedule Meeting" })]
				})
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-300",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3 rounded-lg bg-blue-500/10 border border-blue-500/30 text-xs text-blue-700 dark:text-cyan-300",
				children: notice
			}),
			showCreate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
				elevated: true,
				className: "p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleCreateMeeting,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									value: title,
									onChange: (e) => setTitle(e.target.value),
									placeholder: isAr ? "عنوان الاجتماع" : "Meeting title",
									className: "sm:col-span-2 px-3 py-2 text-sm rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: provider,
									onChange: (e) => setProvider(e.target.value),
									className: "px-3 py-2 text-xs rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "internal",
											children: "KAVIRO Workspace Calendar"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "google_meet",
											children: "Google Meet"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "zoom",
											children: "Zoom"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: meetingUrl,
									onChange: (e) => setMeetingUrl(e.target.value),
									placeholder: "Join URL (optional if internal)",
									className: "px-3 py-2 text-xs rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									type: "datetime-local",
									value: startTime,
									onChange: (e) => setStartTime(e.target.value),
									className: "px-3 py-2 text-xs font-mono-tabular rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									type: "datetime-local",
									value: endTime,
									onChange: (e) => setEndTime(e.target.value),
									className: "px-3 py-2 text-xs font-mono-tabular rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: description,
									onChange: (e) => setDescription(e.target.value),
									placeholder: "Agenda...",
									className: "sm:col-span-2 px-3 py-2 text-xs rounded-lg bg-white dark:bg-[#091124] border border-slate-300 dark:border-blue-500/25"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: users.filter((u) => u.id !== currentUser.id).map((u) => {
								const chosen = participants.includes(u.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setParticipants(chosen ? participants.filter((id) => id !== u.id) : [...participants, u.id]),
									className: `px-3 py-1 text-xs rounded-lg border cursor-pointer ${chosen ? "bg-[#1D7AFC]/15 border-[#00D4FF] text-slate-900 dark:text-white" : "bg-white dark:bg-[#091124] border-slate-200 dark:border-blue-500/20 text-slate-600 dark:text-slate-300"}`,
									children: u.fullName
								}, u.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
								size: "sm",
								type: "button",
								onClick: () => setShowCreate(false),
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								size: "sm",
								type: "submit",
								children: "Schedule"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "lg:col-span-7 p-6 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold text-slate-900 dark:text-white",
						children: isAr ? "الاجتماعات القادمة" : "Upcoming Team Schedule"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y divide-slate-200 dark:divide-blue-500/15",
						children: meetings.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-semibold text-sm text-slate-900 dark:text-white flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-4 h-4 text-[#1D7AFC] dark:text-[#00D4FF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: m.title })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-slate-600 dark:text-slate-400",
										children: m.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs font-mono-tabular text-slate-500 dark:text-slate-400",
										children: [
											new Date(m.startTime).toLocaleString(),
											" · ",
											m.provider,
											" · ",
											m.participantIds.length,
											" participants"
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 shrink-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
									size: "sm",
									onClick: () => handleDownloadIcs(m.id),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: ".ICS" })]
								}), m.meetingUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: m.meetingUrl,
									target: "_blank",
									rel: "noreferrer",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
										size: "sm",
										type: "button",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Join" })]
									})
								})]
							})]
						}, m.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
						className: "p-5 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 font-display text-base font-semibold text-slate-900 dark:text-white",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "w-4 h-4 text-[#1D7AFC] dark:text-[#00D4FF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Google Workspace & Calendar" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `text-xs font-semibold ${googleCfg?.connected ? "text-emerald-500" : "text-amber-500"}`,
									children: googleCfg?.connected ? "Connected (Verified)" : "Not Connected"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-600 dark:text-slate-400",
								children: googleCfg?.note
							}),
							isPrivileged && !googleCfg?.connected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: googleToken,
									onChange: (e) => setGoogleToken(e.target.value),
									placeholder: "Paste verified Google OAuth2 Access Token...",
									className: "w-full px-3 py-2 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
									size: "sm",
									onClick: () => handleVerifyIntegration("google"),
									children: "Verify Google OAuth Token"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
						className: "p-5 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 font-display text-base font-semibold text-slate-900 dark:text-white",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "w-4 h-4 text-[#1D7AFC] dark:text-[#00D4FF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Zoom Meetings API" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `text-xs font-semibold ${zoomCfg?.connected ? "text-emerald-500" : "text-amber-500"}`,
									children: zoomCfg?.connected ? "Connected (Verified)" : "Not Connected"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-600 dark:text-slate-400",
								children: zoomCfg?.note
							}),
							isPrivileged && !zoomCfg?.connected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 pt-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: zoomAccountId,
										onChange: (e) => setZoomAccountId(e.target.value),
										placeholder: "Zoom Account ID",
										className: "w-full px-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: zoomClientId,
										onChange: (e) => setZoomClientId(e.target.value),
										placeholder: "Zoom Client ID",
										className: "w-full px-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "password",
										value: zoomClientSecret,
										onChange: (e) => setZoomClientSecret(e.target.value),
										placeholder: "Zoom Client Secret",
										className: "w-full px-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
										size: "sm",
										onClick: () => handleVerifyIntegration("zoom"),
										children: "Verify Zoom Credentials"
									})
								]
							})
						]
					})]
				})]
			})
		]
	});
};
var DEFAULT_SUPERVISOR_PERMS = {
	canApproveMembers: true,
	canManageAssessments: true,
	canViewSessions: true,
	canRevokeSessions: true,
	canManageTasksAndGroups: true,
	canViewAnalytics: true,
	canManageIntegrations: false
};
var PERMISSION_LABELS = [
	{
		key: "canApproveMembers",
		en: "Approve / Suspend Members",
		ar: "قبول وتعليق حسابات الأعضاء"
	},
	{
		key: "canManageAssessments",
		en: "Create & Grade Assessments",
		ar: "إنشاء وتصحيح الاختبارات"
	},
	{
		key: "canViewSessions",
		en: "View Team Devices & Sessions",
		ar: "رؤية الأجهزة والجلسات المسجلة"
	},
	{
		key: "canRevokeSessions",
		en: "Force Logout Team Devices",
		ar: "إخراج الأجهزة وإنهاء الجلسات عن بُعد"
	},
	{
		key: "canManageTasksAndGroups",
		en: "Manage Projects & Groups",
		ar: "إدارة المشاريع ومجموعات المحادثة"
	},
	{
		key: "canViewAnalytics",
		en: "View Analytics & Audit Logs",
		ar: "عرض التقارير وسجلات التدقيق"
	},
	{
		key: "canManageIntegrations",
		en: "Configure Google & Zoom",
		ar: "إعداد تكامل Google و Zoom"
	}
];
var SecuritySessionsView = ({ lang, currentUser, users, onRefreshUsers }) => {
	const isAr = lang === "ar";
	const isAdmin = currentUser.role === "admin";
	const canViewAllSessions = isAdmin || currentUser.role === "supervisor" && (currentUser.supervisorPermissions?.canViewSessions ?? true);
	const canRevokeOthers = isAdmin || currentUser.role === "supervisor" && (currentUser.supervisorPermissions?.canRevokeSessions ?? true);
	const canApproveMembers = isAdmin || currentUser.role === "supervisor" && (currentUser.supervisorPermissions?.canApproveMembers ?? true);
	const [sessions, setSessions] = (0, import_react.useState)([]);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [accountQuery, setAccountQuery] = (0, import_react.useState)("");
	const [editingSupervisorId, setEditingSupervisorId] = (0, import_react.useState)(null);
	const [permDraft, setPermDraft] = (0, import_react.useState)(DEFAULT_SUPERVISOR_PERMS);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const loadSessions = async () => {
		try {
			const res = await apiRequest("/api/sessions");
			setSessions(res.sessions);
		} catch (e) {
			setError(e.message);
		}
	};
	(0, import_react.useEffect)(() => {
		loadSessions();
	}, []);
	const handleRevoke = async (sessionId) => {
		setError(null);
		setNotice(null);
		try {
			await apiRequest(`/api/sessions/${sessionId}`, { method: "DELETE" });
			setNotice(isAr ? "تم إنهاء الجلسة وإخراج الجهاز فوراً." : "Session revoked and device logged out immediately.");
			loadSessions();
		} catch (e) {
			setError(e.message);
		}
	};
	const handleRevokeAllForUser = async (userId, fullName) => {
		setError(null);
		setNotice(null);
		try {
			const res = await apiRequest(`/api/sessions/revoke-user/${userId}`, { method: "POST" });
			setNotice(isAr ? `تم إخراج ${res.revokedCount} أجهزة نشطة لحساب ${fullName}.` : `Force-logged out ${res.revokedCount} active device(s) for ${fullName}.`);
			loadSessions();
		} catch (e) {
			setError(e.message);
		}
	};
	const handleRoleChange = async (userId, role) => {
		setError(null);
		try {
			await apiRequest(`/api/admin/users/${userId}/role`, {
				method: "PATCH",
				body: JSON.stringify({ role })
			});
			await onRefreshUsers();
			setNotice(isAr ? "تم تحديث الدور بنجاح." : "Account role updated on server.");
		} catch (e) {
			setError(e.message);
		}
	};
	const handleStatusChange = async (userId, status) => {
		setError(null);
		try {
			await apiRequest(`/api/admin/users/${userId}/status`, {
				method: "PATCH",
				body: JSON.stringify({ status })
			});
			await onRefreshUsers();
			await loadSessions();
			setNotice(isAr ? `تم تحديث حالة الحساب إلى ${status}.` : `Account status updated to ${status}.`);
		} catch (e) {
			setError(e.message);
		}
	};
	const handleDeleteUser = async (userId, fullName) => {
		setError(null);
		try {
			await apiRequest(`/api/admin/users/${userId}`, { method: "DELETE" });
			await onRefreshUsers();
			await loadSessions();
			setNotice(isAr ? `تم حذف الحساب (${fullName}).` : `Removed account ${fullName}.`);
		} catch (e) {
			setError(e.message);
		}
	};
	const openPermissionEditor = (user) => {
		setEditingSupervisorId(user.id);
		setPermDraft(user.supervisorPermissions || { ...DEFAULT_SUPERVISOR_PERMS });
	};
	const handleSavePermissions = async () => {
		if (!editingSupervisorId) return;
		setError(null);
		try {
			await apiRequest(`/api/admin/users/${editingSupervisorId}/permissions`, {
				method: "PATCH",
				body: JSON.stringify({ permissions: permDraft })
			});
			setEditingSupervisorId(null);
			await onRefreshUsers();
			setNotice(isAr ? "تم حفظ صلاحيات المشرف المخصصة على الخادم." : "Granular supervisor permissions saved.");
		} catch (e) {
			setError(e.message);
		}
	};
	const visibleSessions = sessions.filter((s) => {
		if (filter === "active") return s.status === "active";
		if (filter === "unusual") return s.isUnusual;
		return true;
	});
	const activeDevicesCount = sessions.filter((s) => s.status === "active").length;
	const unusualAlertsCount = sessions.filter((s) => s.isUnusual && s.status === "active").length;
	const supervisorsCount = users.filter((u) => u.role === "supervisor" || u.role === "admin").length;
	const filteredUsers = users.filter((u) => !accountQuery || u.fullName.toLowerCase().includes(accountQuery.toLowerCase()) || u.email.toLowerCase().includes(accountQuery.toLowerCase()) || u.role.toLowerCase().includes(accountQuery.toLowerCase()));
	const DeviceIcon = (type) => {
		if (type === "Mobile") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "w-4 h-4 text-[#00D4FF]" });
		if (type === "Tablet") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tablet, { className: "w-4 h-4 text-[#00D4FF]" });
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, { className: "w-4 h-4 text-[#1D7AFC] dark:text-[#00D4FF]" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: isAr ? "مركز الأجهزة والحسابات وصلاحيات المشرفين" : "Devices, Accounts & Supervisor Control",
				subtitle: canViewAllSessions ? isAr ? "مراقبة كل الأجهزة الشغالة والتي دخلت سابقاً، التحكم الكامل بالحسابات، وتعيين مشرفين بصلاحيات محددة." : "Monitor active & historical devices, control all accounts, promote supervisors, and assign granular server-enforced permissions." : isAr ? "سجل جلساتك والأجهزة المتصلة بحسابك بشفافية تامة." : "Transparent log of your active sessions and previously used devices."
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-300",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3 rounded-lg bg-blue-500/10 border border-blue-500/30 text-xs text-blue-700 dark:text-cyan-300",
				children: notice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: isAr ? "الأجهزة الشغالة الآن" : "Active Devices Now",
						value: activeDevicesCount,
						context: isAr ? "جلسات متصلة حالياً" : "Live authenticated sessions",
						tone: "accent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: isAr ? "كل الأجهزة المسجلة" : "Total Device Logins",
						value: sessions.length,
						context: isAr ? "الحالية والسابقة" : "Active + historical history"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: isAr ? "تنبيهات دخول غير معتاد" : "Unusual Login Alerts",
						value: unusualAlertsCount,
						context: isAr ? "أجهزة أو متصفحات جديدة" : "Unrecognized device/OS",
						tone: unusualAlertsCount > 0 ? "danger" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: isAr ? "المشرفون والمديرون" : "Admins & Supervisors",
						value: supervisorsCount,
						context: `${users.length} ${isAr ? "إجمالي الحسابات" : "total accounts"}`,
						tone: "success"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "inline-flex items-center gap-1 p-1 rounded-lg bg-slate-200/70 dark:bg-[#091124] border border-slate-300 dark:border-blue-500/20",
				children: [
					"all",
					"active",
					"unusual"
				].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(tab),
					className: `px-3 py-1.5 text-xs font-medium rounded-md cursor-pointer ${filter === tab ? "bg-white dark:bg-[#0e1934] text-slate-900 dark:text-white shadow-sm" : "text-slate-600 dark:text-slate-400"}`,
					children: tab === "all" ? isAr ? "كل الأجهزة والجلسات" : "All Devices & History" : tab === "active" ? isAr ? "الشغالة الآن فقط" : "Active Now Only" : isAr ? "تنبيهات غريبة" : "Unusual Alerts"
				}, tab))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
				className: "overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-start text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-slate-50 dark:bg-[#0e1934] border-b border-slate-200 dark:border-blue-500/15 text-slate-500 dark:text-slate-400",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4 text-start font-medium",
									children: isAr ? "الحساب" : "Account"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4 text-start font-medium",
									children: isAr ? "الجهاز والنظام" : "Device & OS"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4 text-start font-medium",
									children: isAr ? "المتصفح و IP" : "Browser & IP"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4 text-start font-medium",
									children: isAr ? "أوقات الدخول والنشاط" : "Timestamps"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4 text-start font-medium",
									children: isAr ? "الحالة" : "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4 text-end font-medium",
									children: isAr ? "التحكم" : "Action"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-slate-200 dark:divide-blue-500/15",
							children: visibleSessions.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "hover:bg-slate-50 dark:hover:bg-[#0e1934]/60",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-3 px-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-semibold text-slate-900 dark:text-white",
											children: [
												s.userName,
												" ",
												s.isCurrent && (isAr ? "(جلسة حالية)" : "(Current)")
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-slate-500 dark:text-slate-400",
											children: [
												s.userEmail,
												" · ",
												s.userRole
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 px-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-slate-800 dark:text-slate-200",
											children: [DeviceIcon(s.deviceType), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												s.deviceType,
												" · ",
												s.os
											] })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-3 px-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-slate-800 dark:text-slate-200",
											children: s.browser
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-mono-tabular text-slate-500 dark:text-slate-400",
											children: s.ipAddress
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-3 px-4 font-mono-tabular text-slate-600 dark:text-slate-300",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["In: ", new Date(s.loginAt).toLocaleString()] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: s.logoutAt ? `Out: ${new Date(s.logoutAt).toLocaleString()}` : `Active: ${new Date(s.lastActivityAt).toLocaleTimeString()}` })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-3 px-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `font-semibold ${s.status === "active" ? "text-emerald-600 dark:text-emerald-400" : s.status === "revoked" ? "text-rose-600 dark:text-rose-400" : "text-slate-500"}`,
											children: s.status.toUpperCase()
										}), s.isUnusual && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-0.5 inline-flex items-center gap-1 text-[11px] text-amber-600 dark:text-amber-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "w-3 h-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.alertReason || "Unusual device" })]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 px-4 text-end",
										children: s.status === "active" && !s.isCurrent && (canRevokeOthers || s.userId === currentUser.id) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
											size: "sm",
											onClick: () => handleRevoke(s.id),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "w-3.5 h-3.5 text-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إنهاء الجلسة" : "Force Logout" })]
										})
									})
								]
							}, s.id))
						})]
					})
				})
			}),
			(isAdmin || canApproveMembers) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
				className: "p-6 space-y-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-200 dark:border-blue-500/15",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, { className: "w-4 h-4 text-[#1D7AFC] dark:text-[#00D4FF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-base font-semibold text-slate-900 dark:text-white",
							children: isAr ? "إدارة الحسابات وتعيين المشرفين وصلاحياتهم" : "Accounts Control, Role Assignment & Supervisor Permissions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 dark:text-slate-400",
							children: isAdmin ? isAr ? "بصفتك المدير العام (Admin)، يمكنك تعيين أي عضو كمشرف وتحديد صلاحياته بدقة أو تعليق أي حساب." : "As Master Administrator, promote members to Supervisor or Admin, customize exact Supervisor permissions, or revoke all devices." : isAr ? "إدارة حالة الحسابات المصرح لك بمراجعتها." : "Manage member account statuses within your granted permissions."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: accountQuery,
						onChange: (e) => setAccountQuery(e.target.value),
						placeholder: isAr ? "ابحث بالاسم أو البريد..." : "Search accounts...",
						className: "px-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y divide-slate-200 dark:divide-blue-500/15",
					children: filteredUsers.map((u) => {
						const userActiveSessions = sessions.filter((s) => s.userId === u.id && s.status === "active").length;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "py-4 space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-semibold text-sm text-slate-900 dark:text-white flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: u.fullName }), u.id === currentUser.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-medium text-[#1D7AFC] dark:text-[#00D4FF]",
											children: [
												"(",
												isAr ? "أنت" : "You",
												")"
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-slate-500 dark:text-slate-400 mt-0.5",
										children: [
											u.email,
											" · ",
											u.desiredRole,
											" ·",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: u.status === "approved" ? "text-emerald-500 font-semibold" : u.status === "pending" ? "text-amber-500 font-semibold" : "text-rose-500 font-semibold",
												children: u.status
											}),
											" ",
											"· ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono-tabular",
												children: [userActiveSessions, " active device(s)"]
											})
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2 shrink-0",
									children: [
										isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: u.role,
											disabled: u.id === currentUser.id,
											onChange: (e) => handleRoleChange(u.id, e.target.value),
											className: "px-2.5 py-1.5 rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "member",
													children: isAr ? "عضو (Member)" : "Member"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "supervisor",
													children: isAr ? "مشرف (Supervisor)" : "Supervisor"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "admin",
													children: isAr ? "مدير عام (Admin)" : "Administrator"
												})
											]
										}),
										isAdmin && u.role === "supervisor" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
											size: "sm",
											onClick: () => openPermissionEditor(u),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "w-3.5 h-3.5 text-[#00D4FF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تحديد الصلاحيات" : "Permissions" })]
										}),
										canApproveMembers && u.id !== currentUser.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [u.status !== "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
											size: "sm",
											onClick: () => handleStatusChange(u.id, "approved"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "w-3.5 h-3.5 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تفعيل" : "Approve" })]
										}), u.status !== "suspended" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
											size: "sm",
											onClick: () => handleStatusChange(u.id, "suspended"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserX, { className: "w-3.5 h-3.5 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تعليق" : "Suspend" })]
										})] }),
										canRevokeOthers && userActiveSessions > 0 && u.id !== currentUser.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
											size: "sm",
											onClick: () => handleRevokeAllForUser(u.id, u.fullName),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "w-3.5 h-3.5 text-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "إخراج كل الأجهزة" : "Revoke All Devices" })]
										}),
										isAdmin && u.id !== currentUser.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
											size: "sm",
											onClick: () => handleDeleteUser(u.id, u.fullName),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-3.5 h-3.5 text-rose-500" })
										})
									]
								})]
							}), isAdmin && editingSupervisorId === u.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 rounded-xl bg-slate-50 dark:bg-[#0e1934] border border-blue-500/30 space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-semibold text-slate-900 dark:text-white",
										children: isAr ? `صلاحيات المشرف المخصصة لـ: ${u.fullName}` : `Custom Supervisor Permissions for ${u.fullName}`
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
											size: "sm",
											type: "button",
											onClick: () => setEditingSupervisorId(null),
											children: isAr ? "إلغاء" : "Cancel"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
											size: "sm",
											type: "button",
											onClick: handleSavePermissions,
											children: isAr ? "حفظ الصلاحيات" : "Save Permissions"
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5",
									children: PERMISSION_LABELS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2.5 p-2.5 rounded-lg bg-white dark:bg-[#091124] border border-slate-200 dark:border-blue-500/20 text-xs cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: permDraft[item.key],
											onChange: (e) => setPermDraft({
												...permDraft,
												[item.key]: e.target.checked
											}),
											className: "accent-[#1D7AFC]"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-slate-800 dark:text-slate-200",
											children: isAr ? item.ar : item.en
										})]
									}, item.key))
								})]
							})]
						}, u.id);
					})
				})]
			})
		]
	});
};
var AnalyticsView = ({ lang, analytics }) => {
	const isAr = lang === "ar";
	const [actionFilter, setActionFilter] = (0, import_react.useState)("");
	const handleExportCsv = async () => {
		await downloadTextFile("/api/analytics/export.csv", "kaviro-analytics-report.csv", "text/csv");
	};
	if (!analytics) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
		className: "p-8 text-sm text-slate-400",
		children: "Loading analytics..."
	});
	const taskDistribution = [
		{
			label: "Backlog",
			count: analytics.taskStats.backlog,
			color: "#64748B"
		},
		{
			label: "In Progress",
			count: analytics.taskStats.inProgress,
			color: "#1D7AFC"
		},
		{
			label: "In Review",
			count: analytics.taskStats.inReview,
			color: "#00D4FF"
		},
		{
			label: "Done",
			count: analytics.taskStats.done,
			color: "#10B981"
		}
	];
	const maxTaskCount = Math.max(1, ...taskDistribution.map((d) => d.count));
	const filteredLogs = analytics.auditLogs.filter((l) => !actionFilter ? true : l.action.toLowerCase().includes(actionFilter.toLowerCase()) || l.actorName.toLowerCase().includes(actionFilter.toLowerCase()) || l.details.toLowerCase().includes(actionFilter.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: isAr ? "التقارير والتحليلات وتنزيل الموقع" : "Reports, Analytics & Downloadable Package",
				subtitle: isAr ? "إحصائيات الأعضاء والمهام والاختبارات، سجل التدقيق، وتصدير التقارير أو تنزيل كود الموقع الكامل." : "Interactive team metrics, project completion bars, audit trails, CSV exports, and full downloadable KAVIRO web archive.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
						size: "sm",
						onClick: handleExportCsv,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تصدير CSV" : "Export CSV" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
						size: "sm",
						type: "button",
						onClick: () => downloadProjectZip(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تنزيل الموقع (.zip)" : "Download Full Website (.zip)" })]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
				elevated: true,
				className: "p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-display text-sm font-semibold text-slate-900 dark:text-white",
						children: isAr ? "ملف الموقع القابل للتنزيل والتشغيل المستقل" : "Downloadable Full-Stack Website Package"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-slate-600 dark:text-slate-300",
						children: isAr ? "قم بتنزيل الحزمة الكاملة لمنصة KAVIRO (الواجهة الأمامية، الخادم، WebSockets، ونظام التصميم) في ملف ZIP واحد جاهز للتشغيل." : "Bundle the complete KAVIRO web platform (React, Design System, Express, WebSockets, Gemini AI backend, and logo assets) into a single ZIP file."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
					size: "sm",
					type: "button",
					onClick: () => downloadProjectZip(),
					className: "shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "kaviro-platform-web.zip" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: isAr ? "نسبة النجاح بالاختبارات" : "Avg Assessment Score",
						value: `${analytics.assessmentStats.avgScorePct}%`,
						context: `${analytics.assessmentStats.totalAttempts} attempts`,
						tone: "accent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: isAr ? "الأعضاء المعتمدون" : "Approved Roster",
						value: `${analytics.memberStats.approved}/${analytics.memberStats.total}`,
						context: `${analytics.memberStats.pending} pending review`,
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: isAr ? "المهام المكتملة" : "Tasks Completed",
						value: `${analytics.taskStats.done}/${analytics.taskStats.total}`,
						context: "Across active projects"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricTile, {
						label: isAr ? "تنبيهات الأمان" : "Security Alerts",
						value: analytics.securityStats.unusualAlerts,
						context: `${analytics.securityStats.activeSessions} active sessions`,
						tone: analytics.securityStats.unusualAlerts > 0 ? "danger" : "default"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "lg:col-span-6 p-6 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-base font-semibold text-slate-900 dark:text-white",
						children: isAr ? "توزيع حالة المهام" : "Task Completion Breakdown"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3 pt-2",
						children: taskDistribution.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-slate-700 dark:text-slate-300",
									children: item.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono-tabular font-semibold text-slate-900 dark:text-white",
									children: item.count
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-3 rounded-md bg-slate-100 dark:bg-[#0e1934] overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-md transition-all duration-300",
									style: {
										width: `${item.count / maxTaskCount * 100}%`,
										backgroundColor: item.color
									}
								})
							})]
						}, item.label))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
					className: "lg:col-span-6 p-6 space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-base font-semibold text-slate-900 dark:text-white",
						children: isAr ? "تقدم المشاريع الحالية" : "Project Delivery Progress"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-4 pt-2",
						children: analytics.projectProgress.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-slate-900 dark:text-white",
									children: p.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono-tabular text-[#1D7AFC] dark:text-[#00D4FF]",
									children: [
										p.progress,
										"% (",
										p.taskCount,
										" tasks)"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2.5 rounded-full bg-slate-100 dark:bg-[#0e1934] overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-gradient-to-r from-[#1D7AFC] to-[#00D4FF]",
									style: { width: `${p.progress}%` }
								})
							})]
						}, p.id))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
				className: "p-6 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-base font-semibold text-slate-900 dark:text-white",
						children: isAr ? "سجل التدقيق والنشاط الأمني" : "Platform Audit Logs"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: actionFilter,
						onChange: (e) => setActionFilter(e.target.value),
						placeholder: isAr ? "تصفية السجلات..." : "Filter audit logs...",
						className: "px-3 py-1.5 text-xs rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-start text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b border-slate-200 dark:border-blue-500/15 text-slate-500 dark:text-slate-400",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2.5 px-3 text-start",
									children: "Actor"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2.5 px-3 text-start",
									children: "Action"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2.5 px-3 text-start",
									children: "Details"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2.5 px-3 text-start",
									children: "IP"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2.5 px-3 text-end",
									children: "Timestamp"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-slate-200 dark:divide-blue-500/15",
							children: filteredLogs.map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 px-3 font-medium text-slate-900 dark:text-white",
									children: log.actorName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 px-3 font-mono-tabular text-[#1D7AFC] dark:text-[#00D4FF]",
									children: log.action
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 px-3 text-slate-600 dark:text-slate-300",
									children: log.details
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 px-3 font-mono-tabular text-slate-500",
									children: log.ipAddress
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2.5 px-3 text-end font-mono-tabular text-slate-500",
									children: new Date(log.createdAt).toLocaleString()
								})
							] }, log.id))
						})]
					})
				})]
			})
		]
	});
};
var ProfileView = ({ lang, currentUser, onUserUpdated }) => {
	const isAr = lang === "ar";
	const [fullName, setFullName] = (0, import_react.useState)(currentUser.fullName);
	const [email, setEmail] = (0, import_react.useState)(currentUser.email);
	const [phone, setPhone] = (0, import_react.useState)(currentUser.phone || "");
	const [whatsapp, setWhatsapp] = (0, import_react.useState)(currentUser.whatsapp || "");
	const [desiredRole, setDesiredRole] = (0, import_react.useState)(currentUser.desiredRole);
	const [department, setDepartment] = (0, import_react.useState)(currentUser.department);
	const [bio, setBio] = (0, import_react.useState)(currentUser.bio || "");
	const [skillsText, setSkillsText] = (0, import_react.useState)((currentUser.skills || []).join(", "));
	const [avatarUrl, setAvatarUrl] = (0, import_react.useState)(currentUser.avatarUrl);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [changingPass, setChangingPass] = (0, import_react.useState)(false);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const handleSave = async (e) => {
		e.preventDefault();
		setSaving(true);
		setNotice(null);
		setError(null);
		try {
			onUserUpdated((await apiRequest("/api/auth/profile", {
				method: "PATCH",
				body: JSON.stringify({
					fullName,
					email,
					phone,
					whatsapp,
					desiredRole,
					department,
					bio,
					avatarUrl,
					skills: skillsText.split(",").map((s) => s.trim()).filter(Boolean)
				})
			})).user);
			setNotice(isAr ? "تم تحديث الملف الشخصي والبريد الإلكتروني بنجاح." : "Profile and email updated successfully.");
		} catch (err) {
			setError(err.message);
		} finally {
			setSaving(false);
		}
	};
	const handleChangePassword = async (e) => {
		e.preventDefault();
		setChangingPass(true);
		setNotice(null);
		setError(null);
		try {
			await apiRequest("/api/auth/change-password", {
				method: "POST",
				body: JSON.stringify({
					currentPassword,
					newPassword
				})
			});
			setCurrentPassword("");
			setNewPassword("");
			setNotice(isAr ? "تم تغيير كلمة المرور بنجاح." : "Password changed successfully.");
		} catch (err) {
			setError(err.message);
		} finally {
			setChangingPass(false);
		}
	};
	const handleToggle2FA = async () => {
		const next = !currentUser.twoFactorEnabled;
		onUserUpdated((await apiRequest("/api/auth/2fa/toggle", {
			method: "POST",
			body: JSON.stringify({ enabled: next })
		})).user);
		setNotice(next ? isAr ? "تم تفعيل المصادقة الثنائية (2FA)." : "Two-factor authentication enabled." : isAr ? "تم إيقاف المصادقة الثنائية." : "Two-factor authentication disabled.");
	};
	const handlePhoto = (e) => {
		const file = e.target.files?.[0];
		if (!file || file.size > 15e5) return;
		const reader = new FileReader();
		reader.onload = () => setAvatarUrl(String(reader.result || ""));
		reader.readAsDataURL(file);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: isAr ? "الملف الشخصي وأمان الحساب" : "Profile & Account Security",
				subtitle: isAr ? "تحديث الاسم والبريد الإلكتروني، تغيير كلمة المرور، وتفعيل المصادقة الثنائية (2FA)." : "Update your name, email, password, skills, and two-factor authentication."
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-xs text-rose-600 dark:text-rose-300",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-3 rounded-lg bg-blue-500/10 border border-blue-500/30 text-xs text-blue-700 dark:text-cyan-300",
				children: notice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SurfaceCard, {
					className: "lg:col-span-7 p-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSave,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4 pb-4 border-b border-slate-200 dark:border-blue-500/15",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-16 w-16 rounded-xl bg-[#0e1934] border border-blue-500/30 overflow-hidden flex items-center justify-center text-xl font-bold text-[#00D4FF]",
									children: avatarUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: avatarUrl,
										alt: fullName,
										className: "h-full w-full object-cover"
									}) : fullName.slice(0, 1).toUpperCase()
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-semibold text-slate-900 dark:text-white mb-1.5",
									children: isAr ? `الدور الحالي: ${currentUser.role}` : `Role: ${currentUser.role}`
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "px-3.5 py-2 text-xs rounded-lg bg-slate-100 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 inline-flex items-center gap-2 cursor-pointer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "w-3.5 h-3.5" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تغيير الصورة الشخصية" : "Upload Avatar" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											accept: "image/*",
											onChange: handlePhoto,
											className: "hidden"
										})
									]
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: fullName,
										onChange: (e) => setFullName(e.target.value),
										placeholder: isAr ? "الاسم الكامل" : "Full Name",
										className: "px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "email",
										value: email,
										onChange: (e) => setEmail(e.target.value),
										placeholder: isAr ? "البريد الإلكتروني" : "Email Address",
										className: "px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: desiredRole,
										onChange: (e) => setDesiredRole(e.target.value),
										placeholder: isAr ? "الدور الوظيفي" : "Desired Role",
										className: "px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: phone,
										onChange: (e) => setPhone(e.target.value),
										placeholder: isAr ? "الهاتف" : "Phone",
										className: "px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: whatsapp,
										onChange: (e) => setWhatsapp(e.target.value),
										placeholder: isAr ? "واتساب (اختياري)" : "WhatsApp (optional)",
										className: "px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: department,
										onChange: (e) => setDepartment(e.target.value),
										placeholder: isAr ? "القسم" : "Department",
										className: "px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: skillsText,
								onChange: (e) => setSkillsText(e.target.value),
								placeholder: isAr ? "المهارات (مفصولة بفاصلة)" : "Skills (comma-separated)",
								className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								rows: 3,
								value: bio,
								onChange: (e) => setBio(e.target.value),
								placeholder: isAr ? "نبذة مختصرة..." : "Short bio...",
								className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
								type: "submit",
								disabled: saving,
								children: saving ? "Saving..." : isAr ? "حفظ التغييرات" : "Save Profile"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5 space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
						className: "p-6 space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 font-display text-base font-semibold text-slate-900 dark:text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "w-4 h-4 text-[#1D7AFC] dark:text-[#00D4FF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "تغيير كلمة المرور" : "Change Password" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleChangePassword,
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									required: true,
									value: currentPassword,
									onChange: (e) => setCurrentPassword(e.target.value),
									placeholder: isAr ? "كلمة المرور الحالية" : "Current Password",
									className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									required: true,
									minLength: 8,
									value: newPassword,
									onChange: (e) => setNewPassword(e.target.value),
									placeholder: isAr ? "كلمة المرور الجديدة (8+ أحرف)" : "New Password (8+ chars)",
									className: "w-full px-3 py-2 text-sm rounded-lg bg-slate-50 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
									size: "sm",
									type: "submit",
									disabled: changingPass,
									children: changingPass ? "Updating..." : isAr ? "تحديث كلمة المرور" : "Update Password"
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SurfaceCard, {
						className: "p-6 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 font-display text-base font-semibold text-slate-900 dark:text-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-4 h-4 text-[#1D7AFC] dark:text-[#00D4FF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAr ? "المصادقة الثنائية (2FA)" : "Two-Factor Authentication" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-600 dark:text-slate-400 leading-relaxed",
								children: isAr ? "إضافة طبقة تحقق إضافية عبر رمز من 6 أرقام عند كل تسجيل دخول." : "Require a 6-digit verification challenge on every sign-in attempt."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs font-semibold text-slate-900 dark:text-white",
								children: [
									"Status:",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: currentUser.twoFactorEnabled ? "text-emerald-500" : "text-amber-500",
										children: currentUser.twoFactorEnabled ? "Enabled" : "Disabled"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
								size: "sm",
								onClick: handleToggle2FA,
								children: currentUser.twoFactorEnabled ? isAr ? "إيقاف 2FA" : "Disable 2FA" : isAr ? "تفعيل 2FA" : "Enable 2FA"
							})
						]
					})]
				})]
			})
		]
	});
};
function App() {
	const [theme, setTheme] = (0, import_react.useState)("dark");
	const [lang, setLang] = (0, import_react.useState)("en");
	const [booting, setBooting] = (0, import_react.useState)(true);
	const [currentUser, setCurrentUser] = (0, import_react.useState)(null);
	const [activeTab, setActiveTab] = (0, import_react.useState)("dashboard");
	const [mobileMenuOpen, setMobileMenuOpen] = (0, import_react.useState)(false);
	const [users, setUsers] = (0, import_react.useState)([]);
	const [analytics, setAnalytics] = (0, import_react.useState)(null);
	const [notifications, setNotifications] = (0, import_react.useState)([]);
	const [notifDrawerOpen, setNotifDrawerOpen] = (0, import_react.useState)(false);
	const [onlineUserIds, setOnlineUserIds] = (0, import_react.useState)([]);
	const [wsEventState, setWsEventState] = (0, import_react.useState)(null);
	const seqRef = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		if (theme === "dark") root.classList.add("dark");
		else root.classList.remove("dark");
	}, [theme]);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		root.lang = lang;
		root.dir = lang === "ar" ? "rtl" : "ltr";
	}, [lang]);
	const loadWorkspaceData = async () => {
		const [uRes, aRes, nRes] = await Promise.all([
			apiRequest("/api/users"),
			apiRequest("/api/analytics"),
			apiRequest("/api/notifications")
		]);
		setUsers(uRes.users);
		setAnalytics(aRes);
		setNotifications(nRes.notifications);
	};
	(0, import_react.useEffect)(() => {
		if (!getAuthToken()) {
			setBooting(false);
			return;
		}
		apiRequest("/api/auth/me").then(async (res) => {
			setCurrentUser(res.user);
			if (res.user.preferredLanguage) setLang(res.user.preferredLanguage);
			await loadWorkspaceData();
		}).catch(() => {
			setAuthToken(null);
		}).finally(() => setBooting(false));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!currentUser || !getAuthToken()) return;
		return subscribeLive((event, payload) => {
			if (event === "workspace:changed") {
				loadWorkspaceData().catch(() => {});
				return;
			}
			if (event === "presence:init" || event === "presence:update") setOnlineUserIds(payload.onlineUserIds || []);
			else if (event === "notification:new" && payload?.userId === currentUser.id) setNotifications((prev) => prev.some((n) => n.id === payload.id) ? prev : [payload, ...prev]);
			else if (event === "session:revoked" && payload?.affectsCurrent) {
				setAuthToken(null);
				setCurrentUser(null);
			}
			seqRef.current += 1;
			setWsEventState({
				event,
				payload,
				seq: seqRef.current
			});
		});
	}, [currentUser?.id]);
	const sendWsTyping = (conversationId, isTyping) => {
		if (!currentUser) return;
		seqRef.current += 1;
		setWsEventState({
			event: "typing:update",
			payload: {
				conversationId,
				isTyping,
				userId: currentUser.id
			},
			seq: seqRef.current
		});
	};
	const handleAuthenticated = async (user, token) => {
		setAuthToken(token);
		setCurrentUser(user);
		if (user.preferredLanguage) setLang(user.preferredLanguage);
		setActiveTab("dashboard");
		await loadWorkspaceData();
	};
	const handleLogout = async () => {
		try {
			await apiRequest("/api/auth/logout", { method: "POST" });
		} catch {}
		setAuthToken(null);
		setCurrentUser(null);
	};
	const handleApproveUser = async (userId, status) => {
		await apiRequest(`/api/admin/users/${userId}/status`, {
			method: "PATCH",
			body: JSON.stringify({ status })
		});
		await loadWorkspaceData();
	};
	const handleSubmitApplication = async () => {
		const res = await apiRequest("/api/auth/onboarding/submit", { method: "POST" });
		setCurrentUser(res.user);
		await loadWorkspaceData();
	};
	const handleMarkAllRead = async () => {
		await apiRequest("/api/notifications/read-all", { method: "POST" });
		setNotifications((prev) => prev.map((n) => ({
			...n,
			read: true
		})));
	};
	if (booting) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingScreen, {});
	if (!currentUser) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthView, {
		lang,
		theme,
		onToggleLang: () => setLang((l) => l === "en" ? "ar" : "en"),
		onToggleTheme: () => setTheme((t) => t === "dark" ? "light" : "dark"),
		onAuthenticated: handleAuthenticated
	});
	const t = translations[lang];
	const unreadCount = notifications.filter((n) => !n.read).length;
	const navItems = [
		{
			id: "dashboard",
			label: t.nav.dashboard,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "w-4 h-4" })
		},
		{
			id: "design-system",
			label: t.nav["design-system"],
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "w-4 h-4" })
		},
		{
			id: "cv-builder",
			label: t.nav["cv-builder"],
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "w-4 h-4" })
		},
		{
			id: "assessments",
			label: t.nav.assessments,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "w-4 h-4" })
		},
		{
			id: "messages",
			label: t.nav.messages,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "w-4 h-4" })
		},
		{
			id: "tasks",
			label: t.nav.tasks,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareCheckBig, { className: "w-4 h-4" })
		},
		{
			id: "meetings",
			label: t.nav.meetings,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-4 h-4" })
		},
		{
			id: "security",
			label: t.nav.security,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "w-4 h-4" })
		},
		{
			id: "analytics",
			label: t.nav.analytics,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "w-4 h-4" })
		},
		{
			id: "profile",
			label: t.nav.profile,
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCog, { className: "w-4 h-4" })
		}
	];
	const SidebarContent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-full flex flex-col justify-between p-4 bg-white dark:bg-[#060c1b] border-e border-slate-200 dark:border-blue-500/15 min-h-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6 min-h-0 flex-1 overflow-y-auto pe-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KaviroLogo, { variant: "full" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "space-y-1",
				children: navItems.map((item) => {
					const active = activeTab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setActiveTab(item.id);
							setMobileMenuOpen(false);
						},
						className: `w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${active ? "bg-[#1D7AFC]/15 text-[#1D7AFC] dark:text-[#00D4FF] border border-blue-500/30" : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#0e1934]"}`,
						children: [item.icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: item.label
						})]
					}, item.id);
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 pt-4 border-t border-slate-200 dark:border-blue-500/15 shrink-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => downloadProjectZip().catch(() => {}),
				className: "w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium bg-slate-100 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/25 text-slate-800 dark:text-slate-100 hover:border-[#00D4FF] cursor-pointer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "w-3.5 h-3.5 text-[#1D7AFC] dark:text-[#00D4FF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: t.actions.downloadZip
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-semibold text-slate-900 dark:text-white truncate",
						children: currentUser.fullName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[11px] text-slate-500 dark:text-slate-400 truncate",
						children: [
							currentUser.role,
							" · ",
							currentUser.status
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: handleLogout,
					title: t.actions.signOut,
					className: "p-2 rounded-lg text-slate-500 hover:text-rose-500 hover:bg-rose-500/10 cursor-pointer",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "w-4 h-4" })
				})]
			})]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen w-full bg-slate-50 dark:bg-[#040814] text-slate-900 dark:text-slate-100 flex",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden lg:block w-64 shrink-0 sticky top-0 h-screen overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarContent, {})
			}),
			mobileMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 lg:hidden flex bg-black/60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-72 h-full relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setMobileMenuOpen(false),
						className: "absolute top-3 end-3 z-10 p-1.5 rounded-lg bg-slate-900/80 text-white cursor-pointer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-4 h-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarContent, {})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1",
					onClick: () => setMobileMenuOpen(false)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 min-w-0 flex flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-30 bg-white/90 dark:bg-[#040814]/90 backdrop-blur-md border-b border-slate-200 dark:border-blue-500/15 px-4 sm:px-6 py-3 flex items-center justify-between gap-4 no-print",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMobileMenuOpen(true),
								className: "lg:hidden p-2 rounded-lg bg-slate-100 dark:bg-[#0e1934] border border-slate-300 dark:border-blue-500/20 cursor-pointer",
								"aria-label": "Open navigation",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "w-4 h-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KaviroLogo, { variant: "compact" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden lg:flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "KAVIRO" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "/" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-slate-900 dark:text-white",
										children: t.nav[activeTab]
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 shrink-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecondaryButton, {
								size: "sm",
								onClick: () => setTheme((prev) => prev === "dark" ? "light" : "dark"),
								"aria-label": "Toggle theme",
								children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "w-3.5 h-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "w-3.5 h-3.5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
								size: "sm",
								onClick: () => setLang((prev) => prev === "en" ? "ar" : "en"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: lang === "en" ? "العربية" : "EN"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SecondaryButton, {
								size: "sm",
								onClick: () => setNotifDrawerOpen(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "w-3.5 h-3.5" }), unreadCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono-tabular text-[#1D7AFC] dark:text-[#00D4FF] font-bold",
									children: unreadCount
								})]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 pb-28",
					children: [
						activeTab === "dashboard" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardView, {
							lang,
							currentUser,
							users,
							analytics,
							onNavigate: setActiveTab,
							onApproveUser: handleApproveUser,
							onSubmitApplication: handleSubmitApplication
						}),
						activeTab === "design-system" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesignSystemView, {
							lang,
							theme,
							onToggleTheme: () => setTheme((prev) => prev === "dark" ? "light" : "dark"),
							onToggleLang: () => setLang((prev) => prev === "en" ? "ar" : "en")
						}),
						activeTab === "cv-builder" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CvBuilderView, {
							lang,
							currentUser,
							onUserUpdated: setCurrentUser
						}),
						activeTab === "assessments" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssessmentsView, {
							lang,
							currentUser,
							users,
							onUserUpdated: setCurrentUser
						}),
						activeTab === "messages" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagingView, {
							lang,
							currentUser,
							users,
							onlineUserIds,
							wsEvents: wsEventState,
							sendWsTyping
						}),
						activeTab === "tasks" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TasksProjectsView, {
							lang,
							currentUser,
							users
						}),
						activeTab === "meetings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeetingsIntegrationsView, {
							lang,
							currentUser,
							users
						}),
						activeTab === "security" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecuritySessionsView, {
							lang,
							currentUser,
							users,
							onRefreshUsers: loadWorkspaceData
						}),
						activeTab === "analytics" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalyticsView, {
							lang,
							analytics
						}),
						activeTab === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileView, {
							lang,
							currentUser,
							onUserUpdated: setCurrentUser
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationsDrawer, {
				open: notifDrawerOpen,
				lang,
				notifications,
				onClose: () => setNotifDrawerOpen(false),
				onMarkAllRead: handleMarkAllRead,
				onNavigate: setActiveTab
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiAssistantWidget, { lang })
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {});
}
//#endregion
export { Home as component };
